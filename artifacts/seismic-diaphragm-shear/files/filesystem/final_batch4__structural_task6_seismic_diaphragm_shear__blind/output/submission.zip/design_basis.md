# Building B - seismic diaphragm and shear wall design basis

Design format: **LRFD** (loads strength-level; capacities = phi x nominal). Seismic load effects are
E = Fpx, V, Fp at strength level; 0.7E is not used because the package is LRFD (SDC-02 Rev2 Sec 9).

## 1. Seismic basis

Building B is at 46.6832, -111.9756 (Lewis and Clark County, MT). Per **SDC-02 Rev2 Sec 2** the building
is **Risk Category III** (Ie = 1.25, ASCE 7-22 Table 1.5-2) because it houses the county 911 emergency
communications tenant; the Risk Category II shown on the A-101 cover sheet is the schematic issue and is
superseded. **GEO-2026-071 Sec 4** gives Site Class **D** (Vs,100 = 905 ft/s); the ASCE 7-16 / Site
Class C / Parcel 4B report GEO-2019-118 is superseded for Building B. The governing USGS service output is
the ASCE 7-22, Risk Category III, Site Class D file: **SDS = 0.44, SD1 = 0.24, SS = 0.49, S1 = 0.13**,
giving **SDC D** (ASCE 7-22 Sec 11.6, both SDS and SD1). The 2019 / RC II / Site C USGS file is for the
adjacent Parcel 4B and is not used.

Approximate period T = Ct hn^0.75 = 0.020(28)^0.75 = **0.243 s** (ASCE 7-22 Eq 12.8-7). The seismic
response coefficient **Cs = SDS/(R/Ie) = 0.44/3.2 = 0.1375** governs (Eq 12.8-2); the upper bound
SD1/(T R/Ie) = 0.308 (Eq 12.8-3) and the lower bound 0.044 SDS Ie = 0.0242 (Eq 12.8-5) do not govern.
Base shear **V = Cs W = 0.1375 x 2171 = 298.5 kips** (base mass case); 300.7 kips (future).

## 2. Seismic force-resisting system

The seismic force-resisting system is the perimeter 8 in solid normal-weight precast wall panels acting
as **bearing-wall shear walls**. The system selected is **intermediate precast shear walls**
(UFC 3-301-01 Table 3-1 row A.6; ACI 318-19 Sec 18.2.1.6), with **R = 4, Omega0 = 2.5, Cd = 4**, permitted
in SDC D up to hn = 40 ft (footnote i allows 45 ft for single-storey storage warehouses; hn = 28 ft so it
is permitted). It is the cost-efficient choice: its detailing premium is USD 1,850/panel against
USD 4,120/panel for special precast (row A.1), it uses the intermediate-qualified RPC-24/JC1 connectors
rather than the ACI ITG-5.2 ductile RPC-60D, and the 25 % seismic force increase relative to R = 5 falls
on the deck, chords and anchors whose combined cost is far smaller than the detailing and connector
premium saved. Ordinary precast (R = 3) and ordinary reinforced concrete shear walls (R = 4) are both NP
in SDC D as bearing-wall systems and are rejected. The overstrength factor is reduced to **Omega0 = 2.0**
for collectors per Table 3-1 footnote b (flexible diaphragm). The roof is a bare (untopped) steel deck
diaphragm on concrete shear walls, so it is a **flexible diaphragm** under ASCE 7-22 Sec 12.3.1.1.

## 3. As-built geometry

The deck is 240 ft (E-W) x 180 ft (N-S), roof at +28 ft, parapet top at +31 ft (panels 31 ft full height).
The erected geometry differs from the record set in three places and is the basis of design
(**RFI-041**: panels not reset, erected dimensions accepted; **PR-07**: the semi-rigid model uses the
erected geometry, not the record geometry; **ERL-2026-08** and the 7 Aug scan are the record):
- South wall D-3 erected at 15 ft-6 in (vs 14 ft detailed), and the panel band east of S-09 sits 1 ft-6 in
  east, closing the D-4/D-5 pier to 14 ft-6 in.
- North wall louver L-2 recast to shop ticket Rev B at 16 ft (PCS-014 N-12).
- West wall electrical-yard opening EY-1 widened on site to 44 ft (FC-018).
The dock doors (16 ft tall), personnel doors (8 ft) and EY-1 (20 ft) reach the foundation and break each
wall line into full-height piers; the louvers (10 ft, z = 14-24 ft) do not reach the foundation and are
spandrels that keep the segment length with rigidity factored by the solid height fraction (DAP-2 Sec 3).
All openings are below z = 24 ft, so the parapet (z = 28-31 ft) is solid on every wall line. Conflicts
resolved are listed in design_record.json `conflicts_resolved`.

## 4. Analysis

The analysis follows **DAP-2** with the envelope of flexible, rigid and semi-rigid behaviour
(SDC-02 Rev2 Sec 10; PR-07). Stage A models each wall segment as jointed precast cantilevers (DAP-2
Sec 3) using the erected geometry. The effective in-plane stiffness of each wall line is taken
proportional to its solid full-height length with spandrel (louver) runs reduced by the solid height
fraction; this gives the centre of rigidity at X = 130.8 ft, Y = 104.4 ft, offset from the centre of
mass (the N and E walls are the stiffer, more heavily pierced walls). Accidental torsion is 5 % of the
plan dimension perpendicular to loading in both signs (ASCE 7-22 Sec 12.8.4.2). The torsional
amplification factor Ax was checked on the rigid model (DAP-2 Sec 5 / ASCE 7-22 Sec 12.8.4.3): the
maximum-to-average displacement ratio is below 1.2, so there is no torsional irregularity and **Ax = 1.0**
(the check is shown for each case in WALL_FORCES). The 100/30 orthogonal cases combine 100 % of the
case direction with 30 % of the companion orthogonal direction (DAP-2 Sec 6.4). Each design force is the
largest of the three idealisations (DAP-2 Sec 6.3); reported idealisation = **envelope**. Deflections are
taken from the semi-rigid model (DAP-2 Sec 6.2).

## 5. Diaphragm and wall forces

Single-storey diaphragm force **Fpx = Cs wpx** (ASCE 7-22 Eq 12.10-1), within the 0.11 wpx ... 0.22 wpx
bounds (Eqs 12.10-2/12.10-3). The wall weight tributary to the roof uses the lever form of FEMA
P-2192-V1 Sec 7.6.1 Step 1 (w = 100 x h_tot^2/(2 h_roof) = 1716 plf for a solid wall, reduced per the
erected openings), and wpx includes the roof dead load, the RTUs and the wall lines perpendicular to the
loading direction (the parallel walls carry their own inertia, DAP-2 Sec 5). Reported (base case):
wpx(X) = 1399.9 kip, Fpx(X) = 192.5 kip, w_px = 1069 plf; wpx(Y) = 1600.1 kip, Fpx(Y) = 220.0 kip,
w_px = 917 plf. The future case (two reserved 8 kip RTUs) governs: Fpx(X) = 194.7 kip, Fpx(Y) = 222.2 kip.
The governing wall-line forces (envelope over all 12 cases) are S 98.7, N 126.3, W 113.3, E 135.1 kips
(the N and E walls, the stiffer lines, attract the larger share and the torsional component). The full
case-by-case wall forces and deck zone shears are in seismic_calculations.xlsx.

## 6. Wall anchorage and the parapet cantilever

The panels cantilever 3 ft above the deck to the parapet; the weight tributary to the roof and the
anchorage force account for the lever action (SDC-02 Rev2 Sec 6; FEMA P-2192 7.6.1 Step 1). The parapet
transfer is 100 x (3 + 9/56) = **316 plf** on every wall line (the parapet is solid; all openings are
below z = 24 ft). Wall anchorage is to ASCE 7-22 Sec 12.11.2.1 with the flexible-diaphragm amplification
ka = kp = 1 + 0.4(Lf/100) <= 2.0, Lf per UFC 3-301-01 Fig 3-1 (Lf = 180 ft for the N/S walls, 240 ft for
the E/W walls), giving kp = 1.72 (N/S) and 1.96 (E/W). Fp = 0.4 x 0.44 x 1.25 x kp x 1716 = 649 plf (N/S)
and 740 plf (E/W). E/W walls use WA1 joist-seat anchors at 6 ft oc (joists run E-W and bear on these
walls); N/S walls use WA2 embed-plate + strap anchors at 8 ft oc (joists are parallel, no seats). All
anchors satisfy phi Tn >= Fp with margin. Subdiaphragms transferring the anchorage force to the
continuous ties are 24 ft deep x 20 ft span (l/d <= 2.5, ASCE 7-22 Sec 12.11.2.2.1).

## 7. Governing constraint per wall line

- **S wall:** in-plane shear delivered through the dock-door piers; the drag strut across D-3 (15.5 ft)
  governs the collector (12.7 kip amplified); deck zone Z1/Z2 shear governs the deck attachment.
- **N wall:** in-plane shear; the louvered spandrel segments (reduced rigidity) and the stiffer N line
  attract the larger share; collector across the L-1/L-2 spandrel runs (16.8 kip amplified).
- **W wall:** the 44 ft EY-1 opening governs the drag strut (55.4 kip amplified -> C2 member);
  the reduced pier length governs the wall in-plane stiffness and the tie-down (47.6 kip -> BA2).
- **E wall:** the largest envelope wall force (135.1 kip); the 72 ft pier segment governs the
  tie-down (48.7 kip -> BA2) and the in-plane shear.
All wall lines satisfy: deck attachment phi Sn >= zone shear; chord force M/depth (18-37 kip -> C1);
collector Omega0 x drag force -> C1/C2; connector phi Vn >= joint shear; base tie-down phi Tn >= demand
(BA2); wall anchor phi Tn >= Fp; amplified diaphragm deflection 3.18 in + wall drift 0.14 in = 3.33 in <= 4.0 in; story drift 0.14 in <= 5.04 in.

## 8. Cost

Installed lateral-scope cost = **USD 364,602** against the PROC-114 capital cap of USD 395,000
(utilisation 92 %). Breakdown: deck attachment USD 66,790
(P2/P4/P5 by zone), chords USD 9,576, collectors/drag struts USD 15,486,
panel joint connectors USD 33,110 (1 x JC1 per joint on S/N, 2 x JC1 per joint on W/E; 60 joints),
base tie-downs USD 73,710 (BA2 per panel), wall anchors USD 16,080,
intermediate-precast SFRS detailing premium USD 149,850 (USD 1,850 x 81 panels).

## 9. Alternatives rejected

- **Special precast shear walls (R = 5):** lower seismic force but USD 4,120/panel detailing premium
  (delta USD 2,270/panel = USD 184 k) plus mandatory RPC-60D ductile connectors (USD 1,240 each) far
  exceed the saving on the deck, chords and anchors; rejected on cost.
- **Ordinary precast (R = 3) / ordinary reinforced concrete shear walls (R = 4):** NP in SDC D as
  bearing-wall systems (UFC Table 3-1 rows A.3, A.7); rejected.
- **ASD format:** requires Sn/Omega (deck Omega = 2.55) against 0.7E, ~7 % more conservative than LRFD
  (phi = 0.60) on the deck attachment; LRFD chosen for the lower installed cost (SDC-02 Rev2 Sec 9).
- **ASCE 7-22 Sec 12.10.3/12.10.4 alternative diaphragm method:** barred by SDC-02 Rev2 Sec 5 (the
  owner's serviceability criterion governs the diaphragm stiffness); the 12.10 Exception bars only
  precast concrete diaphragms and the Building B roof is steel deck.
- **Flexible idealisation as the sole basis:** rejected by PR-07 (unequal piering, eccentric centre of
  rigidity); the envelope of flexible/rigid/semi-rigid is used.
