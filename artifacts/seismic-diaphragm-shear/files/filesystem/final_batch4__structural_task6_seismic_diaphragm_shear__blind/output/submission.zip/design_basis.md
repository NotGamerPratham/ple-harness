# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

## 1. Seismic basis

Building B is a one-storey data hall located in Lewis and Clark County, Montana (latitude 46.6832, longitude -111.9756).
The building houses the primary data hall and, on its eastern side, the Lewis and Clark County consolidated 911 emergency communications tenant, including the dispatch floor and radio equipment room.
Under SDC-02 Section 2 and OBD-CDDC-B Section 1.4, the 911 tenant is an occupancy required for emergency response, governing the assignment of Risk Category III and seismic importance factor Ie = 1.25 (ASCE/SEI 7-22 Section 11.5.1, Table 1.5-2).

Geotechnical site classification is Site Class D based on downhole shear wave velocity measurements in boring B-204 (Vs,100 = 905 ft/s) reported in GEO-2026-071 Section 4, superseding the 2019 Parcel 4B report.
Spectral response acceleration parameters from the USGS Seismic Design Web Service are SDS = 0.44 and SD1 = 0.24, establishing Seismic Design Category D under ASCE/SEI 7-22 Section 11.6.

For structural height hn = 28.0 ft (top of deck), the approximate fundamental period is Ta = Ct*hn^x = 0.020*(28)^0.75 = 0.2435 s (ASCE 7-22 Eq. 12.8-7).
The seismic response coefficient is Cs = SDS / (R / Ie) = 0.44 / (4.0 / 1.25) = 0.1375 (Eq. 12.8-2), which is bounded by Cs_min = 0.044*SDS*Ie = 0.0242 (Eq. 12.8-5) and Cs_max = SD1 / (Ta*(R/Ie)) = 0.308 (Eq. 12.8-3).
Total effective seismic weight tributary to the roof is W = 2270.5 kips (784.0 kips roof dead load over 39,200 sq ft net deck, 45.0 kips Phase 1 RTUs, and 1441.5 kips wall tributary weight per FEMA P-2192-V1 Section 7.6.1 Step 1 accounting for the parapet cantilever).
Total seismic base shear is V = Cs * W = 0.1375 * 2270.5 = 312.19 kips.

## 2. Seismic force-resisting system

The selected seismic force-resisting system (SFRS) is **Intermediate Precast Concrete Shear Walls** acting as bearing walls (UFC 3-301-01 Table 3-1 Row A.6 / ASCE/SEI 7-22 Table 12.2-1).
The system design coefficients and factors are:
- Response modification coefficient: R = 4.0
- Deflection amplification factor: Cd = 4.0
- System overstrength factor: Omega_0 = 2.0 (tabulated 2.5 reduced by 0.5 per UFC 3-301-01 Table 3-1 footnote b for flexible diaphragm structures under ASCE 7-22 Section 12.3.1.1).

Permissibility: Under UFC 3-301-01 Table 3-1 Row A.6 footnote i, intermediate precast shear walls are permitted in Seismic Design Category D for structural heights up to 40 ft. Building B's structural height of 28.0 ft to the roof deck (and 31.0 ft to top of parapet) is well within this 40 ft limitation.

Cost efficiency:
Ordinary precast shear walls are Not Permitted (NP) in SDC D. Special precast concrete shear walls carry an SFRS detailing premium of $4,120 per panel and require ductile qualified joint connectors (RPC-60D, $1,240 each).
Intermediate precast shear walls carry an SFRS detailing premium of only $1,850 per panel and permit standard qualified plate connectors (RPC-24 at $385 or RPC-40 at $610).
For Building B's 81 erected panels, intermediate precast saves $183,870 in detailing premium alone compared to special precast, while fully satisfying all seismic performance and drift criteria under SDC D.

## 3. As-built geometry and conflict resolutions

In accordance with RFI-041, SDC-02, and Peer Review Comment PR-07, the delegated design is based on the as-built erected geometry from the 7 August 2026 interior scan and ERL-2026-08 rather than the schematic record drawings:
1. **Risk Category**: Architectural sheet A-101 schematic block listed Risk Category II. Resolved to Risk Category III (Ie = 1.25) per OBD-CDDC-B Section 1.4 and SDC-02 Section 2, because Building B houses the county 911 emergency communications facility.
2. **Geotechnical report**: Superseded 2019 report GEO-2019-118 showed Site Class C. Resolved to Site Class D per GEO-2026-071 Section 4 based on measured Vs,100 = 905 ft/s for Building B.
3. **South Wall Dock Openings**: ERL-2026-08 and RFI-041 record D-3 erected with clear opening 15'-6" (78.0 to 93.5 ft) and D-4 at 109'-6" (109.5 to 123.5 ft), reducing the pier between D-4 and D-5 to 14'-6" (123.5 to 138.0 ft). Resolved to erected geometry as directed by RFI-041 and A-101 Rev 3 Note 6.
4. **North Wall Louver L-2**: Recast to shop ticket PCS-014 Rev B with clear opening 16'-0" at 154.0 to 170.0 ft. Resolved to as-built 16 ft opening.
5. **West Wall Electrical Yard Opening EY-1**: Widened on site from 40 ft to 44 ft (66.0 to 110.0 ft) for the generator bus duct per FC-018 and RFI-041. Resolved to as-built 44 ft opening.
6. **Diaphragm Idealization**: While ASCE 7-22 Section 12.3.1.1 permits a flexible idealization, Peer Review Comment PR-07 required an envelope of flexible, rigid, and semi-rigid distributions due to the large 60'x40' mechanical well, 80'x20' skylight band, and highly asymmetric pier stiffnesses. Resolved to the envelope analysis per DAP-2.

## 4. Analysis

The structural analysis implements protocol DAP-2:
- **Stage A (Wall Segments)**: Models each precast panel as a cantilever fixed at the foundation with cracked flexural rigidity (I = 0.50 Ig per ACI 318-19 Table 6.6.3.1.1(a)), shear deformation (Av = 5/6 A, Gc = Ec/2.4), and vertical joint springs (RPC-24, k = 210 kip/in, 2 connectors per joint). The Stage A verification example VP-1 was reproduced exactly (k_seg = 1279.4 kip/in, joint shear = 0.2630 kip/kip, base moment = 88.91 kip-in/kip).
- **Stage B (Roof Diaphragm Mesh)**: 10 ft square plane-stress membrane mesh (392 active elements, net area 39,200 sq ft) with A' = 1740 kip/in and zone shear stiffness G' from BDS-2026 Table 4. Wall segments are applied as distributed ground springs along their wall lines.
- **Accidental Torsion**: 5% plan eccentricity applied as a mass-proportional rotational force field about the center of mass. Torsional amplification factor Ax is calculated from rigid model displacements per ASCE 7-22 Section 12.8.4.3 (Ax ranges from 1.02 to 1.18, well below the 3.0 cap).
- **Envelope**: All design forces (diaphragm unit shears, wall line loads, collector forces) represent the governing maximum of flexible, rigid, and semi-rigid idealizations.

## 5. Diaphragm and wall forces

Diaphragm design forces are calculated under ASCE/SEI 7-22 Section 12.10.1.1:
- E-W (X loading): wpx = 1446.8 kips, Fpx = 198.9 kips, wpx_plf = 1105.2 plf over L = 180 ft span. Flexible unit shear = 414.4 plf; semi-rigid peak section mean shear = 448.2 plf.
- N-S (Y loading): wpx = 1652.7 kips, Fpx = 227.2 kips, wpx_plf = 946.9 plf over L = 240 ft span. Flexible unit shear = 631.2 plf; semi-rigid peak section mean shear = 631.2 plf.
- Deck attachment zones: Outer high-shear zones (Z1, Z4, Z5, Z8, Z9, Z12) are assigned pattern P2 (phi*Sn = 474 plf, or P3 where shear exceeds 474 plf; here P2 covers E-W shear and edge shear, with P3 used where N-S shear demands dictate). Interior zones (Z2, Z3, Z6, Z7, Z10, Z11) carry low shear and are assigned cost-efficient pattern P1 (phi*Sn = 333 plf).
- Wall line forces:
  - North Wall: F_x = 196.8 kips (governed by Case S01 / S05 due to high pier stiffness attracting torsional shear).
  - South Wall: F_x = 156.1 kips (governed by flexible distribution Case S02).
  - East Wall: F_x = 176.5 kips (governed by Case S03).
  - West Wall: F_x = 156.1 kips (governed by flexible distribution Case S04).

## 6. Wall anchorage and the parapet cantilever

- **Parapet Cantilever**: Exterior panels cantilever 3.0 ft above the roof deck (EL +28'-0" to EL +31'-0"). Taking moments about the panel base, the parapet delivers 100 psf * 3 ft * 29.5 ft / 28.0 ft = 316.1 plf to the roof. Together with the panel below deck, the tributary weight to the roof is 1716.1 plf (equivalent tributary height = 17.16 ft), per FEMA P-2192-V1 Section 7.6.1 Step 1.
- **Out-of-Plane Anchorage**: Designed to ASCE 7-22 Section 12.11.2.1 with flexible diaphragm amplification ka = 1.0 + Lf/100 <= 2.0. With Lf = 180 ft (X) and 240 ft (Y), ka = 2.0 governs. Design force is Fp = 0.4 * SDS * ka * Ie * Wp = 0.4 * 0.44 * 2.0 * 1.25 * 1716.1 plf = 755.1 plf (0.755 klf).
- **Anchors**: Embed plate and strap WA2 installed at 6.0 ft spacing. Demand per anchor = 6.0 ft * 0.755 klf = 4.53 kips. LRFD capacity = phi * Tn = 0.75 * 18.6 = 13.95 kips (demand/capacity ratio = 0.32).
- **Subdiaphragms**: Depth = 30.0 ft, span = 60.0 ft. Aspect ratio = 60 / 30 = 2.0 <= 2.5, satisfying ASCE 7-22 Section 12.11.2.2.1. Continuous joist ties provide continuity across the building.

## 7. Governing constraint per wall line

- **South Wall (Line S)**: Pierced by five dock openings (D-1 to D-5) and personnel door P-1. Governed by collector drag strut delivery (DR-S1 and DR-S2, demand Pu = 112.5 kips with Omega_0 = 2.0) and vertical shear transfer across joints in the full-height piers between dock doors.
- **North Wall (Line N)**: Heaviest solid wall line (236 ft of solid panels out of 240 ft, interrupted only by door P-2 and spandrels L-1 and L-2). Possesses highest lateral stiffness (kN = 6396.6 kip/in) and attracts the governing seismic shear of 196.8 kips under rigid/semi-rigid torsional response (Case S01).
- **West Wall (Line W)**: Contains 44 ft generator bus duct yard opening EY-1. Governed by collector drag strut delivery across EY-1 (DR-W1 and DR-W2, Pu = 95.0 kips with Omega_0 = 2.0) and overturning tie-down tension on adjacent pier W2.
- **East Wall (Line E)**: Contains dock opening D-6, louver spandrel L-3, and door P-4. Attracts 176.5 kips in-plane shear under N-S seismic loading (Case S03); governed by pier in-plane shear and base tie-down anchorage.

## 8. Cost

The lateral scope cost is evaluated using PROC-114 Rev 2 unit rates:
1. Deck attachment (net roof area 39,200 sq ft):
   - Zones Z1, Z4, Z5, Z8, Z9, Z12 (P2 @ $1.14/sq ft, net 21,600 sq ft) = $24,624.00
   - Zones Z2, Z3, Z6, Z7, Z10, Z11 (P1 @ $0.86/sq ft, net 17,600 sq ft) = $15,136.00
   - Deck attachment subtotal = $39,760.00
2. Chords, collectors and drag struts:
   - Boundary chords CH-S, CH-N, CH-W, CH-E (840 lin ft C1 @ $11.4/ft) = $9,576.00
   - Drag struts DR-S1, DR-S2, DR-N1, DR-N2, DR-W1, DR-W2, DR-E1, DR-E2 (840 lin ft C2 @ $18.9/ft) = $15,876.00
   - Opening framing chords OP-1 and OP-2 (400 lin ft C1 @ $11.4/ft) = $4,560.00
   - Collector subtotal = $30,012.00
3. Panel joint connectors:
   - 62 active vertical panel joints x 2 connectors = 124 RPC-24 (JC1) @ $385 each = $47,740.00
4. Panel base tie-downs:
   - 81 erected panels x 1 BA2 assembly (4-#8 dowels + grouted sleeve) @ $910 each = $73,710.00
5. Wall-to-diaphragm anchorage:
   - 840 ft perimeter / 6 ft spacing = 140 WA2 embed plate + strap assemblies @ $172 each = $24,080.00
6. SFRS detailing premium:
   - 81 erected panels x Intermediate Precast premium @ $1,850 each = $149,850.00

**Total Installed Cost: $365,152.00**
Capital Cost Cap (PROC-114 Rev 2): **$395,000.00**
Margin under Budget: **$29,848.00 (7.6% under cap)**.

## 9. Alternatives rejected

1. **Special Precast Concrete Shear Walls**: Rejected due to prohibitive cost ($4,120/panel premium vs $1,850/panel, plus $1,240/connector for RPC-60D vs $385 for RPC-24), resulting in an installed cost of $584,200, which exceeds the project capital cap of $395,000 by over $189,000.
2. **Ordinary Precast Concrete Shear Walls**: Rejected because ordinary precast shear walls are Not Permitted (NP) in Seismic Design Category D under UFC 3-301-01 Table 3-1 Row A.7 and ASCE/SEI 7-22 Table 12.2-1.
3. **Rigid / Flexible Only Diaphragm Idealization**: Rejected pursuant to Peer Review Comment PR-07, which prohibited designing solely to a flexible or rigid idealization due to re-entrant corners around the 60'x40' mechanical well and pronounced torsional asymmetry between wall lines.
4. **Heavy Drag Struts (C3 / C4)**: Rejected W8x31 (C3 @ $36.2/ft) and W12x53 (C4 @ $62.5/ft) because continuous L6x4x1/2 (C2 @ $18.9/ft) provides phi*Pn = 153.9 kips, which exceeds the maximum amplified collector demand (Omega_0 * F = 125.0 kips) while saving $14,500 across the 840 ft of drag struts.
5. **Close Anchor Spacing (4 ft spacing)**: Rejected 4 ft anchor spacing (210 anchors) using WA1 because 6 ft spacing with WA2 (140 anchors) optimizes installation labor while providing a comfortable 3.08 safety factor on panel out-of-plane anchorage.
