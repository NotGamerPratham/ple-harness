# Design Basis Narrative — Building A2 Roof Diaphragm and Perimeter Shear Walls

**Project:** Northern Divide Data Campus, Building A2  
**Location:** Lewis and Clark County, Montana  
**Delegated Structural Engineer:** Kestrel Ridge Structural Engineers, PLLC  
**Submittal Date:** August 2026  
**Status:** Issued for Construction / EOR Review  

---

## 1. Primary Design Parameters Table

In accordance with Specification Section 01 33 00, Clause 1.6, the lateral design of the Building A2 roof diaphragm and perimeter shear walls is established on the following governing values:

| item | value | source |
| Kzt | 1.19 | TS-2026-02 clause 4 |
| Ke | 0.8671 | ALTA-2025-77 clause 1 & EOR-NDDC-A2-S01 clause 4.4 |
| q_h_psf | 28.75 | EOR-NDDC-A2-S01 clause 4.2 |
| screen_wall_top_ft | 36.00 | SR-2026-118 clause 5.2 |
| asbuilt_opening_panel | S14 | NDDC-A2 Federated Model 2026 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 clause 3.3 |
| omega_d | 2.35 | CDS-B36 Note 2 |
| analysis_method | DIAPH-MT 1.0 semi-rigid finite element model | EOR-NDDC-A2-S01 section 9 |
| mesh_level | L2 | EOR-NDDC-A2-S01 clause 9.7 |

---

## 2. Governing Wind Scenarios Table

The governing wind scenario for each exterior wall line, established from the envelope of roof-level wall line loads (with the corresponding peak diaphragm reactions also documented), is tabulated below:

| line | governing scenario |
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W01 |
| E2 | W07 |

*Notes on Governing Scenarios:*
* **Wall Line S (South face, y = 0 ft):** Governed by Scenario W05 (Azimuth 180°, direct South wind), generating the maximum roof-level inward line load of 253.06 plf (ASD). The peak reaction taken out of the diaphragm by Line S is 33.70 kips (ASD) under Scenario W07.
* **Wall Line E (East face, x = 240 ft):** Governed by Scenario W03 (Azimuth 090°, direct East wind), generating the maximum roof-level inward line load of 253.42 plf (ASD). The peak reaction taken out of the diaphragm by Line E is 22.01 kips (ASD) under Scenario W10.
* **Wall Line N1 (North face, y = 180 ft):** Governed by Scenario W01 (Azimuth 000°, direct North wind), generating the maximum roof-level inward line load of 321.78 plf (ASD), amplified by the solid mechanical screen wall cantilevering to +36.00 ft. The peak reaction taken out of the diaphragm by Line N1 is 35.08 kips (ASD) under Scenario W08.
* **Wall Line W (West face, x = 0 ft):** Governed by Scenario W07 (Azimuth 270°, direct West wind), generating the maximum roof-level inward line load of 252.34 plf (ASD). The peak reaction taken out of the diaphragm by Line W is 49.04 kips (ASD) under Scenario W01.
* **Wall Line N2 (Generator yard notch north line, y = 140 ft):** Governed by Scenario W01 (Azimuth 000°, North wind), generating a roof-level line load of 265.68 plf (ASD). The peak reaction taken out of the diaphragm by Line N2 is 16.29 kips (ASD) under Scenario W03.
* **Wall Line E2 (Generator yard notch east line, x = 180 ft):** Governed by Scenario W07 (Azimuth 270°, West wind), generating a roof-level line load of 263.98 plf (ASD). The peak reaction taken out of the diaphragm by Line E2 is 44.11 kips (ASD) under Scenario W01, where collector line K-E2 drags significant diaphragm shear into Line E2.

---

## 3. Resolution of Document Conflicts

During the preparation of this lateral package, several dimensional, loading, and analytical discrepancies were identified among the issued historical, architectural, structural, and vendor documents. Each conflict was resolved strictly in accordance with the hierarchy established in the project transmittal T-204 and Structural Design Criteria EOR-NDDC-A2-S01 Revision 2:

### 3.1 Basic Wind Speed and Building Risk Category
* **Conflict:** The preliminary structural design criteria (Revision 0, dated 3 May 2024) and the 2024 pre-application correspondence cited a basic wind speed $V = 105\text{ mph}$ under Risk Category II. Conversely, the official Authority Having Jurisdiction letter (NDDC-AHJ-014, dated 11 June 2026) mandated Risk Category III due to the facility's continuous-operation data processing role supporting critical county communications, accepting a hazard determination of $V = 115\text{ mph}$ (3-second gust).
* **Resolution:** Revision 0 was formally superseded. The design incorporates Risk Category III and basic wind speed $V = 115\text{ mph}$ per NDDC-AHJ-014 and Criteria Revision 2 Section 2 and Section 4.2.

### 3.2 Topographic Speed-Up Factor ($K_{{zt}}$)
* **Conflict:** Revision 0 assumed level ground with $K_{{zt}} = 1.00$. Subsequently, the site-specific boundary-layer topographic wind study (TS-2026-02, dated 30 April 2026) established that the campus sits within the upper quarter of a 190 ft river valley rise classifying as an escarpment for easterly winds and a 2D ridge for westerly winds.
* **Resolution:** The escarpment speed-up governs. A uniform topographic factor $K_{{zt}} = 1.19$ is applied across the entire building footprint and over the full height of all panels and parapets, as mandated by TS-2026-02 Clause 4 and Criteria Revision 2 Section 4.3.

### 3.3 Atmospheric Ground Elevation Factor ($K_e$)
* **Conflict:** Standard regional practice often takes $K_e = 1.00$. However, ALTA Site Survey ALTA-2025-77 establishes that finished floor elevation FF-A2 is at 3,940.0 ft NAVD 88 (site benchmark BM-2 at 3,941.02 ft NAVD 88). Criteria Revision 2 Section 4.4 explicitly prohibits taking $K_e = 1.00$ and defines $K_e = \exp(-0.0000362 \cdot z_g)$.
* **Resolution:** Utilizing $z_g = 3940.0\text{ ft}$, the ground elevation factor is established as $K_e = \exp(-0.0000362 \times 3940.0) = 0.8671$. At mean roof height ($z = 28.00\text{ ft}$, $K_z = 0.9681$), with $K_d = 0.85$, $K_{{zt}} = 1.19$, and $V = 115\text{ mph}$, the design velocity pressure is $q_h = 28.75\text{ psf}$.

### 3.4 Mechanical Screen Wall Parapet Geometry (North Elevation)
* **Conflict:** The 2024 Precast Panel Schedule PC-S01 and Revision 0 drawings showed all north elevation panels at a uniform parapet elevation of +31.00 ft (3.00 ft above the roof deck). However, the Terrestrial Laser Scan Report SR-2026-118 and the 2026 Federated IFC Model reveal that between $x = 96.00\text{ ft}$ and $x = 168.00\text{ ft}$, panels N108, N109, N110, and N111 were cast and erected with an extended solid precast mechanical screen wall reaching elevation +36.00 ft (8.00 ft above roof deck).
* **Resolution:** Per Criteria Revision 2 Section 5.3, the as-built federated model and scan report govern over the unrevised 2024 shop schedule. A parapet top elevation of +36.00 ft is assigned to panels N108–N111. Velocity pressure for this extended cantilever is evaluated at the top of the screen wall ($z = 36.00\text{ ft}$, $K_z = 1.0207$, $q_p = 30.31\text{ psf}$), and its full windward/leeward net load is transferred into the roof deck diaphragm via the simple-beam lever action formulation ($R_{{roof}} = p \cdot A \cdot z / h$).

### 3.5 As-Built Field-Cut Opening on South Panel S14
* **Conflict:** Precast Panel Schedule PC-S01 and Panel Elevations PC-S02 Rev 2 designate panel S14 as solid with no openings. In contrast, the 2026 Federated IFC Model records a field-cut opening (S14-O1) measuring 8.00 ft wide by 12.00 ft high, located between stations $s = 194.50\text{ ft}$ and $s = 202.50\text{ ft}$ (panel extent $s = 192.00\text{ ft}$ to $204.00\text{ ft}$).
* **Resolution:** Per PC-S02 General Note 4 and Criteria Section 5.3, the as-built federated model governs over fabrication drawings for field openings. The opening divides panel S14 into two vertical legs: Leg 1 ($s = 192.00\text{ ft}$ to $194.50\text{ ft}$, width 2.50 ft) and Leg 2 ($s = 202.50\text{ ft}$ to $204.00\text{ ft}$, width 1.50 ft). Under Criteria Section 5.4, any leg narrower than 2.0 ft carries no in-plane shear and is neglected. Accordingly, Leg 2 is neglected, while Leg 1 ($L = 2.50\text{ ft}$, $t = 8\text{ in}$, $k = 5.70\text{ kip/in}$) is scheduled as the sole active pier on panel S14.

### 3.6 Diaphragm Analysis Method and Code Acceptance
* **Conflict:** Preliminary studies for Hall B on the campus utilized a flexible diaphragm tributary distribution, while Revision 0 of the Criteria permitted a rigid diaphragm analysis. AHJ Letter NDDC-AHJ-014 Section 3 specifically noted the re-entrant plan notch at the generator yard and the heavy mechanical screen wall, formally rejecting both flexible and rigid diaphragm distributions.
* **Resolution:** In strict compliance with Criteria Revision 2 Section 9, the semi-rigid finite element model DIAPH-MT 1.0 is implemented. The model employs 4-node bilinear membrane elements integrated with 2x2 Gauss quadrature, continuous 2-node chord/collector bar elements, and discrete pier support springs attached at nearest perimeter nodes. The formulation was rigorously validated against verification benchmark VE-1 prior to campus deployment, matching all VE-1 published displacements, reactions, shears, and chord forces to the exact decimal. Convergence between mesh Level L2 ($H = 5.0\text{ ft}$, 1,584 elements) and Level L3 ($H = 2.5\text{ ft}$, 6,336 elements) achieves a 0.17% relative reaction change on Line W under Scenario W01, comfortably satisfying the 5% code threshold.

---

## 4. Summary of Design Compliance

* **Deck Design:** A 3-deck-type scheme is implemented across the 12 roof zones, satisfying OBD 4.6 (maximum 4 types): D22-36/4-2 ($3.05/sf, ASD cap 417 plf) in low-shear zones Z21, Z22, Z23; D22-36/7-4 ($3.95/sf, ASD cap 842.6 plf) in peak-shear zones Z11, Z13, Z33; and D22-36/7-2 ($3.62/sf, ASD cap 685.1 plf) in all remaining zones. In all zones, peak ASD unit shears remain safely below allowable deck shear capacities.
* **Chord and Collector Design:** ASTM A572 Grade 50 plate sections PL4x3/8 are assigned to Line C-E2 (maximum demand 16.54 kips vs 27.0 kips allowable compression) and PL3x3/8 to all other 11 boundary chord and opening collector lines, satisfying allowable stress design criteria.
* **Deflection and Drift:** Maximum relative diaphragm deflection is 0.2820 in along global X and 0.5187 in along global Y, both satisfying the strict 0.55 in campus tolerance (OBD 4.4). Maximum pier drift is 0.0505 in, well within the $h/400 = 0.84\text{ in}$ limit.
* **Panel Anchorage & Base Stability:** 17 panels experience net overturning under the $0.6D + 0.6W$ ASD load combination and are equipped with Type T1 base tie-down assemblies (88 kips ASD capacity at lever arm $L$). A total of 146 Type E1 deck-to-panel embed connections are scheduled to satisfy the 8 ft spacing and shear transfer criteria.
* **Cost Cap:** The total installed cost of the package is **$224,030.94**, well below the Owner's Basis of Design cap of **$310,000.00**.
