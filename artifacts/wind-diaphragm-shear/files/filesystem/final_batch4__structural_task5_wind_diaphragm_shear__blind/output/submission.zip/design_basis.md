# Design Basis — Building A2 Roof Diaphragm and Perimeter Shear Walls

Northern Divide Data Campus, Building A2, Lewis and Clark County, Montana. Lateral package for the roof deck diaphragm, chords, collectors, precast perimeter shear wall panels and their connections under wind. Delegated design to the criteria EOR-NDDC-A2-S01 Rev 2.

## 1. Design values table

| item | value | source |
|---|---|---|
| Kzt | 1.19 | TS-2026-02 section 4 |
| Ke | 0.8671 | EOR-NDDC-A2-S01 section 4.4; ALTA-2025-77 section 1 (zg=3940.0 ft FF-A2) |
| q_h_psf | 28.746 | EOR-NDDC-A2-S01 section 4.2 at mean roof height 28.0 ft |
| screen_wall_top_ft | 36.0 | SR-2026-118 section 5.2; as-built federated model (N108-N111) |
| asbuilt_opening_panel | S14 | IFC federated model 2026; field-cut opening S14-O1 not on PC-S01 2024 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 section 3.3 |
| omega_d | 2.35 | CDS-B36 Notes 2 |
| analysis_method | DIAPH-MT 1.0 semi-rigid: Q4 bilinear orthotropic membrane + chord/collector bar elements + pier springs | EOR-NDDC-A2-S01 section 9 |
| mesh_level | L2 (H=5.0 ft) | EOR-NDDC-A2-S01 section 9.7 |

## 2. Governing wind scenario per wall line

| line | governing scenario |
|---|---|
| S | W07 |
| E | W01 |
| N1 | W08 |
| W | W01 |
| N2 | W03 |
| E2 | W01 |

## 3. Basis of design

- **Code and risk.** 2021 IBC (ARM 24.301.131) with ASCE/SEI 7-16; Risk Category III per AHJ letter NDDC-AHJ-014. Wind governs the lateral design in both directions (Seismic Design Category B, separate package).

- **Wind parameters.** Basic wind speed V = 115 mph (3-second gust), Exposure C, Kd = 0.85, Kzt = 1.19, Ke = 0.8671 (site ground elevation 3940.0 ft). Velocity pressure at the mean roof height (28.0 ft) q_h = 28.746 psf. Internal pressure (GCpi = +/-0.18) cancels in the net MWFRS lateral force and is not included in the diaphragm and shear wall loads.

- **Reported quantities are ASD**, obtained from the strength-level wind effect by the load combination 0.6W (criteria 3.3). Drawings and the calculation package state on their face that the loads shown are ASD.

- **As-built geometry governs.** Panel marks, lengths, thicknesses, top elevations and openings are taken from the 2026 federated model (IFC) and the roof line scan (SR-2026-118); where the 2024 precast panel schedule disagrees, the as-built model governs.

- **Diaphragm analysis.** The semi-rigid model DIAPH-MT 1.0 of criteria section 9 is used: a structured square mesh (reported at L2, H = 5.0 ft) of four-node bilinear orthotropic membrane elements (Ghat = 12 G'), chord/collector bar elements on the lines of S-201, and one spring per pier (leg) at the node nearest the leg midpoint. Implementation was checked against verification example VE-1 (elements/nodes 240/273, reactions 10.00/10.00 kips, largest unit shear 185.2 plf, largest chord force 2.57 kips, largest displacement 0.1669 in) before it was applied to Building A2.

- **Deck.** Two deck types are used: D22-36/4-4 in zones Z22 and Z42 and D22-36/7-4 in the remaining ten zones (within the four-type cap). The Z22 deck span is 4 ft so its tabulated G' is multiplied by 1.15 for stiffness only. ASD shear capacity is the nominal strength divided by omega_d = 2.35. The governing diaphragm unit shear (621 plf ASD at L2) is below every zone capacity.

- **Chords and collectors.** One section per line from KRS-CH; all lines carry PL3x3/8 (allowable tension 33.8 kips, compression 20.3 kips), which envelopes the largest recovered chord/collector force (13.8 kips ASD at C-E2).

- **Piers, embeds and tie-downs.** Each panel leg is a cantilever pier (criteria 5.5); legs narrower than 2.0 ft are neglected (S14 retains one 2.5 ft leg). Deck-to-panel E1 embeds (4.20 kips ASD each, 8 ft o.c. maximum, minimum two per panel) are provided per panel to develop the panel roof-level shear. Where the panel self-weight does not satisfy the 0.6D + 0.6W stability check, a T1 tie-down assembly (88 kips at the panel length lever arm) is provided.

- **Acceptance.** Diaphragm deflection relative to supports: 0.490 in < 0.55 in. Pier drift: < 0.84 in (h/400). Mesh convergence (relative change L2-L3 in the W-line reaction under W01) = 0.24% < 5%. Installed cost $229,210 < $310,000 cap.

## 4. Conflicts between issued documents and how they were resolved

1. **Kzt and basic wind speed, EOR Rev 0 vs the topographic study and AHJ letter.** Rev 0 of the structural design criteria carried Kzt = 1.00 and V = 105 mph at Risk Category II. The site-specific topographic study TS-2026-02 (section 4) gives Kzt = 1.19 over the whole footprint, and AHJ letter NDDC-AHJ-014 (section 2) accepts V = 115 mph at Risk Category III and states the 2024 pre-application memorandum is superseded. Resolved: Kzt = 1.19 and V = 115 mph at Risk Category III are used; Rev 0 values are not used (T-204 item 12 archives Rev 0).

2. **Screen wall top elevation, 2024 panel schedule vs as-built scan.** PC-S01 (2024 fabrication issue) shows panels N108, N109, N110 and N111 at a 31.0 ft top of panel. The roof line scan SR-2026-118 (section 5.2) and the federated model show these four panels at 36.0 ft, forming the mechanical screen wall between x = 96 ft and x = 168 ft. Resolved per criteria 5.3: the as-built 36.0 ft governs; the parapet for N108-N111 is 8.0 ft and its pressure is evaluated at q_p(36 ft). The difference is reported here.

3. **Field-cut opening on S14, 2024 panel schedule vs as-built model.** PC-S01 shows no opening on panel S14. The federated model contains opening S14-O1, provenance "field-cut after erection", 8.0 ft wide by 12.0 ft high at station 194.5-202.5 ft. Resolved per criteria 5.3 and the OBD "asbuilt_opening_panel" item: the as-built opening governs; S14 is divided into one 2.5 ft leg (the 1.5 ft leg is neglected under the 2.0 ft rule). This is the asbuilt_opening_panel reported in the design values table.

4. **Panel geometry, 2024 schedule vs 2026 federated model.** T-204 item 10 issues PC-S01 "for information; superseded by the federated model." Resolved: panel lengths, thicknesses, top elevations and cast openings are taken from the federated model and the roof line scan; PC-S01 is used only where it agrees with the as-built model (thicknesses are unchanged).

5. **Roof extents, Revision A vs Revision C.** A-101 Revision A showed a clean rectangle; Revision C (and the federated model) show the generator-yard re-entrant corner at x = 180, y = 140 added by Revision B. Resolved: the L-shaped as-built outline is used; Revision A is archived (T-204 item 13).

6. **Precast panel elevations, Rev 1 vs Rev 2.** PC-S02 Rev 1 is superseded by Rev 2 (T-204 item 14). Resolved: PC-S02 Rev 2 is used and cross-checked against the federated model.

7. **Hall B Lateral Study.** T-204 item 15 issues the Hall B (Building A1) study "for information only" as another building. Resolved: it is not used for Building A2.

8. **Panel base connection B1 capacity at the re-entrant corner.** Panel E201 at the generator-yard re-entrant corner recovers an ASD in-plane shear that exceeds the standard B1 capacity of 1.40 kip/ft (10 ft panel). Per KRS-CN section 3.2 the base connection is not field-adjustable and a panel exceeding B1 requires a panel redesign outside this package. Resolved: the package reports the demand and flags E201 for redesign outside the lateral package; the deck-to-panel embeds, tie-downs and all other panels are designed within this package.
