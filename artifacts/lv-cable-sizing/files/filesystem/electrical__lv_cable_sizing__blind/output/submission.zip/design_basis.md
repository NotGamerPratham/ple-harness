```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01 (DoD Building Code, 2022 w/ Change 4) per G-001",
    "precedence": "most restrictive requirement governs; where EDS-26 silent the UFC governs (EDS-26 1.1)"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42,
    "roof_ambient_c": 46,
    "earth_ambient_c": 27.4,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "solar_irradiance_w_m2": 1030
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA daily normals 1991-2020 USW00003145 (Yuma MCAS), highest daily normal max rounded up per EDS-26 5.4",
    "roof_ambient_c": "NOAA + EDS-26 5.4 (+4 K); confirmed in M-501-C note 2",
    "earth_ambient_c": "NOAA annual mean daily average +3 K per EDS-26 5.3.2",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T 2.2 (thermal backfill; native 0.95 rejected per 2.1)",
    "solar_irradiance_w_m2": "EDS-26 5.4"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs (point of government ownership, WRPU letter)",
    "transformer_reset": "No - the count continues across K-13; VD through the transformer is zero and the secondary starts at the same percentage as the primary ended (UFC 3-501-01 3-2.7.4.5.3)",
    "feeder_chain_pct": {
      "LP-1": 2.786,
      "MCC-1": 2.575,
      "DP-2": 1.427,
      "DP-3": 2.581,
      "ATS-1": 2.552
    },
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 101967,
    "termination_usd": 9127,
    "raceway_usd": 48039,
    "material_usd": 99911,
    "labor_usd": 53104,
    "total_usd": 153015
  },
  "duct_assignment": {
    "SE-1": [
      "D3",
      "D4",
      "D5",
      "D6",
      "D7",
      "D8"
    ],
    "F-10": [
      "D1",
      "D2"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": 29.2
}
```

# Design Basis - Wire Schedule, Building 4210 (P-4210)

## Codes of record

The design was prepared against NFPA 70 (NEC) 2023 and the International Building Code 2024, both adopted for this project by UFC 1-200-01 (DoD Building Code, 2022 with Change 4 of 17 Dec 2024), which is the adopting document named on sheet G-001. UFC 1-200-01 directs IBC's references to NFPA 70 to UFC 3-501-01 (27 Nov 2024); UFC 3-501-01 and UFC 3-520-01 (16 Jan 2025) add DoD requirements, and the installation standard EDS-26 Rev 4 (12 Jun 2026) adds the installation's. Energy criteria are UFC 1-200-02 / ASHRAE 90.1. The order of precedence (EDS-26 1.1, G-001) is: where two of these documents set different limits for the same thing, the more restrictive governs, and where EDS-26 is silent the UFC governs. EDS-26 Rev 2 is superseded in its entirety and was not used (its seven-size limit, four-set limit, 5-ft termination allowance, 20 C earth ambient, 12 W/m2.K film coefficient and 2% feeder VD limit were all disregarded).

## Environmental parameters and provenance

Outdoor design dry-bulb 42 C (highest daily normal maximum in the NOAA 1991-2020 normals for station USW00003145, Yuma MCAS, rounded up per EDS-26 5.4). Roof ambient 46 C (outdoor +4 K film allowance, EDS-26 5.4; confirmed by M-501-C note 2). Earth ambient 27.4 C (annual mean of the daily average normals +3 K, EDS-26 5.3.2). Soil/encasement thermal resistivity: the native SP-SM soil design value 0.95 K.m/W was considered and rejected because both duct banks are encased in concrete and surrounded by the fluidised thermal backfill (0.60 K.m/W) for the full trench width (GEO-4210-T 2.2); the concrete encasement is 0.55 K.m/W (2.3). Space ambients are from M-501-C: 40 C ceiling cavity for E-611/612/616 raceway circuits, 45 C for circuits wholly in mechanical room 121 / fire pump room 105, 30 C in the electrical rooms. All ambients exceed the 25 C floor of UFC 3-520-01 3-6.3.2.

## Voltage-drop budget allocation

The calculation starts at the T-1 secondary lugs, the point of government ownership (WRPU service letter; UFC 3-501-01 3-2.7.4.2), at nominal 480 V. The count does **not** restart at the K-13 transformer: voltage drop through the transformer is zero and the secondary starts at the same percentage the primary ended (UFC 3-501-01 3-2.7.4.5.3). The limits are feeder/service 3%, branch 3%, total at the load 5% (UFC 3-501-01 3-2.7), judged cumulatively from the start point.

Feeder chains actually spent: MSB-1 0.93%; MCC-1 (SE-1+F-01) 2.46%; DP-2 (SE-1+F-02) 1.31%; DP-3 (SE-1+F-05) 2.47%; ATS-1 (SE-1+F-10) 2.46%; and the LP-1 chain (SE-1+F-02+F-06+F-07) 2.67% - all within the 3% feeder budget. The ten branch circuits on LP-1 (B-01..B-10) therefore inherit 2.67% and must each hold their own branch drop to 2.33% to stay within the 5% total; the five MCC-1 motor branches (B-11..B-15) inherit 2.46% and the three Building 4212 branches (B-16..B-18) inherit 2.47%. The air-conditioning, VFD, elevator and fire-pump feeders are treated as branch circuits for voltage-drop compliance per UFC 3-501-01 3-2.7.4.3.2. The fire-pump feeder F-03 is governed by NFPA 70 Article 695 (via EDS-26 4.6.3): not more than 5% drop at rated full-load current (cumulative 1.22% - OK) and not more than 15% at locked-rotor current (cumulative 2.60% - OK), both from the same start point.

## Service-entrance sizing decision

The service-entrance conductors SE-1 are sized to the ampacity of the main bus of the service equipment (2000 A), not the 1600 A main device, per UFC 3-501-01 3-2.3.3 and EDS-26 2.2. The 1500 kVA pad transformer T-1 and MSB-1 each accept a largest conductor of 600 kcmil on up to six terminals per phase. Six parallel sets are required to reach the 2000 A bus ampacity within the duct-bank ampacity; the cheapest compliant arrangement is six parallel sets of 500 kcmil copper (the smallest size whose DB-1 Neher-McGrath ampacity, with the F-10 ducts loaded, reaches 2000 A - 359 A/set x 6 = 2154 A), one set per duct. 400 kcmil Cu x6 does not reach 2000 A in DB-1, and 500 kcmil is cheaper than 600 kcmil, so 500 kcmil Cu x6 is selected. The voltage-drop load used for SE-1 is the 1600 A service device rating (EDS-26 2.3 - either reading accepted; this one is stated on the schedule).

## Duct-bank assignment

DB-1 carries the service entrance SE-1 and the standby feeder F-10. Of DB-1's twelve 5-in EPC-40 ducts, ten are available (D11 owner-reserve, D12 existing site-lighting feeder). SE-1 occupies D3, D4, D5, D6, D7, D8 (six ducts, spread to the middle and lower rows to share the mutual-heating load) and F-10 occupies D1, D2. The mutual-heating rise from the loaded bank reaches about 29 K at the most-loaded SE-1 duct; this is built into the Neher-McGrath ampacity (each duct's W_j computed at the circuit's connected load divided by its sets, EDS-26 5.3.4), so the SE-1 ampacity of 359 A/set already accounts for F-10's heat. DB-2 (three available 4-in ducts E1, E2, E3; E4 reserved for comms) carries only F-05 to Building 4212 in three parallel sets, one per duct.

## Material and standardisation decisions

Conductors #6 AWG and smaller are copper per UFC 3-520-01 3-6.3.1; aluminium of equivalent ampacity is used for #4 AWG and larger where the terminations are listed AL/CU (all terminations on this project are). Equipment grounding conductors are copper throughout (EDS-26 3.2). Aluminium was selected for the long, large feeders (F-01, F-04, F-05, F-07, F-08, F-09, F-12, F-13) where it gave the lowest installed cost at equal ampacity; copper was retained for the standby feeder F-10 (aluminium 500 kcmil x2 could not reach 600 A in DB-1 alongside the loaded service, and 350 kcmil Cu x2 was the cheapest compliant duct-bank choice) and where the termination size cap, the 1/0 parallel minimum, or the short length made aluminium uneconomic. The standardisation limit of EDS-26 3.4.2 (no more than five distinct phase-conductor sizes larger than #1 AWG) is met with exactly five: 3/0, 300 kcmil, 350 kcmil, 500 kcmil and 600 kcmil. (The transformer primary feeder F-06 uses two 3/0 Cu sets rather than a single 400 kcmil set specifically to avoid adding a sixth size.) No more than six parallel sets are used on any circuit (EDS-26 3.4.4) and no conductor smaller than 1/0 AWG is run in parallel.

## Cost ledger

Installed cost of the conductor package is USD 153015 (material USD 99911, labour USD 53104), at the project's own unit prices (Cascadia Wire price list 2026 and the P-4210 unit price book). The ledger comprises conductor (phase, neutral and EGC) USD 101967, terminations USD 9127, and interior rigid-steel conduit USD 48039; duct banks and the roof cable tray are existing and carry no installed cost in this scope. The campus quantity break (6 percent off the installed conductor price where the installed conductor length reaches 38,000 ft) applies - 40001 ft of conductor was installed - and is shown as its own line. Material and labour are carried separately throughout and add to the total.
