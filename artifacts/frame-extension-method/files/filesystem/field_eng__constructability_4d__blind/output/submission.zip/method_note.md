# Construction Method Package: Reinforced Concrete Frame Extension

## Attribution

The building in this corpus — its storey elevations, its column grid and sections, its slab thickness and its stair cores — is derived from:
> LivingBIM Dataset: As-designed and As-built Dataset for an Academic Building including BIM 3d models, Point Clouds, and Panoramic Images. DOI 10.5281/zenodo.17934615. Licensed **CC BY 4.0**.
This attribution and the CC BY 4.0 conditions are carried with all reproductions from the design schedules.

## 1. Document Precedence and Hierarchy

Where documents in the project corpus disagree, a rigorous governing hierarchy is established and strictly maintained:
- **Temporary Works Procedure TWP-09 Revision C** governs absolutely over the superseded Revision B. Revision B is retained purely as historical shop-issue record and is not in force; its superseded parameters (such as 310-day programme, 10 gangs, 12 crane hours/shift, 10-ft reshoring spacing, and striking without reshoring) are completely rejected and excluded.
- **Activity Durations and Precedences:** The issued `programme/activity_list.csv` governs over `SUPERSEDED_baseline_programme_revA.csv`. Durations are maintained exactly as issued, with `finish_day = start_day + duration_days`.
- **Adopted Technical Criteria:** Where specific technical criteria are referenced, the five adopted public standards govern their respective scopes: 29 CFR 1926.451 for access scaffolds, 29 CFR 1926.703 for cast-in-place concrete falsework and formwork removal, 29 CFR 1926.1408 for crane power line proximity safety, 29 CFR 1926.250 for site material storage, and 29 CFR 1926.34 for continuous maintenance of two unobstructed means of egress.
- **Excluded Scopes:** External document MS-14 (east facade curtain wall replacement) represents a separate, subsequent contract scope and contributes zero governing requirements to this frame package.

## 2. Striking and Reshoring Methodology

The adopted striking methodology rigorously follows TWP-09 Clause 6.3 and 29 CFR 1926.703(e)(1)(i) via early-age striking under continuous reshoring:
- **Early-Strike Thresholds:** Slabs are cast with design mixes specified in `catalogue/concrete_mix_schedule.csv`. Zones in bands A through D utilize mix `M40-PUMP` (early-strike age of 7 days), while zones in bands E through G utilize high-early mix `M50-HE` (early-strike age of 4 days).
- **Reshoring Installation and Sizing:** Primary formwork and shores are struck only upon achieving the mix's early-strike age. In exact accordance with 29 CFR 1926.703(b)(10), reshores are erected as the original shores are removed. Reshoring consists of `RS-16` steel posts placed at an 8.0-ft by 8.0-ft regular grid in both orthogonal directions (Clause 6.4).
- **Compound Inventory Accounting:** Striking the primary formwork assemblies immediately frees 100% of the zone's primary shoring stock back to the site compound. During the subsequent curing period, reshores occupy only 25% of the zone's plan area against compound capacity (Clause 8.3).
- **Full-Strength Removal:** In accordance with 29 CFR 1926.703(e)(2) and TWP-09 Clause 6.4, reshore posts remain undisturbed until the supported slab attains its full-strength age of 28 calendar days from concrete placement.

## 3. Governing Constraints by Structural Zone

Each structural zone across levels L2, L3, and L4 is governed by unique constructability and safety criteria:
- **Band A (Z-A-N and Z-A-S):** Zone `Z-A-N` houses an essential permanent stair core; under TWP-09 Clause 7.3 and 29 CFR 1926.34, no more than one stair-core zone site-wide may be shored simultaneously to guarantee two open escape routes. Furthermore, Level 2 sits directly over active ground floor occupants (`site/existing_occupation.csv`), requiring a 15 psf overhead protective deck (yielding 387.6 psf total shoring load) and medium-duty scaffold (1000 lb/bay rating, 3 planks per bay). Zone `Z-A-S` carries identical shoring and medium-duty scaffold criteria on L2, with lateral stability governed by 2% notional vertical gravity load (6025.6 lb demand).
- **Band B (Z-B-N and Z-B-S):** These zones encompass the largest slab plan areas (1227.0 sf and 1177.8 sf, 5 laydown units). Zone `Z-B-S` contains the second stair core, strictly constrained to sequence non-concurrently with Z-A-N and Z-E-S shoring. Zone `Z-B-N` generates the highest lateral stability demand on site (9511.7 lb on L2), requiring three bays of `XB-1` cross-bracing (12000 lb capacity). Both L2 zones include protective decks and medium-duty scaffolds.
- **Band C (Z-C-N and Z-C-S):** The eastern boundary of the occupied ground floor. L2 requires protective decks and medium-duty perimeter scaffolds. Placement is executed via concrete pump.
- **Band D (Z-D-N and Z-D-S):** Unoccupied below (L2 shoring load 372.6 psf, light-duty scaffold 750 lb/bay). Columns C-L*-089-020 and C-L*-089-071 are heavy 30"x30" sections weighing 13,665 to 13,674 lb, establishing the critical site-wide maximum pick. The crane at central position `CP-C` operates at a 78.55 ft radius, providing 16,114 lb rated capacity to safely exceed demand.
- **Band E (Z-E-N and Z-E-S):** Beyond pump reach; placed via crane and bucket utilizing `M50-HE` concrete (75 psf construction live load, 397.6 psf shoring design load). Slab edge landing requires heavy-duty scaffolds (1750 lb/bay, 5 planks per bay, system `SF-5`). Zone `Z-E-S` carries the third stair core, strictly staggered. Crane bucket hoisting demands up to 8.29 crane hours across 2 pouring days.
- **Bands F and G (Z-F-N, Z-F-S, Z-G-N, Z-G-S):** Crane-and-bucket placement with heavy-duty scaffolds (`SF-5`). Band G represents the maximum operating radius from `CP-C` (102.6 ft), where rated crane capacity (9,797 lb) safely accommodates the 8,752 lb precast column picks.

## 4. Engineering Safety Margins

Robust structural and operational margins have been designed into every system:
- **Shoring Posts:** Shore posts are standardized to `SP-16` (extension capacity 16.0 ft vs required 13.84 ft). On a 3.5-ft grid under 397.6 psf load, post load is 4870.6 lb versus 6000.0 lb rated capacity, providing an 18.8% safety reserve. On a 4.0-ft grid under 372.6 psf load, post load is 5961.6 lb, safely within rated capacity.
- **Lateral Bracing:** Bracing bays utilizing `XB-1` tension/compression cross-braces provide 8000 lb (2 bays) or 12000 lb (3 bays), exceeding peak lateral demands (5792 to 9512 lb) with margins between 20.9% and 34.0%.
- **Crane Operations & Power Line Safety:** From standing position `CP-C` (98.0, 118.0), crane capacity exceeds peak picks across all zones (margin of 17.8% on the heaviest 13.67-kip pick at Band D, and 11.9% at Band G). For the 34.5 kV uninsulated distribution line at 155 ft offset, Option (3) is adopted: the Table A clearance is 10.0 ft, while the crane's maximum physical reach of 140.0 ft establishes a permanent minimum clearance of 15.0 ft, providing a 50% safety buffer over statutory clearance. Demarcation is formally set at 140.0 ft.
- **Access Scaffolds:** All working decks feature 4:1 capacity factors (`PL-95` plank assemblies rated at 3000 to 7500 lb). Scaffolds are securely tied to the structure at specified vertical intervals (13.0 ft and 32.5 ft for `SF-3`; 19.5 ft and 45.5 ft for `SF-5`) with top ties placed within the 4:1 height from the working deck. Mudsill bearing pressures do not exceed 1200 psf, well within the 2000 psf allowable limit (40% buffer).
- **Programme Float:** The complete 42 zone-lift programme finishes on Day 197, providing 53 calendar days of float (21.2% buffer) ahead of the Day 250 contract completion deadline.
