# Foundation Feasibility and Optimisation Matrix

Cattail Run Data Campus, Phase 1. Per pad and per foundation: demand, bearing check, predicted settlement, shear-wall stability, governing constraint, and the shallow-versus-improved decision with the cost of both alternatives.


## CR-P1 — Light Industrial, Public (FS=3.5, f'c=4000 psi, w/cm<=0.5, sulfate=0.14% -> S1)
Bearing elevation: 42 in below finished grade (frost; AFI=556>500). Bearing stratum I. Decision: **IMPROVED (aggregate piers)**. Spread-only pad cost $180,648; improved pad cost $105,264 (excl. mobilisation). Pad governing constraint: BEARING.


| Tag | Service P (k) | B x L (in) | t (in) | q_net (ksf) | q_allow (ksf) | s (in) | Pier count x depth | alpha | top-of-pier (psf) | Governing |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 610 | 132 x 132 | 27 | 5.11 | 5.42 | 0.662 | 9 x 8 ft | 0.365 | 12894 | BEARING |
| F2 | 1180 | 180 x 180 | 39 | 5.35 | 5.65 | 0.712 | 19 x 8 ft | 0.414 | 12179 | SETTLEMENT |
| F3 | 1420 | 195 x 195 | 42 | 5.49 | 5.73 | 0.731 | 24 x 8 ft | 0.446 | 11769 | SETTLEMENT |
| F4 | 980 | 165 x 165 | 33 | 5.27 | 5.57 | 0.748 | 14 x 8 ft | 0.363 | 13308 | SETTLEMENT |
| F5 | 520 | 123 x 123 | 24 | 5.01 | 5.39 | 0.633 | 8 x 9 ft | 0.374 | 12435 | ANGULAR_DISTORTION |
| W1 | 1650 | 174 x 288 | 30 | 4.82 | 4.99 | 0.735 | 26 x 9 ft | 0.367 | 12171 | ANGULAR_DISTORTION |

**W1 shear-wall stability:** sliding FS=2.53 (>=1.5); resultant eccentricity=6.40 in vs B/6=29.00 in (middle third); uplift FS=3.11 (>=1.5).

**Angular distortion between adjacent units:**
 F1-F2 0.050 in / 24 ft = 0.00017 (limit 0.00200) OK; 
 F2-F3 0.019 in / 20 ft = 0.00008 (limit 0.00200) OK; 
 F3-F4 0.017 in / 16 ft = 0.00009 (limit 0.00200) OK; 
 F4-F5 0.114 in / 12 ft = 0.00079 (limit 0.00200) OK; 
 F5-W1 0.102 in / 5 ft = 0.00169 (limit 0.00200) OK; 



**Decision:** IMPROVED. Spread-only cost $180,648 would require very large footings on the soft Stratum I (Es=110 ksf); improved cost $105,264 (incl. piers, working platform, one modulus test) is lower, so the pad is improved.


## CR-P2 — Light Industrial, Public (FS=3.5, f'c=4500 psi, w/cm<=0.45, sulfate=0.23% -> S2)
Bearing elevation: 42 in below finished grade (frost; AFI=556>500). Bearing stratum I. Decision: **IMPROVED (aggregate piers)**. Spread-only pad cost $285,763; improved pad cost $111,084 (excl. mobilisation). Pad governing constraint: BEARING.


| Tag | Service P (k) | B x L (in) | t (in) | q_net (ksf) | q_allow (ksf) | s (in) | Pier count x depth | alpha | top-of-pier (psf) | Governing |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 647 | 135 x 135 | 27 | 5.18 | 5.53 | 0.794 | 9 x 10 ft | 0.349 | 13507 | SETTLEMENT |
| F2 | 1251 | 183 x 183 | 39 | 5.48 | 5.75 | 0.846 | 19 x 9 ft | 0.401 | 12790 | SETTLEMENT |
| F3 | 1505 | 198 x 198 | 42 | 5.64 | 5.83 | 0.850 | 25 x 8 ft | 0.451 | 11972 | SETTLEMENT |
| F4 | 1039 | 168 x 168 | 33 | 5.39 | 5.68 | 0.851 | 15 x 8 ft | 0.376 | 13241 | SETTLEMENT |
| F5 | 551 | 123 x 123 | 24 | 5.31 | 5.48 | 0.774 | 8 x 8 ft | 0.374 | 13115 | SETTLEMENT |
| W1 | 1749 | 180 x 288 | 33 | 4.95 | 5.14 | 0.853 | 27 x 8 ft | 0.368 | 12425 | SETTLEMENT |

**W1 shear-wall stability:** sliding FS=2.52 (>=1.5); resultant eccentricity=6.40 in vs B/6=30.00 in (middle third); uplift FS=3.11 (>=1.5).

**Angular distortion between adjacent units:**
 F1-F2 0.052 in / 24 ft = 0.00018 (limit 0.00200) OK; 
 F2-F3 0.004 in / 20 ft = 0.00002 (limit 0.00200) OK; 
 F3-F4 0.001 in / 16 ft = 0.00000 (limit 0.00200) OK; 
 F4-F5 0.077 in / 12 ft = 0.00054 (limit 0.00200) OK; 
 F5-W1 0.080 in / 5 ft = 0.00133 (limit 0.00200) OK; 



**Decision:** IMPROVED. Spread-only cost $285,763 would require very large footings on the soft Stratum I (Es=85 ksf); improved cost $111,084 (incl. piers, working platform, one modulus test) is lower, so the pad is improved.


## CR-P3 — Light Industrial, Public (FS=3.5, f'c=4000 psi, w/cm<=0.5, sulfate=0.07% -> S0)
Bearing elevation: 42 in below finished grade (frost; AFI=556>500). Bearing stratum I. Decision: **SPREAD footings only**. Spread-only pad cost $29,347; improved pad cost $69,054 (excl. mobilisation). Pad governing constraint: SETTLEMENT.


| Tag | Service P (k) | B x L (in) | t (in) | q_net (ksf) | q_allow (ksf) | s (in) | Pier count x depth | alpha | top-of-pier (psf) | Governing |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 439 | 108 x 108 | 21 | 5.48 | 5.77 | 0.705 | - | - | - | BEARING |
| F2 | 850 | 144 x 144 | 30 | 5.98 | 6.17 | 0.972 | - | - | - | SETTLEMENT |
| F3 | 1022 | 168 x 168 | 33 | 5.30 | 6.47 | 0.966 | - | - | - | SETTLEMENT |
| F4 | 706 | 141 x 141 | 27 | 5.18 | 6.14 | 0.963 | - | - | - | SETTLEMENT |
| F5 | 374 | 102 x 102 | 21 | 5.24 | 5.71 | 0.888 | - | - | - | BEARING |
| W1 | 1188 | 132 x 288 | 24 | 4.56 | 5.13 | 0.972 | - | - | - | SETTLEMENT |

**W1 shear-wall stability:** sliding FS=2.62 (>=1.5); resultant eccentricity=6.40 in vs B/6=22.00 in (middle third); uplift FS=3.11 (>=1.5).

**Angular distortion between adjacent units:**
 F1-F2 0.267 in / 24 ft = 0.00093 (limit 0.00200) OK; 
 F2-F3 0.006 in / 20 ft = 0.00003 (limit 0.00200) OK; 
 F3-F4 0.003 in / 16 ft = 0.00001 (limit 0.00200) OK; 
 F4-F5 0.075 in / 12 ft = 0.00052 (limit 0.00200) OK; 
 F5-W1 0.084 in / 5 ft = 0.00140 (limit 0.00200) OK; 



**Decision:** SPREAD. Stratum I is stiffer here (Es=210 ksf); spread cost $29,347 is well below the improved cost $69,054, so spread footings alone are used.


## CR-P4 — Apartments, Office (FS=3.0, f'c=4000 psi, w/cm<=0.5, sulfate=0.11% -> S1)
Bearing elevation: 42 in below finished grade (frost; AFI=556>500). Bearing stratum I. Decision: **SPREAD footings only**. Spread-only pad cost $55,591; improved pad cost $59,708 (excl. mobilisation). Pad governing constraint: SETTLEMENT.


| Tag | Service P (k) | B x L (in) | t (in) | q_net (ksf) | q_allow (ksf) | s (in) | Pier count x depth | alpha | top-of-pier (psf) | Governing |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 384 | 114 x 114 | 21 | 4.31 | 6.32 | 0.945 | - | - | - | SETTLEMENT |
| F2 | 743 | 192 x 192 | 30 | 2.98 | 6.73 | 0.961 | - | - | - | SETTLEMENT |
| F3 | 895 | 237 x 237 | 33 | 2.38 | 7.03 | 0.963 | - | - | - | SETTLEMENT |
| F4 | 617 | 201 x 201 | 27 | 2.27 | 6.79 | 0.959 | - | - | - | SETTLEMENT |
| F5 | 328 | 138 x 138 | 21 | 2.53 | 6.42 | 0.979 | - | - | - | SETTLEMENT |
| W1 | 1040 | 285 x 288 | 27 | 1.90 | 7.34 | 0.980 | - | - | - | SETTLEMENT |

**W1 shear-wall stability:** sliding FS=2.67 (>=1.5); resultant eccentricity=6.40 in vs B/6=47.50 in (middle third); uplift FS=3.72 (>=1.5).

**Angular distortion between adjacent units:**
 F1-F2 0.016 in / 24 ft = 0.00005 (limit 0.00200) OK; 
 F2-F3 0.002 in / 20 ft = 0.00001 (limit 0.00200) OK; 
 F3-F4 0.004 in / 16 ft = 0.00002 (limit 0.00200) OK; 
 F4-F5 0.020 in / 12 ft = 0.00014 (limit 0.00200) OK; 
 F5-W1 0.001 in / 5 ft = 0.00001 (limit 0.00200) OK; 



**Decision:** SPREAD. Stratum I is stiffer here (Es=130 ksf); spread cost $55,591 is well below the improved cost $59,708, so spread footings alone are used.


## CR-P5 — Warehouse (FS=2.5, f'c=5000 psi, w/cm<=0.4, sulfate=0.05% -> S0)
Bearing elevation: 42 in below finished grade (frost; AFI=556>500). Bearing stratum I. Decision: **SPREAD footings only**. Spread-only pad cost $16,296; improved pad cost $45,971 (excl. mobilisation). Pad governing constraint: BEARING.


| Tag | Service P (k) | B x L (in) | t (in) | q_net (ksf) | q_allow (ksf) | s (in) | Pier count x depth | alpha | top-of-pier (psf) | Governing |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 336 | 81 x 81 | 18 | 7.41 | 7.90 | 0.531 | - | - | - | BEARING |
| F2 | 649 | 111 x 111 | 24 | 7.65 | 8.28 | 0.697 | - | - | - | BEARING |
| F3 | 781 | 120 x 120 | 27 | 7.88 | 8.42 | 0.807 | - | - | - | BEARING |
| F4 | 539 | 102 x 102 | 21 | 7.52 | 8.15 | 0.774 | - | - | - | BEARING |
| F5 | 286 | 75 x 75 | 18 | 7.37 | 7.84 | 0.710 | - | - | - | BEARING |
| W1 | 908 | 78 x 288 | 18 | 5.87 | 6.25 | 0.716 | - | - | - | BEARING |

**W1 shear-wall stability:** sliding FS=2.72 (>=1.5); resultant eccentricity=6.40 in vs B/6=13.00 in (middle third); uplift FS=3.00 (>=1.5).

**Angular distortion between adjacent units:**
 F1-F2 0.166 in / 24 ft = 0.00058 (limit 0.00200) OK; 
 F2-F3 0.110 in / 20 ft = 0.00046 (limit 0.00200) OK; 
 F3-F4 0.033 in / 16 ft = 0.00017 (limit 0.00200) OK; 
 F4-F5 0.064 in / 12 ft = 0.00044 (limit 0.00200) OK; 
 F5-W1 0.006 in / 5 ft = 0.00010 (limit 0.00200) OK; 



**Decision:** SPREAD. Stratum I is stiffer here (Es=250 ksf); spread cost $16,296 is well below the improved cost $45,971, so spread footings alone are used.


## CR-P6 — Light Industrial, Public (FS=3.5, f'c=4500 psi, w/cm<=0.45, sulfate=0.26% -> S2)
Bearing elevation: 42 in below finished grade (frost; AFI=556>500). Bearing stratum I. Decision: **IMPROVED (aggregate piers)**. Spread-only pad cost $191,040; improved pad cost $107,710 (excl. mobilisation). Pad governing constraint: BEARING.


| Tag | Service P (k) | B x L (in) | t (in) | q_net (ksf) | q_allow (ksf) | s (in) | Pier count x depth | alpha | top-of-pier (psf) | Governing |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 622 | 132 x 132 | 27 | 5.21 | 5.47 | 0.698 | 9 x 11 ft | 0.365 | 13129 | BEARING |
| F2 | 1204 | 180 x 180 | 36 | 5.45 | 5.69 | 0.758 | 19 x 9 ft | 0.414 | 12384 | SETTLEMENT |
| F3 | 1448 | 195 x 195 | 42 | 5.60 | 5.77 | 0.778 | 24 x 8 ft | 0.446 | 11984 | SETTLEMENT |
| F4 | 1000 | 165 x 165 | 33 | 5.38 | 5.62 | 0.788 | 14 x 8 ft | 0.363 | 13551 | SETTLEMENT |
| F5 | 530 | 123 x 123 | 24 | 5.11 | 5.43 | 0.678 | 8 x 8 ft | 0.374 | 12661 | ANGULAR_DISTORTION |
| W1 | 1683 | 177 x 288 | 30 | 4.83 | 5.07 | 0.767 | 26 x 8 ft | 0.360 | 12362 | SETTLEMENT |

**W1 shear-wall stability:** sliding FS=2.53 (>=1.5); resultant eccentricity=6.40 in vs B/6=29.50 in (middle third); uplift FS=3.11 (>=1.5).

**Angular distortion between adjacent units:**
 F1-F2 0.060 in / 24 ft = 0.00021 (limit 0.00200) OK; 
 F2-F3 0.020 in / 20 ft = 0.00008 (limit 0.00200) OK; 
 F3-F4 0.009 in / 16 ft = 0.00005 (limit 0.00200) OK; 
 F4-F5 0.110 in / 12 ft = 0.00076 (limit 0.00200) OK; 
 F5-W1 0.089 in / 5 ft = 0.00148 (limit 0.00200) OK; 



**Decision:** IMPROVED. Spread-only cost $191,040 would require very large footings on the soft Stratum I (Es=95 ksf); improved cost $107,710 (incl. piers, working platform, one modulus test) is lower, so the pad is improved.
