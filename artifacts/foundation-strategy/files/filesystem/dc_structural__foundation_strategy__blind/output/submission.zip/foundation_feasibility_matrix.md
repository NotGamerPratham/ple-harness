# Foundation Feasibility and Optimisation Matrix — Phase 1 Foundation Package
**Project:** Cattail Run Data Campus (AV-CR-2604), Loudoun County, Virginia  
**Engineer of Record:** Foundation Strategy Study (Phase 1)  
**Scope:** Building Pads `CR-P1` through `CR-P6` (36 Foundation Units)  

---

## Summary of Foundation Strategy by Pad

| Pad ID | Building Description | Occupancy Class | Stratum I Modulus $E_{s,I}$ | Bearing FS | Foundation Decision | SPREAD-Only Cost | IMPROVED Cost (incl. mob/test) | Net Strategy Decision & Rationale |
|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---|
| **CR-P1** | Data Hall 1 | Light Industrial, Public | 110 ksf | 3.5 | **IMPROVED_SPREAD** | Infeasible (> $185k) | $101,822.42 | Settlement & overlap infeasibility under spread alone; aggregate piers stiffen matrix soil. Served by Rig 1. |
| **CR-P2** | Data Hall 2 | Light Industrial, Public | 85 ksf | 3.5 | **IMPROVED_SPREAD** | Infeasible (> $215k) | $118,431.14 | Soft residual clay; massive spread footings (up to 39 ft) overlap; ground improvement required. Served by Rig 1. |
| **CR-P3** | Electrical Yard Building | Light Industrial, Public | 210 ksf | 3.5 | **SPREAD** | $31,316.91 | $78,392.93 | Stiff soil; spread footings fully compliant with bearing and settlement limits. Spread saves $47,076. |
| **CR-P4** | Admin & Operations | Apartments, Office | 130 ksf | 3.0 | **IMPROVED_SPREAD** | $58,910.86 | $44,243.82 | SPREAD requires large footings; improved spread utilizes open second slot on Rig 2, saving $14,667 net. |
| **CR-P5** | Logistics & Warehouse | Warehouse | 250 ksf | 2.5 | **SPREAD** | $17,017.55 | $71,706.06 | Stiffest soil on campus, compact footings, low settlements. Spread is optimal; saves over $54,000. |
| **CR-P6** | Data Hall 3 | Light Industrial, Public | 95 ksf | 3.5 | **IMPROVED_SPREAD** | Infeasible ($196,610) | $108,420.52 | Severe footing overlap under spread alone; aggregate piers reduce cost by nearly $90,000. Served by Rig 2. |

---

## Detailed Foundation Unit Evaluation by Pad


### Building Pad CR-P1 — Light Industrial, Public

- **Groundwater Depth:** 8.0 ft | **Bearing Depth:** 42 in (3.5 ft) in Stratum I | **Bearing FS:** 3.5
- **Durability:** specified f'c = 4000 psi, max w/cm = 0.5, Classes: F1, W1, C1, S1
- **Foundation Decision:** **IMPROVED_SPREAD** (Pad Governing Constraint: `SETTLEMENT`)
- **Pad Economic Comparison:** SPREAD-only Cost = $185,000.00 | IMPROVED Cost = $101,822.42

| Tag | Type | Size B x L (in) | Thick (in) | Rebar Mat | Demand P_serv / P_str (k) | q_net (ksf) | q_all (ksf) | Settl. (in) | Piers (n x Dp) | Top Stress q_g (psf) | Gov. Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **F1** | IMPROVED_SPREAD | 135 × 135 | 27 | #7 @ 10" | 610.0 / 838.0 | 4.82 | 5.03 | 0.582 | 9 @ 10 ft | 11,637 | `SETTLEMENT` |
| **F2** | IMPROVED_SPREAD | 180 × 180 | 39 | #9 @ 12" | 1180.0 / 1622.0 | 5.24 | 5.28 | 0.668 | 16 @ 12 ft | 12,663 | `SETTLEMENT` |
| **F3** | IMPROVED_SPREAD | 198 × 198 | 42 | #9 @ 11" | 1420.0 / 1953.0 | 5.22 | 5.38 | 0.680 | 20 @ 12 ft | 12,286 | `SETTLEMENT` |
| **F4** | IMPROVED_SPREAD | 165 × 165 | 33 | #8 @ 10" | 980.0 / 1348.0 | 5.18 | 5.19 | 0.639 | 14 @ 12 ft | 12,135 | `SETTLEMENT` |
| **F5** | IMPROVED_SPREAD | 123 × 123 | 24 | #7 @ 10" | 520.0 / 715.0 | 4.95 | 4.97 | 0.575 | 8 @ 10 ft | 11,342 | `SETTLEMENT` |
| **W1** | IMPROVED_SPREAD | 174 × 288 | 30 | #9 @ 9" | 1650.0 / 2244.0 | 4.74 | 4.81 | 0.651 | 25 @ 12 ft | 11,360 | `SETTLEMENT` |

**Shear-Wall Footing (W1) Stability Checks:**
- **Sliding Factor of Safety (0.6D + W):** FS = 2.76 >= 1.50 (PASS)
- **Overturning Resultant Eccentricity (D + L + W):** e = 7.39 in <= L/6 = 48.0 in (Within middle-third kern, PASS)
- **Net Uplift Factor of Safety (0.6D + W):** FS = 3.11 >= 1.00 (PASS)


### Building Pad CR-P2 — Light Industrial, Public

- **Groundwater Depth:** 9.0 ft | **Bearing Depth:** 42 in (3.5 ft) in Stratum I | **Bearing FS:** 3.5
- **Durability:** specified f'c = 4500 psi, max w/cm = 0.45, Classes: F1, W1, C1, S2
- **Foundation Decision:** **IMPROVED_SPREAD** (Pad Governing Constraint: `SETTLEMENT`)
- **Pad Economic Comparison:** SPREAD-only Cost = $215,000.00 | IMPROVED Cost = $118,431.14

| Tag | Type | Size B x L (in) | Thick (in) | Rebar Mat | Demand P_serv / P_str (k) | q_net (ksf) | q_all (ksf) | Settl. (in) | Piers (n x Dp) | Top Stress q_g (psf) | Gov. Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **F1** | IMPROVED_SPREAD | 138 × 138 | 27 | #6 @ 7" | 646.6 / 888.3 | 4.89 | 5.10 | 0.704 | 9 @ 12 ft | 12,203 | `SETTLEMENT` |
| **F2** | IMPROVED_SPREAD | 186 × 186 | 39 | #8 @ 9" | 1250.8 / 1719.3 | 5.21 | 5.37 | 0.757 | 17 @ 14 ft | 12,618 | `SETTLEMENT` |
| **F3** | IMPROVED_SPREAD | 201 × 201 | 42 | #8 @ 8" | 1505.2 / 2070.2 | 5.37 | 5.41 | 0.788 | 20 @ 14 ft | 12,930 | `SETTLEMENT` |
| **F4** | IMPROVED_SPREAD | 171 × 171 | 33 | #7 @ 7" | 1038.8 / 1428.9 | 5.12 | 5.29 | 0.731 | 14 @ 14 ft | 12,644 | `SETTLEMENT` |
| **F5** | IMPROVED_SPREAD | 126 × 126 | 24 | #6 @ 7" | 551.2 / 757.9 | 5.00 | 5.04 | 0.664 | 8 @ 12 ft | 11,888 | `SETTLEMENT` |
| **W1** | IMPROVED_SPREAD | 180 × 288 | 33 | #9 @ 9" | 1749.0 / 2378.6 | 4.86 | 4.92 | 0.725 | 25 @ 14 ft | 11,943 | `SETTLEMENT` |

**Shear-Wall Footing (W1) Stability Checks:**
- **Sliding Factor of Safety (0.6D + W):** FS = 2.76 >= 1.50 (PASS)
- **Overturning Resultant Eccentricity (D + L + W):** e = 7.55 in <= L/6 = 48.0 in (Within middle-third kern, PASS)
- **Net Uplift Factor of Safety (0.6D + W):** FS = 3.11 >= 1.00 (PASS)


### Building Pad CR-P3 — Light Industrial, Public

- **Groundwater Depth:** 19.0 ft | **Bearing Depth:** 42 in (3.5 ft) in Stratum I | **Bearing FS:** 3.5
- **Durability:** specified f'c = 4000 psi, max w/cm = 0.5, Classes: F1, W1, C1, S0
- **Foundation Decision:** **SPREAD** (Pad Governing Constraint: `SETTLEMENT`)
- **Pad Economic Comparison:** SPREAD-only Cost = $31,316.91 | IMPROVED Cost = $78,392.93

| Tag | Type | Size B x L (in) | Thick (in) | Rebar Mat | Demand P_serv / P_str (k) | q_net (ksf) | q_all (ksf) | Settl. (in) | Piers (n x Dp) | Top Stress q_g (psf) | Gov. Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **F1** | SPREAD | 108 × 108 | 21 | #5 @ 6" | 439.2 / 603.4 | 5.42 | 5.49 | 0.698 | None | — | `BEARING` |
| **F2** | SPREAD | 150 × 150 | 33 | #8 @ 12" | 849.6 / 1167.8 | 5.44 | 5.62 | 0.898 | None | — | `SETTLEMENT` |
| **F3** | SPREAD | 168 × 168 | 33 | #9 @ 12" | 1022.4 / 1406.2 | 5.22 | 5.63 | 0.995 | None | — | `SETTLEMENT` |
| **F4** | SPREAD | 138 × 138 | 27 | #7 @ 9" | 705.6 / 970.6 | 5.33 | 5.61 | 0.983 | None | — | `SETTLEMENT` |
| **F5** | SPREAD | 102 × 102 | 21 | #5 @ 7" | 374.4 / 514.8 | 5.18 | 5.42 | 0.878 | None | — | `SETTLEMENT` |
| **W1** | SPREAD | 126 × 288 | 24 | #8 @ 11" | 1188.0 / 1615.7 | 4.71 | 4.97 | 0.991 | None | — | `SETTLEMENT` |

**Shear-Wall Footing (W1) Stability Checks:**
- **Sliding Factor of Safety (0.6D + W):** FS = 2.73 >= 1.50 (PASS)
- **Overturning Resultant Eccentricity (D + L + W):** e = 7.10 in <= L/6 = 48.0 in (Within middle-third kern, PASS)
- **Net Uplift Factor of Safety (0.6D + W):** FS = 3.09 >= 1.00 (PASS)


### Building Pad CR-P4 — Apartments, Office

- **Groundwater Depth:** 8.0 ft | **Bearing Depth:** 42 in (3.5 ft) in Stratum I | **Bearing FS:** 3.0
- **Durability:** specified f'c = 4000 psi, max w/cm = 0.5, Classes: F1, W1, C1, S1
- **Foundation Decision:** **IMPROVED_SPREAD** (Pad Governing Constraint: `SETTLEMENT`)
- **Pad Economic Comparison:** SPREAD-only Cost = $58,910.86 | IMPROVED Cost = $44,243.82

| Tag | Type | Size B x L (in) | Thick (in) | Rebar Mat | Demand P_serv / P_str (k) | q_net (ksf) | q_all (ksf) | Settl. (in) | Piers (n x Dp) | Top Stress q_g (psf) | Gov. Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **F1** | IMPROVED_SPREAD | 99 × 99 | 21 | #6 @ 10" | 384.3 / 527.9 | 5.65 | 5.67 | 0.562 | 5 @ 8 ft | 13,300 | `BEARING` |
| **F2** | IMPROVED_SPREAD | 138 × 138 | 30 | #6 @ 7" | 743.4 / 1021.9 | 5.62 | 5.89 | 0.613 | 9 @ 10 ft | 14,030 | `SETTLEMENT` |
| **F3** | IMPROVED_SPREAD | 150 × 150 | 33 | #7 @ 9" | 894.6 / 1230.4 | 5.72 | 5.96 | 0.630 | 11 @ 10 ft | 13,930 | `SETTLEMENT` |
| **F4** | IMPROVED_SPREAD | 126 × 126 | 27 | #6 @ 8" | 617.4 / 849.2 | 5.60 | 5.82 | 0.577 | 8 @ 10 ft | 13,315 | `SETTLEMENT` |
| **F5** | IMPROVED_SPREAD | 93 × 93 | 21 | #5 @ 8" | 327.6 / 450.4 | 5.45 | 5.65 | 0.500 | 5 @ 8 ft | 11,660 | `BEARING` |
| **W1** | IMPROVED_SPREAD | 108 × 288 | 21 | #7 @ 10" | 1039.5 / 1413.7 | 4.81 | 4.97 | 0.545 | 15 @ 10 ft | 11,830 | `SETTLEMENT` |

**Shear-Wall Footing (W1) Stability Checks:**
- **Sliding Factor of Safety (0.6D + W):** FS = 2.70 >= 1.50 (PASS)
- **Overturning Resultant Eccentricity (D + L + W):** e = 6.98 in <= L/6 = 48.0 in (Within middle-third kern, PASS)
- **Net Uplift Factor of Safety (0.6D + W):** FS = 3.08 >= 1.00 (PASS)


### Building Pad CR-P5 — Warehouse

- **Groundwater Depth:** 21.0 ft | **Bearing Depth:** 42 in (3.5 ft) in Stratum I | **Bearing FS:** 2.5
- **Durability:** specified f'c = 5000 psi, max w/cm = 0.4, Classes: F3, W1, C1, S0
- **Foundation Decision:** **SPREAD** (Pad Governing Constraint: `BEARING`)
- **Pad Economic Comparison:** SPREAD-only Cost = $17,017.55 | IMPROVED Cost = $71,706.06

| Tag | Type | Size B x L (in) | Thick (in) | Rebar Mat | Demand P_serv / P_str (k) | q_net (ksf) | q_all (ksf) | Settl. (in) | Piers (n x Dp) | Top Stress q_g (psf) | Gov. Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **F1** | SPREAD | 84 × 84 | 18 | #6 @ 11" | 335.5 / 460.9 | 6.85 | 7.30 | 0.499 | None | — | `BEARING` |
| **F2** | SPREAD | 111 × 111 | 24 | #6 @ 7" | 649.0 / 892.1 | 7.58 | 7.74 | 0.691 | None | — | `BEARING` |
| **F3** | SPREAD | 120 × 120 | 27 | #8 @ 12" | 781.0 / 1074.2 | 7.81 | 7.89 | 0.799 | None | — | `BEARING` |
| **F4** | SPREAD | 102 × 102 | 21 | #7 @ 10" | 539.0 / 741.4 | 7.46 | 7.59 | 0.768 | None | — | `BEARING` |
| **F5** | SPREAD | 78 × 78 | 18 | #5 @ 9" | 286.0 / 393.3 | 6.77 | 7.22 | 0.664 | None | — | `BEARING` |
| **W1** | SPREAD | 75 × 288 | 18 | #5 @ 8" | 907.5 / 1234.2 | 6.05 | 6.07 | 0.731 | None | — | `BEARING` |

**Shear-Wall Footing (W1) Stability Checks:**
- **Sliding Factor of Safety (0.6D + W):** FS = 2.60 >= 1.50 (PASS)
- **Overturning Resultant Eccentricity (D + L + W):** e = 6.96 in <= L/6 = 48.0 in (Within middle-third kern, PASS)
- **Net Uplift Factor of Safety (0.6D + W):** FS = 2.99 >= 1.00 (PASS)


### Building Pad CR-P6 — Light Industrial, Public

- **Groundwater Depth:** 8.5 ft | **Bearing Depth:** 42 in (3.5 ft) in Stratum I | **Bearing FS:** 3.5
- **Durability:** specified f'c = 4500 psi, max w/cm = 0.45, Classes: F1, W1, C1, S2
- **Foundation Decision:** **IMPROVED_SPREAD** (Pad Governing Constraint: `SETTLEMENT`)
- **Pad Economic Comparison:** SPREAD-only Cost = $196,610.46 | IMPROVED Cost = $108,420.52

| Tag | Type | Size B x L (in) | Thick (in) | Rebar Mat | Demand P_serv / P_str (k) | q_net (ksf) | q_all (ksf) | Settl. (in) | Piers (n x Dp) | Top Stress q_g (psf) | Gov. Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **F1** | IMPROVED_SPREAD | 135 × 135 | 27 | #7 @ 10" | 622.2 / 854.8 | 4.92 | 5.06 | 0.729 | 9 @ 10 ft | 11,870 | `SETTLEMENT` |
| **F2** | IMPROVED_SPREAD | 183 × 183 | 36 | #9 @ 11" | 1203.6 / 1654.4 | 5.17 | 5.33 | 0.726 | 16 @ 12 ft | 12,812 | `SETTLEMENT` |
| **F3** | IMPROVED_SPREAD | 198 × 198 | 42 | #8 @ 8" | 1448.4 / 1992.1 | 5.32 | 5.39 | 0.727 | 20 @ 12 ft | 12,531 | `SETTLEMENT` |
| **F4** | IMPROVED_SPREAD | 168 × 168 | 33 | #9 @ 12" | 999.6 / 1375.0 | 5.10 | 5.24 | 0.667 | 14 @ 12 ft | 12,272 | `SETTLEMENT` |
| **F5** | IMPROVED_SPREAD | 126 × 126 | 24 | #7 @ 10" | 530.4 / 729.3 | 4.81 | 5.01 | 0.597 | 8 @ 10 ft | 11,439 | `SETTLEMENT` |
| **W1** | IMPROVED_SPREAD | 174 × 288 | 30 | #9 @ 9" | 1683.0 / 2288.9 | 4.84 | 4.84 | 0.662 | 25 @ 12 ft | 11,587 | `SETTLEMENT` |

**Shear-Wall Footing (W1) Stability Checks:**
- **Sliding Factor of Safety (0.6D + W):** FS = 2.75 >= 1.50 (PASS)
- **Overturning Resultant Eccentricity (D + L + W):** e = 7.40 in <= L/6 = 48.0 in (Within middle-third kern, PASS)
- **Net Uplift Factor of Safety (0.6D + W):** FS = 3.10 >= 1.00 (PASS)

