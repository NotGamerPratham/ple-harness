```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 185000.0,
      "improved_cost_usd": 101822.42
    },
    "CR-P2": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 215000.0,
      "improved_cost_usd": 118431.14
    },
    "CR-P3": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 31316.91,
      "improved_cost_usd": 78392.93
    },
    "CR-P4": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 58910.86,
      "improved_cost_usd": 44243.82
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 17017.55,
      "improved_cost_usd": 71706.06
    },
    "CR-P6": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 196610.46,
      "improved_cost_usd": 108420.52
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 462660.4,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC 3-220-10N Soil Mechanics (2005) - Cancelled predecessor volume superseded by UFC 3-220-01 and DM 7.1",
    "UFC 3-220-01N Foundation Design (2005) - Cancelled predecessor volume superseded by UFC 3-220-01 and UFC 3-220-20",
    "AV-CR-2604 Basis of Design Structural Rev 1 - Superseded in its entirety by Basis of Design Structural Rev 3",
    "AV-CR-2604 Geotechnical Addendum 1 - Superseded in its entirety by Geotechnical Data Report Rev 2",
    "NOAA NCEI AFI return period tables 1951-1980 - Superseded by current 1981-2010 normals per AHJ Amendment 3 and RFI-007",
    "Adjacent Parcel Report Broadview Commons 2023 - Off-site report not applicable to Cattail Run per RFI-013",
    "FHWA GEC 6 Shallow Foundations for Bridges - Manual written for highway bridges; facility governed by UFC 3-220-01 and UFC 3-301-01",
    "EM 1110-2-2104 Table 3-1 load factors - Civil works hydraulic structures load factors rejected per AV-CR-2604 load combination memo",
    "Presumptive bearing capacity of 3,000 psf in GDR Rev 2 - Prohibited by Loudoun County AHJ Amendment 4 and UFC 3-220-01 para 2-4.5.2"
  ]
}
```


# Basis of Design Narrative — Foundation Strategy: Spread Footings versus Rammed Aggregate Piers

## 1. Governing Criteria and Documents Reviewed and Set Aside
This foundation strategy report and basis of design governs Phase 1 of the Cattail Run Data Campus in Loudoun County, Virginia, comprising six single-storey building pads (CR-P1 through CR-P6). Each pad carries an instrumented column line of six foundation units (five isolated column footings F1-F5 and one continuous shear-wall footing W1).

### Governing Documents:
1. **Geotechnical Criteria:** UFC 3-220-01 Geotechnical Engineering (2012 with Change 3, 2025), specifically Section 2-4 and Table 2-3 for factors of safety and allowable movements.
2. **Analysis Manuals:** UFC 3-220-20 Foundations and Earth Structures (DM 7.2, 2025) and USACE EM 1110-1-1905 Bearing Capacity of Soils (1992) for bearing capacity and settlement formulation; USACE EM 1110-2-2502 Retaining and Flood Walls (1989) for lateral earth pressures, sliding, and overturning; FHWA GEC 13 Vol. 1 Ground Modification Methods (2017) for rammed aggregate pier design and layered elastic settlement analysis (Equation 5-14).
3. **Structural and Concrete Criteria:** UFC 3-301-01 Structural Engineering (2023 with Change 4, 2025) and ACI 318-19; UFGS 03 30 00 Cast-in-Place Concrete; and UFGS 31 00 00 Earthwork.
4. **Site Reports and Project Instructions:** Harrowgate Geosciences PC Geotechnical Data Report (Rev. 2, 2026-08-14); Vantry Civil Group Site Grading and Groundwater Record (AV-CR-2604 Sheet C-301); Ardent Vale Basis of Design - Structural (Rev. 3); Loudoun County AHJ Amendment Letter (BP-26-11884 / LC-BD-26-0774); and Project RFI Log (AV-CR-2604).

### Documents Reviewed and Set Aside:
- **UFC 3-220-10N (2005) & UFC 3-220-01N (2005):** Cancelled NAVFAC predecessor publications, superseded by UFC 3-220-01 and UFC 3-220-20. Set aside.
- **AV-CR-2604 Basis of Design - Structural Rev. 1:** Superseded in its entirety by Revision 3. Set aside.
- **AV-CR-2604 Geotechnical Addendum 1:** Issued against Revision 1 with preliminary moduli (320/900/2400 ksf) and withdrawn 4,000 psf presumptive pressure. Superseded by Geotechnical Data Report Rev. 2. Set aside.
- **NOAA NCEI AFI Return Periods 1951-1980:** Superseded climate product. Set aside per Loudoun County AHJ Amendment 3 and RFI-007 in favour of the current 1981-2010 normals.
- **Adjacent Parcel Report (Broadview Commons, 2023):** Pertains to a separate property. Set aside for information only per RFI-013.
- **FHWA GEC 6 (Shallow Foundations for Highway Bridges):** Developed for transportation bridge structures; building foundation design is governed by UFC 3-220-01, UFC 3-301-01, and DM 7.2. Set aside.
- **EM 1110-2-2104 Table 3-1 Load Factors:** Specific to civil works hydraulic structures; building foundations are governed by UFC 3-301-01 / ASCE 7 load combinations per the load combination memo.
- **Presumptive Load-Bearing Values:** The 3,000 psf presumptive value in GDR Rev. 2 is explicitly prohibited from final design by Loudoun County AHJ Amendment 4 and UFC 3-220-01 paragraphs 2-4.5.2 and 2-4.6.4 (RFI-009).

---

## 2. Frost Protection, Bearing Elevation, and Stratigraphy
- **Air-Freezing Index & Frost Line Depth:** In accordance with Loudoun County AHJ Amendment 3, the 100-year return period air-freezing index was obtained from NOAA NCEI cooperative station USC00444909 (Lincoln, VA) using the current 1981-2010 normals period (AFI = 556 degree F-days). Because the index exceeds 500 degree F-days, the governing minimum depth of the foundation bearing surface below finished grade is 42 inches (3.5 ft). Under the superseded 1951-1980 product (AFI = 416 degree F-days), the depth would have erroneously been 30 inches.
- **Bearing Elevation:** Per Basis of Design Rev. 3 Section 4, all foundations on a building pad share a single uniform bearing elevation. A bearing depth of Df = 42 inches (3.5 ft) is selected for all thirty-six foundations across all six pads. This exactly satisfies the frost protection depth, avoids triggering construction dewatering (piezometer groundwater levels range from 8.0 to 21.0 ft below finished grade), and remains within the vertical excavation cut limit (<= 4.0 ft), minimizing excavation and backfill costs.
- **Bearing Stratum & Stratigraphy:** At Df = 3.5 ft, all footings bear within Stratum I (lean to silty clay CL-ML residual soils, total unit weight gamma = 118 pcf, effective friction angle phi = 26 deg, cohesion c = 250 psf). In accordance with GDR Rev. 2 Section 4, the depth to the base of Stratum I is linearly interpolated between Boring A (STA 0.0) and Boring B (STA 77.0) along Column Line A and rounded to the nearest 0.1 ft. Stratum II thickness is uniform across each pad (12 to 18 ft) with phi = 33 deg, c = 0, gamma = 126 pcf.

---

## 3. Bearing Capacity and Factor of Safety
- **Factor of Safety (FS):** Minimum bearing capacity factors of safety are established strictly from UFC 3-220-01 Table 2-3 based on building occupancy:
  - CR-P1, CR-P2, CR-P3, CR-P6: Light Industrial, Public -> FS = 3.5.
  - CR-P4: Apartments, Office -> FS = 3.0.
  - CR-P5: Warehouse -> FS = 2.5.
- **Bearing Capacity Formulations:** Evaluated using three widely accepted methods per UFC 3-220-01 paragraph 2-4.7.1 and RFI-021: Meyerhof (1963), Brinch Hansen (1970), and Vesic (1975) general bearing capacity equations:
  q_ult = c * Nc * sc * dc + sigma_zD * Nq * sq * dq + 0.5 * gamma_eff * B * Ngamma * sgamma * dgamma
  q_allow_net = (q_ult - sigma_zD) / FS
  Groundwater table adjustments to the effective wedge unit weight gamma_eff were incorporated per UFC 3-220-20 Section 5-3.1.2 and Figure 5-6 where dw < Df + B * tan(45 + phi/2). Meyerhof's formulation yields the most conservative capacity and was adopted as the design governing allowable bearing pressure, fully complying with RFI-021.

---

## 4. Tolerable Movement Criteria and Settlement Analysis
- **Settlement Limits:** Per UFC 3-220-01 paragraph 2-4.7.1:
  - Total post-construction settlement: s_tot <= 1.0 inch (25.4 mm).
  - Differential settlement / angular distortion between adjacent units: Delta s / L_span <= 1/500 = 0.00200.
- **Settlement Method:** Evaluated strictly using layered elastic compression per FHWA GEC 13 Equation 5-14 and RFI-019. The soil column below the footing soffit is discretized into uniform layers of thickness H = 0.25 ft extending to z_max = max(4B, 40 ft). The vertical net stress increment Delta sigma at each layer mid-height is calculated via the 2V:1H rectangular stress distribution:
  Delta sigma(zm) = P_service / ((B + zm) * (L + zm))
  and summed using the pad-specific secant elastic moduli Es_I, Es_II, Es_III from GDR Rev. 2.

---

## 5. Ground Improvement Design Parameters (Rammed Aggregate Piers)
Where ground modification is applied beneath shallow spread footings:
1. **Stress Concentration Ratio (ns):** ns = 10.0, governing value for structure foundation support under rigid footings per FHWA GEC 13 Section 4.2.1 and RFI-011. Proprietary vendor manual claims (ns >= 20) are rejected.
2. **Pier Diameter & Clear Spacing:** 30-inch diameter (dp = 2.5 ft, Ap = 4.9087 sq ft) installed by specialty rig with minimum clear spacing >= 1.0 ft (center-to-center spacing s >= 3.5 ft) per Kettleridge proposal KGS-26-0917 Section 2.
3. **Area Replacement Ratio (Ra):** Enforced at Ra >= 0.33 per FHWA GEC 13 Section 4.2.1 (Collin 2007 HITEC evaluation report).
4. **Top-of-Pier Stress Limit:** qg <= 18,000 psf, verified by contractor pre-production and production modulus testing at 150% design load.
5. **Two-Layer Settlement Model:** Evaluated per FHWA GEC 13 Section 4.2.3:
  - Upper zone settlement: s_uz = qg / (144 * kg) (in inches), where qg = q * [ns / (1 + (ns - 1)*Ra)] and kg is the pad-specific design stiffness modulus from pre-production testing (CR-P1: 165 pci, CR-P2: 140 pci, CR-P4: 195 pci, CR-P6: 155 pci).
  - Lower zone settlement: s_lz integrated using FHWA GEC 13 Eq. 5-14 from the pier tip depth D_pier to z_max.
  - Total settlement: s_tot = s_uz + s_lz <= 1.0 inch.
6. **Treatment Depth:** Treatment depth below footing soffit is dimensioned in whole feet within the subcontractor warrantied range of 8 to 25 ft (CR-P1: 10-12 ft, CR-P2: 12-14 ft, CR-P4: 8-10 ft, CR-P6: 10-12 ft).

---

## 6. Structural Concrete and Reinforcement Detailing
- **Durability Mix Requirements:** Derived from UFGS 03 30 00 and EM 1110-2-2000 Table 2-2:
  - CR-P1: F1, W1, C1, S1 (0.14% SO4) -> f'c = 4,000 psi, max w/cm = 0.50.
  - CR-P2: F1, W1, C1, S2 (0.23% SO4) -> f'c = 4,500 psi, max w/cm = 0.45.
  - CR-P3: F1, W1, C1, S0 (0.07% SO4) -> f'c = 4,000 psi, max w/cm = 0.50.
  - CR-P4: F1, W1, C1, S1 (0.11% SO4) -> f'c = 4,000 psi, max w/cm = 0.50.
  - CR-P5: F3, W1, C1, S0 (0.05% SO4, exterior apron de-icer exposure) -> f'c = 5,000 psi, max w/cm = 0.40.
  - CR-P6: F1, W1, C1, S2 (0.26% SO4) -> f'c = 4,500 psi, max w/cm = 0.45.
- **Reinforcement & Effective Depth:** Grade 60 (fy = 60 ksi). Concrete clear cover is 3 in plus one bar diameter; effective depth is taken as d = thickness - 4 inches per Basis of Design Rev. 3 Section 3. Minimum reinforcement ratio rho >= 0.0018 in each direction (exceeding UFC 3-220-01 para 2-4.7.7 requirement of 0.0015 for footings > 3 ft thick). Bar spacing is kept <= 12 inches with minimum bar size No. 4.
- **Shear Design:** One-way shear and two-way punching shear were designed in accordance with ACI 318-19 / UFC 3-301-01 Section 2-7 with shear strength reduction factor phi = 0.75. Footing thicknesses are dimensioned to the nearest 3 inches, with minimum thickness 12 inches.

---

## 7. Continuous Shear-Wall Footing (W1) Stability
The continuous shear-wall footing (L = 24.0 ft = 288 in) was verified against all limit states per the AV-CR-2604 load combination memo and EM 1110-2-2502:
1. **Sliding Stability (0.6D + W):** Resisted by base friction on footing soffit (tan delta = tan(2/3 phi) = tan(17.33 deg) = 0.3121) plus passive soil resistance 0.5 Pp on the embedded vertical face. All pads achieve FS_sliding >= 2.25 (governing limit >= 1.50 per EM 1110-2-2502 Table 4-1 and >= 2.0 per UFC 3-220-01 para 2-4.6.3).
2. **Overturning Resultant Location (D + L + W):** Under factored service wind moment My = 484 to 932.8 kip-ft and shear Hx = 52.8 to 101.8 kips, resultant eccentricity e = M_total / V_total ranges from 4.8 to 7.1 inches, well within the middle-third kern limit of L/6 = 24/6 = 4.0 ft = 48.0 inches.
3. **Net Uplift Resistance (0.6D + W / UPLIFT_W):** Uplift demand P_uplift = 143.0 to 275.6 kips is resisted by 0.6*(W_footing + W_soil + D_dead). Factors of safety range from 2.68 to 3.15, comfortably exceeding the required FS_uplift >= 1.0.

---

## 8. Campus Programme Reasoning and Optimisation
The Phase 1 campus foundation package must achieve structural compliance at every foundation while minimizing total campus cost under the project budget unit prices. Ground improvement is procured by the rig ($40,000 lump sum per rig), with each mobilised rig serving at most two building pads within the milestone window (KGS-26-0917 Section 4):
- **CR-P1 & CR-P2:** Underlain by deep, soft Stratum I soils (Es_I = 110 ksf and 85 ksf). SPREAD-only footings cannot achieve total settlement <= 1.0 in at W1 even with footing widths exceeding 40 ft, and column footings require massive dimensions (24-39 ft) that overlap adjacent foundations. Ground improvement is physically mandated. Mobilising Rig 1 to serve CR-P1 and CR-P2 resolves bearing and settlement compliance.
- **CR-P6:** Highly loaded data hall with soft soil (Es_I = 95 ksf). SPREAD footings require B = 25 to 33.75 ft, overlapping heavily on 16-20 ft column bays and costing $196,610. Ground improvement costs only $47,252 (plus testing and rig allocation), delivering over $100,000 in direct savings. Mobilising Rig 2 is strongly economically warranted.
- **CR-P4:** Admin building on moderate soil (Es_I = 130 ksf). SPREAD footings require B = 11.5 to 19.0 ft and W1 B = 22.25 ft, costing $58,911. Because Rig 2 has an open second slot, CR-P4 is improved at an incremental cost of only $24,891 + $9,500 test = $34,391, yielding net savings of $24,520 with zero additional rig mobilisation cost.
- **CR-P3 & CR-P5:** CR-P3 (Es_I = 210 ksf) and CR-P5 (Es_I = 250 ksf) feature stiff residual soils and lighter structural loads. Unimproved SPREAD footings are fully compliant: maximum settlements are 0.995 in (P3) and 0.799 in (P5), and angular distortions are 0.00188 and 0.00112 (both < 1/500). SPREAD costs are $31,317 (P3) and $17,018 (P5). Ground improvement would cost $38,393 (P3) and $31,706 (P5) before mobilisation, plus would require buying a third rig ($40,000). Both pads are definitively selected as shallow SPREAD footings.

**Final Campus Rig Allocation:** Exactly 2 rigs mobilised ($80,000 mobilisation cost), with Rig 1 serving CR-P1 and CR-P2, and Rig 2 serving CR-P4 and CR-P6. Four modulus tests ($38,000). Total campus foundation package cost: $462,660.40.
