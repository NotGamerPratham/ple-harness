```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010 normals",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 180647.52,
      "improved_cost_usd": 105263.72
    },
    "CR-P2": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 285763.46,
      "improved_cost_usd": 111084.28
    },
    "CR-P3": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 29346.81,
      "improved_cost_usd": 69053.71
    },
    "CR-P4": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 55591.11,
      "improved_cost_usd": 59707.52
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 16296.38,
      "improved_cost_usd": 45970.63
    },
    "CR-P6": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 191040.23,
      "improved_cost_usd": 107709.84
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 505292.14,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "NOAA NCEI AFI 1951-1980 (superseded, gives 416 deg F-days -> would allow 30 in; current 1981-2010 gives 556 -> 42 in)",
    "Geotechnical Addendum 1 (superseded Es and 4000 psf presumptive value)",
    "Basis of Design Rev 1 (superseded; all-Warehouse/F0, 1 in grid, 20 ft bearing depth)",
    "UFC 3-220-10N Soil Mechanics DM 7.1 2005 (cancelled; settlement method redirected to GEC13 Eq 5-14)",
    "UFC 3-220-01N Foundation Design 2005 (cancelled)",
    "Adjacent Parcel Report Broadview Commons (different property; not applicable)",
    "FHWA GEC 6 bridge angular distortion 0.004/0.005 (different class of structure; UFC 3-220-01 1/500 governs buildings)",
    "3000 psf presumptive bearing pressure in the Geotechnical Data Report (preliminary only; prohibited by AHJ Amendment 4)"
  ]
}
```
# Design Basis — Cattail Run Data Campus, Phase 1 Foundation Strategy


## Governing criteria and documents set aside

The governing geotechnical criteria are UFC 3-220-01 (Geotechnical Engineering, 2012, Change 3) and the supporting manuals it cites — DM 7.2 (UFC 3-220-20, 2025) and EM 1110-1-1905 (Bearing Capacity of Soils) for bearing capacity, EM 1110-2-2502 (Retaining and Flood Walls) for sliding/overturning/uplift, and EM 1110-2-2104 (Strength Design for Reinforced Concrete) for footing shear and flexure. Concrete durability is governed by UFGS 03 30 00 with the sulfate-exposure condition table of EM 1110-2-2000. Ground improvement is governed by FHWA GEC 13 Vol 1 and the Kettleridge Ground Systems budget proposal. The Loudoun County AHJ amendment letter LC-BD-26-0774 (Amendments 3 and 4) governs frost protection and the prohibition on presumptive bearing values. Documents reviewed and set aside are listed in the rejected_criteria array above (the superseded 1951-1980 AFI product, Geotechnical Addendum 1, Basis of Design Rev 1, the cancelled DM 7.1 and UFC 3-220-01N, the adjacent-parcel Broadview Commons report, and the FHWA GEC 6 bridge serviceability criterion).


## Bearing capacity and factor of safety

A minimum factor of safety on bearing was selected from UFC 3-220-01 Table 2-3 by the occupancy (STRUCTURE) row of the Basis of Design: 3.5 for the Light Industrial/Public pads (CR-P1, CR-P2, CR-P3, CR-P6), 3.0 for the Apartments/Office pad (CR-P4), and 2.5 for the Warehouse pad (CR-P5, which is a logistics/spares warehouse without super-flat floor requirements). Ultimate bearing capacity of the Stratum I matrix soil was computed with three widely accepted methods — Terzaghi, Meyerhof and Brinch Hansen (DM 7.2 Table 5-3, EM 1110-1-1905 Eq 4-1) — using the drained strength parameters of the Geotechnical Data Report (phi=26 deg, c=0.25 ksf, gamma=118 pcf). The reported net allowable for each foundation is the value the design relies on and is not more permissive than the Meyerhof general bearing-capacity equation evaluated for the same geometry, stratigraphy, groundwater condition and factor of safety. For improved foundations the net allowable is the lesser of the top-of-pier-stress limit (18,000 psf, GEC13/Kettleridge) and the matrix-soil allowable, both expanded by the stress concentration ratio. The groundwater correction (EM 1110-1-1905 Eq 1-6 / DM 7.2 5-3.1.3) is applied wherever the water table lies within one footing width of the bearing elevation; the surcharge term uses the moist unit weight because every pad's 42 in bearing elevation is above the stabilised water table.


## Settlement method and tolerable movement

Per RFI-019, settlement is computed by layered elastic compression (GEC13 Equation 5-14): the soil below the bearing surface is divided into uniform 0.25 ft layers, the net stress increment in each layer is found with the 2-vertical-to-1-horizontal approximate stress distribution for the rectangular loaded area, and the layer compressions s = (delta sigma)(H)/Es are summed using the pad-specific elastic moduli, carried to a depth of four times the footing width and in no case less than 40 ft. The same equation is the lower-zone term of the two-layer aggregate-pier method, keeping the improved and unimproved cases consistent. The tolerable-movement criteria adopted are those of UFC 3-220-01 paragraph 2-4.7.1: total post-construction settlement not exceeding 1 in (25.4 mm) and angular distortion (differential settlement divided by distance) not exceeding 1/500. The competing FHWA GEC 6 bridge criterion (0.004 for continuous spans, 0.005 for simple spans) is rejected because GEC 6 is written for transportation structures, a different class.


## Ground-improvement design parameters

The stress concentration ratio is 10, the value FHWA GEC 13 (Section 4.2) gives for structure foundation support under rigid footings (per RFI-011). The installed pier diameter is 30 in (Kettleridge). The design area replacement ratio is at least 0.33 (GEC13/HITEC) and at most the geometric maximum fixed by 30 in piers at the 1.0 ft minimum clear spacing. The design top-of-pier stress is held at or below 18,000 psf (Kettleridge, verified at 150% of design load). The stiffness modulus for each improved pad is the as-tested value of the Kettleridge pre-production modulus tests (140-230 pci). Treatment depth is a whole number of feet between 8 and 25 ft, chosen to extend through the compressible Stratum I so the lower-zone settlement begins in the stiffer Stratum II/III.


## Conflict resolution

Two NCEI air-freezing-index products give different 100-year values for the county station of record; the current 1981-2010 product (556 deg F-days) governs per AHJ Amendment 3 and RFI-007, giving a 42 in minimum bearing depth (the superseded 1951-1980 product gave 416, which would have allowed 30 in). The 3,000 psf presumptive value in the Geotechnical Data Report and the 4,000 psf value in Addendum 1 are not used (AHJ Amendment 4, RFI-009); a site-specific analysis is used instead. Where the 1.5B footing spacing is not met, RFI-017 directs the foundations to be sized as individual units with no reduction for overlapping zones of influence. The governing value is in each case the live document listed in the constraint register.


## Campus programme reasoning

Ground improvement is bought by the rig and each mobilised rig can serve at most two pads, so the four pads whose soft Stratum I would force very large spread footings — CR-P1, CR-P2 and CR-P6 (the lowest Es and thickest Stratum I) — are improved and served by two rigs (RIG-1: CR-P1, CR-P2; RIG-2: CR-P6). CR-P3, CR-P4 and CR-P5 have stiffer Stratum I (Es 130-250 ksf) and are carried on spread footings alone, which are cheaper than improving them. Improving a fourth pad (CR-P4) would still fit within the two mobilised rigs but the equalised improved footings cost more than the spread footings there, so it is not economical. The campus programme cost is $505,292 (mobilisation $80,000 for 2 rigs), the least-cost compliant programme at the project unit prices.
