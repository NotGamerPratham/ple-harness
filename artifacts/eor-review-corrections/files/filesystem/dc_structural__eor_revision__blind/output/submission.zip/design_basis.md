# DESIGN BASIS: EOR REVIEW CORRECTIONS - WORK ORDER 74213

```json
{
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": 2,
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 15,
      "delay_days": 0,
      "backcheck_window_days": 15,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 21546.61,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 3600,
        "overflow_option_usd": 2640,
        "non_concurrence_usd": 2400,
        "delay_usd": 0,
        "total_usd": 57386.61
      },
      "title_block_defects": [
        {
          "sheet": "E-501",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "S-301",
          "defect": "CHK_EQUALS_DRW"
        }
      ]
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": "NONE",
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 0,
      "backcheck_window_days": 30,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 25639.78,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 0,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 0,
        "delay_usd": 0,
        "total_usd": 52839.78
      },
      "title_block_defects": [
        {
          "sheet": "A-501",
          "defect": "CHK_EQUALS_DES"
        },
        {
          "sheet": "M-101",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "T-101",
          "defect": "CHK_EQUALS_DRW"
        }
      ]
    }
  },
  "governing_standards": [
    "FC 1-300-09N, Navy and Marine Corps Design Procedures (17 May 2024, with Change 1, 17 April 2025)",
    "DoD A/E/C CAD Standard, Release 6.2 (ERDC/ITL SR-24-3, September 2024)",
    "DoD A/E/C Graphics Standard, Release 2.2 (ERDC/ITL SR-23-1, March 2023)",
    "ER 1165-2-217, Water Resources Policies and Authorities - Civil Works Review Policy (1 May 2021)",
    "ERDC/ITL SR-21-6, Record Package Guidance: Best Practices (November 2021)",
    "ER 415-1-11, Biddability, Constructability, Operability, Environmental, and Sustainability (BCOES) Reviews (1 January 2013)",
    "FAR 52.236-25, Requirements for Registration of Designers (48 CFR 52.236-25, June 2003)"
  ],
  "rejected_standards": [
    "UFC 1-300-09N (25 May 2005, Change 7, 27 January 2010) - Cancelled and superseded by FC 1-300-09N",
    "DoD A/E/C CAD Standard Release 6.0 (ERDC/ITL TR-12-6, August 2012) - Superseded by DoD A/E/C CAD Standard Release 6.2",
    "GSA PBS CAD Standards (January 2021) - Legacy civilian agency criteria inapplicable to Department of the Navy military construction",
    "Fire Protection Comment Log BP-2 (Separate Task Order) - Belongs to independent fire protection contract scope outside work order 74213"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4,
    "days_per_bundle": 3
  },
  "void_markups": [
    {
      "comment_id": "EOR-2-017",
      "reason": "Reviewer is not listed on roster and lacks professional registration under FAR 52.236-25."
    },
    {
      "comment_id": "EOR-2-021",
      "reason": "Markup was entered on superseded submittal print rather than the current bid package."
    },
    {
      "comment_id": "EOR-2-027",
      "reason": "Reviewer is construction representative lacking professional registration required by FAR 52.236-25."
    },
    {
      "comment_id": "EOR-2-033",
      "reason": "Comment previously closed in sixty percent review as elevated and not reopened."
    },
    {
      "comment_id": "EOR-3-012",
      "reason": "Markup was entered on superseded submittal print rather than certified final design."
    },
    {
      "comment_id": "EOR-3-022",
      "reason": "Reviewer is not listed on roster and lacks professional registration under FAR 52.236-25."
    },
    {
      "comment_id": "EOR-3-036",
      "reason": "Comment previously closed in sixty percent review as elevated and not reopened."
    }
  ]
}
```

## 1. Resolution of Revision-Graphics Layer Conflict

Two technical standards in the project library specify CAD layer assignments for revision graphics. In FC 1-300-09N Paragraph 12-3.6.1, directions are given to place revision clouds on layer Z-ANNO-REVC and revision indicators on layer Z-ANNO-REVS. In contrast, the DoD A/E/C CAD Standard Release 6.2 (ERDC/ITL SR-24-3) Table A-3 and ERDC/ITL SR-21-6 Chapter 3 assign revision clouds to layer G-ANNO-REVC and revision symbols and tags to layer G-ANNO-REVS.

This apparent conflict is resolved by applying the hierarchy established in FC 1-300-09N Paragraph 12-3.3.4, CAD Standards. Under Paragraph 12-3.3.4, the order of precedence dictates that the provisions of Chapter 12 control first, followed by the latest editions of the DoD A/E/C CAD Standard and DoD A/E/C Graphics Standard. Examination of Chapter 12 reveals that Paragraph 12-3.6 is explicitly entitled Record Documents, with Paragraph 12-3.6.1 dedicated exclusively to Record Drawing Preparation. The Z-ANNO prefix layers are specifically intended for post-construction as-built record drawings prepared after field completion. 

For pre-award design submittals, including solicitation amendments and final design reissues governed by Paragraph 12-3.5, Chapter 12 provides no specialized revision layer designations. Consequently, per the precedence rule of Paragraph 12-3.3.4, authority flows directly to the DoD A/E/C CAD Standard Release 6.2 Table A-3 and ERDC/ITL SR-21-6 Chapter 3. Accordingly, all revision clouds are drafted on layer G-ANNO-REVC and all revision indicators, deltas, and associated notes are drafted on layer G-ANNO-REVS. This finding is corroborated by inspection of the active CAD source files for both bid packages, which consistently employ G-ANNO-REVC and G-ANNO-REVS.

## 2. Issue State and Review Window Determination for BP-3

Bid package BP-3 (Data Hall 210 Shell and Interiors, Solicitation N40085-26-R-3018) currently resides in a certified final design state pending advertisement. Paragraph 3 of the Contracting Officer memorandum of 26 August 2026 establishes that BP-3 is scheduled to advertise on 9 November 2026, which controls over earlier solicitation schedule dates. The memorandum authorizes the Designer of Record to evaluate two alternative courses: incorporating corrections into the certified design prior to advertisement (Option a), or advertising on schedule and issuing corrections via amendment during the solicitation period (Option b).

Governing review policy under ER 415-1-11 establishes explicit timing windows for review completion. For design-bid-build delivery, ER 415-1-11 Paragraph 6.e.(2) and Paragraph 6.g dictate that the second BCOES review and associated backcheck review must be initiated and completed at least 30 calendar days prior to advertisement. Incorporating corrections prior to advertisement (PRE_ADVERTISEMENT_REISSUE) binds the project to this 30 calendar day pre-advertisement window. With a production start date of 2026-08-31 and total production duration of 14 calendar days, production completes on 2026-09-14. This date precedes the 9 November 2026 advertisement date by 56 calendar days, comfortably satisfying the 30 calendar day requirement of Paragraph 6.g with 26 days of float. The advertisement deadline is undisturbed (delay days D = 0), incurring zero schedule extension penalties.

Conversely, if Option b were adopted, the corrections would be issued as a post-advertisement amendment. Under ER 415-1-11 Paragraph 6.g, all comments must be resolved and backchecked prior to bid opening. The solicitation schedule sets bid opening for 2026-11-12, providing an advertisement duration of only 3 calendar days following the 9 November 2026 advertisement. Even applying the shorter 15 calendar day backcheck duration described in ER 415-1-11 Paragraph 6.e.(4), conducting backcheck during advertisement would breach the bid-opening date by at least 12 calendar days. Under Contracting Officer Memorandum paragraph 4, a 12-day extension would assess $51,360 in escalating delay costs ($2,600 * 12 + $140 * 144). Furthermore, post-advertisement issuance would mandate revision delta indicators, revision clouds, continuation sheets, and revision mark fees.

Therefore, Option a (PRE_ADVERTISEMENT_REISSUE) is selected. It complies fully with the 30 calendar day window of ER 415-1-11 Paragraph 6.g, completely avoids delay penalties, and eliminates revision mark and continuation sheet expenses.

## 3. Revision (Issue) Block Overflow Decision for BP-2

Bid package BP-2 is currently advertised under Solicitation N40085-26-R-2041, requiring that corrections be issued as Amendment 0003. Per DoD A/E/C Graphics Standard Release 2.2 (ERDC/ITL SR-23-1) Paragraph 7.3, the standard title block Revision (Issue) block has a maximum capacity of exactly eight rows. Review of the BP-2 drawing set shows that seven re-issued sheets (C-101, M-101, M-501, S-101, S-102, S-501, and S-502) already contain eight historical revision entries and are completely full.

Paragraph 7.3 of ERDC/ITL SR-23-1 presents two standardized procedures when revisions exceed eight rows: Option 1, which replaces the oldest entry in the block while copying displaced entries outside the plotted sheet border; and Option 2, which continues adding entries above the eighth row so that they spill upward into the drawing area. Paragraph 7.3 explicitly mandates that whichever option is chosen must be applied consistently across the entire drawing set rather than on a sheet-by-sheet basis.

The selection between these options is governed by comparative cost under the A-E Production Rate Schedule:
1. Option 1 charges $520 per revised sheet whose revision block is full. For the 7 full sheets, Option 1 incurs an expenditure of 7 * $520 = $3,640.
2. Option 2 assesses $880 per revised full sheet only when the sheet carries three or more drawing blocks, requiring graphic re-layout of occupied space. Sheets carrying fewer than three drawing blocks possess unoccupied margin above the title block, allowing overflow at zero charge.

Among the 7 full sheets in BP-2:
- Sheets C-101, M-101, S-101, and S-102 each carry only a single plan drawing block, leaving the overflow zone entirely vacant ($0 charge each).
- Only three sheets carry three or more drawing blocks: M-501 (3 details), S-501 (3 details), and S-502 (4 details). These 3 sheets incur the re-layout fee (3 * $880 = $2,640).

Implementing Option 2 set-wide results in a total overflow cost of $2,640, securing an immediate cost reduction of $1,000 compared to Option 1 ($3,640). Option 2 is therefore selected and applied uniformly across the BP-2 drawing package.
