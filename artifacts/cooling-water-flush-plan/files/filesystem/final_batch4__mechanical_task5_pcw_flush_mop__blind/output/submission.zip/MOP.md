# METHOD OF PROCEDURE (MOP) AND DESIGN BASIS
## Process Cooling Water Cleaning, Flushing, Passivation and Turnover
### Tull Creek Data Hall — Turnover Package

---

## 1. DESIGN BASIS AND GOVERNING CONSTRAINTS

The Process Cooling Water (PCW) system at the Tull Creek Data Hall comprises eight tie-in bounded circuits (C1 through C8) of varying metallurgies, pipe sizes, elevations, and hold-up volumes. In accordance with Section 23 25 16 Clause 1.6, the governing constraint for each circuit has been established by evaluating the five binding constraint families:
1. Flushing duty against available skid pump head: `(h_avail - h_req) / h_avail`
2. Rinse endpoint: relative margin in conductivity `(C_target - C_achieved) / C_target` and in displacements `(n_actual - n_exact) / n_actual`
3. Authorised programme sewer discharge volume: `(500,000 - V_discharge_sewer) / 500,000`
4. Site daily construction water allocation: `(Allocation_day - Draw_day) / Allocation_day`
5. Temporary electrical power capacity at tie-in: `(kW_available - kW_connected) / kW_available`

Per Section 23 25 16 Clause 1.6, which constraint binds is decided using whichever permitted form of each is the tighter. The rinse endpoint criterion evaluated in conductivity leaves the least room against limit for almost all circuits, and the authorised sewer discharge volume caps total sewered effluent.

The governing constraint lines are stated below exactly as prescribed:

GOVERNING CONSTRAINT C1: authorised programme discharge volume (margin 0.0081)
GOVERNING CONSTRAINT C2: rinse endpoint (margin 0.0198)
GOVERNING CONSTRAINT C3: rinse endpoint (margin 0.0198)
GOVERNING CONSTRAINT C4: rinse endpoint (margin 0.0107)
GOVERNING CONSTRAINT C5: rinse endpoint (margin 0.0107)
GOVERNING CONSTRAINT C6: rinse endpoint (margin 0.0289)
GOVERNING CONSTRAINT C7: rinse endpoint (margin 0.0107)
GOVERNING CONSTRAINT C8: rinse endpoint (margin 0.0359)

### Summary of Governing Constraints and Margins by Circuit

* **Circuit C1 (Primary Header & Pump Gallery):**
  * Assigned Skid: `FS-1200-A` (Single unit, 75 kW).
  * Flow Rate: 1,200.0 gpm (governing line 1043, 4 legs of 6 in. CS, v = 3.39 ft/s >= 3.28 ft/s).
  * Hydraulic Head: Required 88.31 ft w.c. vs Available 119.52 ft w.c. (margin = 0.2611).
  * Temporary Power: 75.0 kW connected vs 150.0 kW available at TP-MER-1 (margin = 0.5000).
  * Rinse Endpoint: 6 passes achieve 663.1 uS/cm vs 676.5 uS/cm limit (margin = 0.0198 in conductivity, 0.0660 in displacements).
  * Sewer Discharge Cap: Total programme sewer volume is 495,969.7 gal against the 500,000 gal cap in SW-03 Rev B (margin = 0.0081).
  * **Binding Constraint:** Authorised programme discharge volume (margin 0.0081).

* **Circuit C2 (Heat Exchanger Bay A):**
  * Assigned Skid: `FS-600-A+FS-600-B` (2 units in parallel, 60 kW).
  * Flow Rate: 624.0 gpm (governing line 2011, 8 in. CS, v = 4.00 ft/s >= 4.00 ft/s).
  * Hydraulic Head: Required 59.13 ft w.c. vs Available 161.24 ft w.c. (margin = 0.6333).
  * Temporary Power: 60.0 kW connected vs 150.0 kW available at TP-MER-1 (margin = 0.6000).
  * Rinse Endpoint: 6 passes (1 cascaded from C1, 5 fresh) achieve 663.1 uS/cm vs 676.5 uS/cm limit (margin = 0.0198 in conductivity).
  * **Binding Constraint:** Rinse endpoint (margin 0.0198).

* **Circuit C3 (Heat Exchanger Bay B):**
  * Assigned Skid: `FS-600-A+FS-600-B` (2 units in parallel, 60 kW).
  * Flow Rate: 721.0 gpm (governing line 2023, 2 legs of 6 in. CS, v = 4.00 ft/s >= 4.00 ft/s).
  * Hydraulic Head: Required 70.40 ft w.c. vs Available 154.13 ft w.c. (margin = 0.5432).
  * Temporary Power: 60.0 kW connected vs 95.0 kW available at TP-MER-2 (margin = 0.3684).
  * Rinse Endpoint: 6 passes achieve 663.1 uS/cm vs 676.5 uS/cm limit (margin = 0.0198 in conductivity).
  * **Binding Constraint:** Rinse endpoint (margin 0.0198).

* **Circuit C4 (CDU Distribution North):**
  * Assigned Skid: `FS-600-A` (Single unit, 30 kW).
  * Flow Rate: 361.0 gpm (governing line 4021, 6 in. CS, v = 4.00 ft/s >= 4.00 ft/s).
  * Hydraulic Head: Required 99.15 ft w.c. vs Available 154.05 ft w.c. (margin = 0.3564).
  * Temporary Power: 30.0 kW connected vs 90.0 kW available at TP-L3-N (margin = 0.6667).
  * Rinse Endpoint: 8 passes (mixing efficiency eta = 0.45 due to CP-311 manifold bank) achieve 669.2 uS/cm vs 676.5 uS/cm limit (margin = 0.0107 in conductivity, 0.0349 in displacements).
  * **Binding Constraint:** Rinse endpoint (margin 0.0107).

* **Circuit C5 (CDU Distribution South):**
  * Assigned Skid: `FS-600-A` (Single unit, 30 kW).
  * Flow Rate: 477.0 gpm (governing line 4033, 3 legs of 4 in. CS, v = 4.00 ft/s >= 4.00 ft/s).
  * Hydraulic Head: Required 130.17 ft w.c. vs Available 134.70 ft w.c. (margin = 0.0336).
  * Temporary Power: 30.0 kW connected vs 90.0 kW available at TP-L3-S (margin = 0.6667).
  * Rinse Endpoint: 8 passes (mixing efficiency eta = 0.45 due to CP-321 manifold bank) achieve 669.2 uS/cm vs 676.5 uS/cm limit (margin = 0.0107 in conductivity).
  * **Binding Constraint:** Rinse endpoint (margin 0.0107). Note: Flushing duty against skid head is also remarkably tight at 0.0336, but rinse endpoint in conductivity is tighter (0.0107).

* **Circuit C6 (CDU Distribution West):**
  * Assigned Skid: `FS-600-A` (Single unit, 30 kW).
  * Flow Rate: 361.0 gpm (governing line 4041, 6 in. CS, v = 4.00 ft/s >= 4.00 ft/s).
  * Hydraulic Head: Required 102.23 ft w.c. vs Available 154.05 ft w.c. (margin = 0.3364).
  * Temporary Power: 30.0 kW connected vs 90.0 kW available at TP-L3-W (margin = 0.6667).
  * Rinse Endpoint: 8 passes (mixing efficiency eta = 0.45 due to CP-331 aluminum cold-plate bank) achieve 656.9 uS/cm vs 676.5 uS/cm limit (margin = 0.0289 in conductivity).
  * **Binding Constraint:** Rinse endpoint (margin 0.0289).

* **Circuit C7 (Fan-Wall Coil Branch):**
  * Assigned Skid: `FS-600-A` (Single unit, 30 kW).
  * Flow Rate: 296.0 gpm (governing line 5011, 6 in. CS, v = 3.28 ft/s >= 3.28 ft/s).
  * Hydraulic Head: Required 107.28 ft w.c. vs Available 163.35 ft w.c. (margin = 0.3432).
  * Temporary Power: 30.0 kW connected vs 45.0 kW available at TP-ROOF (margin = 0.3333). Note: 45 kW strictly forbids FS-1200 (75 kW) and parallel FS-600s (60 kW).
  * Rinse Endpoint: 8 passes (mixing efficiency eta = 0.45 due to CL-401 coil bank) achieve 669.2 uS/cm vs 676.5 uS/cm limit (margin = 0.0107 in conductivity).
  * **Binding Constraint:** Rinse endpoint (margin 0.0107).

* **Circuit C8 (Makeup & Fill Riser):**
  * Assigned Skid: `FS-600-B` (Single unit, 30 kW).
  * Flow Rate: 152.0 gpm (governing line 6013, 2 legs of 3 in. Galv, v = 3.28 ft/s >= 3.28 ft/s).
  * Hydraulic Head: Required 67.41 ft w.c. vs Available 175.83 ft w.c. (margin = 0.6166). Includes ST-601 break tank dP = 9.63 ft w.c. at 152 gpm.
  * Temporary Power: 30.0 kW connected vs 120.0 kW available at TP-YARD (margin = 0.7500).
  * Rinse Endpoint: 6 passes achieve 652.2 uS/cm vs 676.5 uS/cm limit (margin = 0.0359 in conductivity, 0.1351 in displacements).
  * **Binding Constraint:** Rinse endpoint (margin 0.0359).

---

## 2. EXECUTION NARRATIVE

### 2.1 Scope Overview and Boundaries
The scope encompasses complete pre-operational hydrostatic testing, cleaning, flushing, chemical cleaning, rinsing, passivation, and turnover of the Tull Creek Data Hall Process Cooling Water (PCW) system across eight tie-in bounded circuits. All work is executed in strict compliance with Section 23 25 16 Rev 3, Section 23 21 16 Rev 3, Section 01 91 13 Rev 2, UFC 3-230-13 (2023 edition), DOE-HDBK-1012/3-92, 40 CFR 403, and 29 CFR 1910.1200.

### 2.2 Hydrostatic Pressure Testing Regime
In accordance with Section 01 91 13 Clause 1.3 and Section 23 21 16 Clause 3.3, a test result entered on commissioning record CX-02 is accepted only when accompanied by cited evidence (pressure chart) filed in the commissioning records:
* Circuits C1 (chart TR-0412), C2 (chart TR-0413), C4 (chart TR-0415), and C8 (chart TR-0419) have accepted pressure recorder charts on file. These circuits are not retested; retesting constitutes an unauthorized scope change.
* Circuits C3 (chart TR-0414 missing), C5 (chart TR-0416 missing), C6 (chart TR-0417 missing), and C7 (chart TR-0418 missing) have unaccepted hydrostatic records. These four circuits are hydrostatically tested on Project Day 0 prior to chemical cleaning.
* Testing is performed at 1.5 times the operating pressure of 85 psig = 127.5 psig (>= 125 psig minimum), held for not less than 120 minutes with zero pressure loss and no visible leakage, using a dedicated contractor-provided hydrostatic test pump (cl. 3.10.f). All hydro tests complete by hour 4 on Day 0, well before contractual milestone TM-1 (Day 6, hour 144).

### 2.3 Component Protection and Temporary Bypass Spools
Per Schedule M-602 and Section 23 25 16 Clause 3.4:
* Full-size temporary bypass spools are fitted prior to initial flushing on all protected equipment: plate heat exchangers HX-201A (C2) and HX-201B (C3), coolant distribution units CDU-301 (C4) and CDU-302 (C5), cold-plate manifold banks CP-311 (C4), CP-321 (C5), CP-331 (C6), and fan-wall coil bank CL-401 (C7).
* Primary pump set PMP-101 (2,400 gal) and buffer vessel BT-101 (5,000 gal) in C1, and makeup break tank ST-601 (3,750 gal) in C8, have no bypass provision and remain in the flushed path. Their casing ratings and allowable particle sizes (800 micron) exceed the 380 micron screen of the temporary strainers.
* Each flushing skid discharge is fitted with a 40-mesh stainless steel basket strainer (nominal 380 micron opening, clean dP 11 ft w.c. at 600 gpm per VD-05). Strainer baskets are inspected and cleaned at every drain event and removed at turnover milestone TM-4.

### 2.4 Flushing and Flow Rate Verification
Per Section 23 25 16 Clause 3.3 and UFC 3-230-13 paragraph 5-3.7:
* Every leg of every line achieves >= 4.0 ft/s for circuits serving plate heat exchangers or cold plates (C2, C3, C4, C5, C6) and >= 3.28 ft/s (foulant suspension velocity per UFC 3-230-13 cl. 5-3.7) for all other circuits (C1, C7, C8).
* In parallel lines, flow divides equally across legs. The governing segment (minimum velocity) is verified and recorded for each circuit:
  * C1: Line 1043 (4 legs of 6 in. CS), v = 3.39 ft/s at 1,200 gpm.
  * C2: Line 2011 (8 in. CS), v = 4.00 ft/s at 624 gpm.
  * C3: Line 2023 (2 legs of 6 in. CS), v = 4.00 ft/s at 721 gpm.
  * C4: Line 4021 (6 in. CS), v = 4.00 ft/s at 361 gpm.
  * C5: Line 4033 (3 legs of 4 in. CS), v = 4.00 ft/s at 477 gpm.
  * C6: Line 4041 (6 in. CS), v = 4.00 ft/s at 361 gpm.
  * C7: Line 5011 (6 in. CS), v = 3.28 ft/s at 296 gpm.
  * C8: Line 6013 (2 legs of 3 in. Galv), v = 3.28 ft/s at 152 gpm.

### 2.5 Chemical Cleaning and Metallurgy Compatibility
* **Circuits C1, C2, C3, C4, C5, C7 (Carbon steel, stainless steel, copper):** Cleaned with alkaline pre-operational cleaner CL-100 at 1.5 gal per 1,000 gal of system volume, supplemented with polyacrylate dispersant PD-45 at 5.0 ppm active polymer.
* **Circuit C6 (6061-T6 Aluminum cold plates CP-331):** Cleaned with neutral-pH cleaner CL-210 at 2.0 gal per 1,000 gal of system volume to prevent alkaline corrosion (pH held <= 8.5 per UFC 3-230-13 cl. 10-1.1 and VD-04).
* **Circuit C8 (Galvanized steel fill riser and ST-601 break tank):** Cleaned with neutral-pH cleaner CL-210 at 2.0 gal per 1,000 gal of system volume to prevent stripping of zinc galvanizing and white rust formation (pH held <= 8.5 per UFC 3-230-13 cl. 5-7.3.1 and RFI-022).
* All cleaning charges are circulated for exactly 24.0 occupied hours (UFC 3-230-13 cl. 5-7.3.2.2.b). All chemical cleaning across the project completes on Day 12, well ahead of contractual milestone TM-2 (Day 22, hour 528).

### 2.6 Rinse Displacements and Effluent Management
* Rinse requirements are governed by the displacement mixing model `C_n = C_mk + (C_0 - C_mk) * exp(-eta * n)` to meet `C_n <= 1.10 * C_mk = 676.5 uS/cm`. Circuits containing manifold banks or coil banks (C4, C5, C6, C7) have mixing efficiency eta = 0.45 (requiring 8 passes); other circuits (C1, C2, C3, C8) have eta = 0.62 (requiring 6 passes).
* **Cascaded Rinse:** In accordance with Section 23 25 16 Clause 3.6, Circuit C2 receives 1 cascaded displacement (5,596.0 gal) transferred from the final rinse effluent of Circuit C1 via a portable holding tank (cl. 3.10.f). Circuit C2 draws only 5 fresh displacements, saving 5,596.0 gallons of water and sewer disposal.
* **Effluent Routing:**
  * Initial flush and hydrostatic test effluent meet all sewer local limits and are discharged to metered manhole MH-14.
  * Spent cleaning solutions from C4, C5, C6, C7 contain total copper (typically 1.6 to 3.4 mg/L) exceeding the SW-03 Rev B local limit of 1.0 mg/L; spent cleaning solution from C8 contains total zinc (5.5 mg/L) exceeding the 1.0 mg/L limit. These streams are hauled off site by vacuum tanker to a permitted disposal facility at $168.00/1,000 gal.
  * Spent cleaning solution from C1 (32,983.4 gal) is also hauled off site to ensure total programme sewer volume remains strictly below the 500,000 gallon permit cap in SW-03 Rev B.
  * Total sewer discharge across the programme is 495,969.7 gallons, safely within the 500,000 gallon authorized cap.

### 2.7 Passivation and Turnover Strategy
* **Treatment Selection:**
  * Makeup water contains 505 mg/L Cl and 355 mg/L SO4 (total Cl + SO4 = 860 mg/L). UFC 3-230-13 paragraph 6-2.2.2 explicitly prohibits nitrite-based programs (NB-700) when Cl + SO4 > 800 ppm.
  * Circuits C1, C2, C3, C4, C5, C7 utilize Molybdate (MO-500) at 50 ppm as Mo initial passivation and 100 ppm as Mo maintenance (UFC cl. 6-2.2.3 and Table 5-11). Tolyltriazole (TA-90) is added at 10 ppm as TTA on circuits with wetted copper (C4, C5, C7).
  * Circuits C6 (aluminum) and C8 (galvanized steel) utilize Polysilicate (PS-330) at 50 ppm as SiO2 initial passivation and 80 ppm as SiO2 maintenance, pH 7.5 to 8.5 (UFC cl. 6-2.2.5, Table 5-11, VD-04, and cl. 5-7.3.1). Circuit C6 includes TA-90 at 10 ppm for copper fittings.
* **Film-Formation Hold:** All circuits maintain the passivation residual and pH for an unattended film-formation hold of 10.0 calendar days (240.0 occupied hours) per Table 5-11. Rented flush skids are released during the hold and are not charged (cl. 3.10.a). All passivation holds complete by Day 28 (hour 676), well ahead of milestone TM-3 (Day 44, hour 1056).
* **Turnover Method:** `RETAIN_AND_TOP_UP` is declared for all eight circuits. The passivation solution is retained in the pipework, component bypasses are removed, and the circuits are topped up to full system volume with treated makeup water carrying the maintenance chemical charge. This eliminates draining hundreds of thousands of gallons of treated water, avoids off-site chemical tanker haulage, and achieves the lowest total programme cost.
* **Final Acceptance:** Following top-up, circuits are recirculated for >= 30 minutes and sampled while circulating. Turnover parameters (maintenance inhibitor residual and total aerobic bacteria < 1,000 CFU/ml per UFC Table 6-3) are verified. Temporary strainers are removed at contractual milestone TM-4 (Day 47, hour 1128).

---

## 3. CONFLICT RESOLUTIONS AND DOCUMENT DEFECTS LOG

### 3.1 Document Conflict Resolutions
1. **Sewer Discharge Volume Authorization: RFI-031 vs SW-03 Rev B**
   * *Conflict:* RFI-031 (issued 2026-07-06) states the sewer authorization caps the programme total at 540,000 gallons. SW-03 Rev B (issued 2026-07-21) supersedes Revision A and explicitly restricts the authorized programme volume to 500,000 gallons.
   * *Resolution:* SW-03 Rev B was issued later in time and explicitly states it supersedes Revision A following treatment plant capacity review. The plan adopts the stricter 500,000 gallon cap. By hauling C1 spent cleaning solution, total sewered effluent is held to 495,969.7 gallons, fully complying with both documents.
2. **Treatment Program Selection: Table 6-2 vs Paragraph Text (UFC 3-230-13)**
   * *Conflict:* Table 6-2 lists Polysilicate-azole only under diesel engine jacket systems and omits closed process loops. Paragraph 6-2.2.5 states polysilicate is especially beneficial for closed process cooling water loops where aluminum metal is present.
   * *Resolution:* Section 23 25 16 Clause 3.5 governs: where the selection table and controlling paragraph text differ, the paragraph text governs. Polysilicate-Azole is selected for Circuit C6 (aluminum cold plates) and Circuit C8 (galvanized steel).
3. **Passivation Dosage Tables: Table 5-11 vs Tables 5-14/5-15 (UFC 3-230-13)**
   * *Conflict:* Table 5-11 specifies passivation film formation time of 10-12 days for Molybdate and Polysilicate. Tables 5-14 and 5-15 specify 14-21 days.
   * *Resolution:* Section 23 25 16 Clause 3.5 specifies that the tables identified for passive film formation in the current edition govern (Table 5-11, entitled "Guidelines for Passive Film Formation and Subsequent Maintenance"). A 10-day (240-hour) hold is scheduled.
4. **Rinse Acceptance Criterion: Tolerance vs Window**
   * *Conflict:* UFC 3-230-13 Clause 5-7.3.2.2.e specifies rinse pH as "+/-0.3 pH units from 7.5 to 8.5". Municipal makeup water pH is 7.6. Tolerance gives 7.3 to 7.9, while window gives 7.5 to 8.5.
   * *Resolution:* Section 23 25 16 Clause 3.6 resolves that both readings are acceptable, and a control band inside their intersection satisfies both. The plan operates inside their intersection (pH 7.5 to 7.9).

### 3.2 Document Defects Logged
1. **P&ID Rev A Superseded Sheet in Library:** Drawing `M-PID-103 Rev A` was included in the drawing tree. Schedule M-601 Note 5 and Rev C drawing title blocks clarify that Rev A is superseded. Rev C sheets were used exclusively.
2. **Cancelled Standard UFC 3-240-13FN:** The 2005 edition of the UFC criteria document was present in `standards/`. Section 23 25 16 Clause 1.2 explicitly cancels this document. The 2023 edition (UFC 3-230-13) was applied exclusively.
3. **Hydrostatic Test Records CX-02 Defect:** Test record CX-02 lists all eight circuits as "PASS", but pressure recorder charts are filed only for C1, C2, C4, and C8. Per Section 01 91 13 Clause 1.3, entries lacking filed evidence are unaccepted. Circuits C3, C5, C6, and C7 were correctly identified as requiring hydrostatic testing.
4. **Chiller Submittal VD-08:** Vendor submittal VD-08 for ACCH-500 belongs to the comfort cooling system and is explicitly not part of the PCW loop. It was reviewed and excluded.
5. **Domestic Water Pumps Spec 22 11 23:** Specification 22 11 23 covers domestic water booster sets and disinfection, which do not apply to the PCW system. It was reviewed and excluded.

---

## 4. SAFETY AND HAZARD COMMUNICATION (29 CFR 1910.1200)

All chemical operations comply strictly with OSHA Hazard Communication Standard 29 CFR 1910.1200 and the project Safety Data Sheet (SDS) pack (VD-07):
* **Hazard Identification:**
  * CL-100 & CL-210: Skin Corrosion Category 1B, Eye Damage Category 1. Signal Word: DANGER. Causes severe skin burns and eye damage.
  * MO-500 & PS-330: Skin Irritation Category 2, Eye Irritation Category 2A. Signal Word: WARNING.
  * TA-90: Acute Toxicity Category 4, Eye Irritation Category 2A. Signal Word: WARNING. Harmful if swallowed.
  * PD-45: Eye Irritation Category 2A. Signal Word: WARNING.
* **Engineering Controls & Handling:**
  * Chemical transfers and dosing are conducted by trained commissioning personnel using closed-loop chemical injection quills on the skid suction manifold.
  * Per SDS Section 4 and 29 CFR 1910.1200, an ANSI Z358.1 compliant emergency eyewash and quick-drench shower station is installed and functional within 10 seconds (unobstructed walking distance) of all chemical handling and tie-in points.
* **Personal Protective Equipment (PPE):**
  * Handlers must wear chemical splash goggles, full-face shields, chemical-resistant butyl/nitrile gloves, chemical-resistant aprons, and steel-toed rubber boots during all chemical transfer, dosing, and sampling operations.
* **Storage and Spill Containment:**
  * All chemical packages are stored in the designated covered laydown pad at the yard (C-101) within secondary containment pallets rated for >= 110% of package capacity.
  * Spill kits containing neutralizers, absorbent pads, and containment booms are staged adjacent to each tie-in location.
* **Emergency Response:**
  * In the event of skin or eye contact, immediately flush with copious water for not less than 15 minutes at the emergency drench shower/eyewash and summon site emergency medical services.
  * Supplier emergency contact: Cascadia Water Technologies at 1-800-555-0142.
