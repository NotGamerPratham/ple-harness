# METHOD OF PROCEDURE — Process Cooling Water Cleaning, Flushing and Passivation
## Tull Creek Data Hall — PCW turnover package (Section 23 25 16)

### 1. SCOPE AND SEQUENCE
Eight tie-in-bounded PCW circuits (C1–C8) are mechanically complete and must each be flushed, chemically cleaned, rinsed, passivated, held for film formation and brought to the maintenance treatment programme before turnover. The work is executed with the rented fleet (FS-600-A, FS-600-B, FS-1200-A), two commissioning crews, the metered construction-water supply, the single authorised sewer discharge point MH-14, and the temporary power at each tie-in, all within the contractual milestones of CX-01 (TM-0 h0 … TM-4 day 47).

Circuits, tie-in locations and governing segments (from M-603, M-601, the P&ID Rev C sheets and the isometrics M-ISO-2xx):

| Circuit | Lines | Components (M-602) | Location | Static lift | V_f (gal) | V_s (gal) | eta | Skid | Q_min (gpm) |
|---|---|---|---|---|---|---|---|---|---|
| C1 | 1041,1042,1043,1044 | PMP-101,BT-101 | MER-1 | 26 ft | 32983 | 32983 | 0.62 | FS-1200-A | 1181 |
| C2 | 2011,2012,2013 | HX-201A | MER-1 | 22 ft | 5596 | 7946 | 0.62 | FS-600-A+FS-600-B | 624 |
| C3 | 2021,2022,2023 | HX-201B | MER-2 | 22 ft | 6203 | 8553 | 0.62 | FS-600-A+FS-600-B | 720 |
| C4 | 4021,4022,4023,4024 | CDU-301,CP-311 | L3-N | 48 ft | 5957 | 8537 | 0.45 | FS-600-A | 360 |
| C5 | 4031,4032,4033,4034 | CDU-302,CP-321 | L3-S | 44 ft | 6406 | 8986 | 0.45 | FS-600-B | 476 |
| C6 | 4041,4042,4043 | CP-331 | L3-W | 48 ft | 4227 | 5677 | 0.45 | FS-600-A | 360 |
| C7 | 5011,5012,5013 | CL-401 | ROOF | 72 ft | 4086 | 6036 | 0.45 | FS-600-B | 295 |
| C8 | 6011,6012,6013 | ST-601 | YARD | 14 ft | 5791 | 5791 | 0.62 | FS-600-A | 151 |

### 2. EXECUTION NARRATIVE (per circuit, per stage)
Each circuit follows the same seven-stage sequence. HYDRO is owed only where CX-02 has no accepted chart on file (01 91 13 cl.1.3): the hydrostatic charts TR-0414/0416/0417/0418 cited for C3, C5, C6 and C7 are not in the commissioning records, so those four circuits are re-tested at 127.5 psig for 120 min with the lump-sum hydrostatic test pump (the flush skids cannot reach test pressure and are not intended to, 23 25 16 cl.3.10f). C1, C2, C4 and C8 are recorded PASS with charts TR-0412/0413/0415/0419 on file and are not re-tested (23 21 16 cl.3.3); their HYDRO rows are filed at zero duration and no water.

**INITIAL_FLUSH** — one full circuit displacement (n_f = 1) at the declared flow with the 40-mesh (380 µm) temporary strainer in each skid discharge and the temporary bypass spools fitted to every M-602 component that has a bypass provision (C2–C7). Bypassed components are isolated from construction debris.

**CHEM_CLEAN** — the cleaner scheduled for the circuit's metallurgy in VD-06 is dosed on the SYSTEM volume at the volumetric application rate (CL-100 1.5 gal/1000 gal for carbon/copper steel; CL-210 2.0 gal/1000 gal for the galvanized riser C8 and the aluminium cold-plate circuit C6, which cannot take high pH — UFC cl.10-1.1, VD-04). The polyacrylate dispersant PD-45 is carried at 5 ppm active (UFC cl.5-3.7). The charge is circulated for 24 h (UFC cl.5-7.3.2.2b), then drained and the strainers cleaned. Spent cleaner from C4–C8 carries copper/zinc taken up from copper pipe/galvanizing (VD-06 Note 3) and is hauled to a permitted facility; C1–C3 spent cleaner is sewered.

**DRAIN_RINSE** — n_r full circuit-volume displacements computed from the project rinse model C_n = C_mk + (C0 − C_mk)·exp(−η·n) until the rinse endpoint of UFC cl.5-7.3.2.2 is met (conductivity ≤ 1.1·C_mk and pH 7.5–8.5). C_mk (makeup conductivity) and the spent-solution conductivities C0 are read from SW-02 and VD-06 Note 3 (see §6 on the unreadable scans). The circuit is left full at the last displacement, so rinse effluent is one displacement less than the rinse draw. Bypass spools remain fitted through the rinse so the protected components are not flushed and are filled later at turnover.

**PASSIVATE** — the passivation inhibitor of UFC Table 5-11 is dosed on the SYSTEM volume into the water standing at the end of the rinse and circulated one displacement plus 30 min to distribute (UFC cl.5-7.3.2.2d). Molybdate (50 ppm Mo, 10–12 day film) is used for the carbon/copper-steel circuits (C1–C5, C7); polysilicate (50 ppm SiO2, 10–12 day film) for the aluminium circuit C6 and the galvanized riser C8 (aluminium and galvanized cannot take pH > 8.5). Tolyltriazole at 10 ppm is carried wherever copper is wetted (C4–C7). Soda ash (SA-100) adjusts the molybdate circuits to pH 8.5–9.5. pH is controlled to the intersection of the bands where two inhibitors are carried (C4–C7).

**HOLD** — the film-formation hold is 10 days (the 10–12 day band, current edition), measured in occupied hours but executed unattended: the skid is released and the crew stands down for the hold (23 25 16 cl.3.10b).

**FINAL_FILL / TURNOVER** — every circuit is brought to the maintenance residual by RETAIN_AND_TOP_UP (permitted because the maintenance residual — 125 ppm Mo or 80 ppm SiO2 — is not below the passivation residual of 50 ppm, so the top-up raises rather than dilutes, cl.3.8). The circuit is topped to SYSTEM volume with treated makeup carrying the maintenance increment (the difference 75 ppm Mo or 30 ppm SiO2); for C1 and C8, V_s = V_f so the top-up volume is zero and the increment is added as a slug. The molybdate circuits retain their charge, so no molybdate is discharged (VD-06 Note 5 / UFC discharge note). The circuit is recirculated 30 min and sampled while circulating. Temporary strainers are removed at TM-4.

### 3. SKID ASSIGNMENT AND HYDRAULICS
Flushing flow is the greater of the UFC foulant-suspension velocity (3.28 fps, cl.5-3.7) and the project velocity class (4.0 fps for plate-HX / cold-plate circuits C2–C6, 2.0 fps otherwise, so 3.28 fps governs C1, C7, C8). The governing segment is the line of the smallest total flow area. Each skid is checked to deliver the required flow against the circuit head (static lift + main-path Darcy loss + in-path component dP + per-skid hose/strainer loss, cl.3.2):

| Circuit | Skid | Q (gpm) | Gov seg | v (fps) | Re | Req head (ft) | Avail head (ft) | Power (kW/avail) |
|---|---|---|---|---|---|---|---|---|
| C1 | FS-1200-A | 1181 | 1043 (6.065in x4) | 3.28 | 153497 | 88.2 | 119.6 | 75/150 |
| C2 | FS-600-A+FS-600-B | 624 | 2011 (7.981in x1) | 4.0 | 246327 | 59.1 | 161.3 | 60/150 |
| C3 | FS-600-A+FS-600-B | 720 | 2023 (6.065in x2) | 4.0 | 187191 | 70.3 | 154.2 | 60/95 |
| C4 | FS-600-A | 360 | 4021 (6.065in x1) | 4.0 | 187191 | 98.9 | 154.2 | 30/90 |
| C5 | FS-600-B | 476 | 4033 (4.026in x3) | 4.0 | 124259 | 129.9 | 134.9 | 30/90 |
| C6 | FS-600-A | 360 | 4041 (6.065in x1) | 4.0 | 187191 | 102.0 | 154.2 | 30/90 |
| C7 | FS-600-B | 295 | 5011 (6.065in x1) | 3.28 | 153497 | 107.1 | 163.4 | 30/45 |
| C8 | FS-600-A | 151 | 6013 (3.068in x2) | 3.28 | 77647 | 66.8 | 175.9 | 30/120 |

C1 requires the FS-1200 (the two FS-600 in parallel reach only ~1120 gpm < 1181 gpm required); all other circuits are served by one or two FS-600 units. C5 is the tightest skid-duty margin (5.0 ft of 135 ft). All duty points are within the published curves (cl.3.2f) and within the panel kW (SW-04/E-701). FS-1200-A is not available before hour 48 (SI-05); C1 starts at h96 to avoid the reduced metered days 2–3 and the metered-out day 6 (SI-04).

### 4. RINSE DESIGN
Makeup conductivity C_mk = 100 µS/cm (SW-02) and spent-solution conductivities C0 = 2600 (CL-100) / 2150 (CL-210) µS/cm (VD-06 Note 3). Mixing efficiency η = 0.45 for the cold-plate/coil-bank circuits (C4–C7) and 0.62 for the others. The chosen displacements n_r (10 for C1–C3, C8; 13 for C4, C5, C7; 13 for C6) leave the post-rinse conductivity at 104–107 µS/cm against the 110 µS/cm endpoint:

| Circuit | Cleaner | eta | n_r | C_n (µS/cm) | Endpoint (µS/cm) | Rinse margin |
|---|---|---|---|---|---|---|
| C1 | CL-100 | 0.62 | 10 | 105.1 | 110 | 0.0448 |
| C2 | CL-100 | 0.62 | 10 | 105.1 | 110 | 0.0448 |
| C3 | CL-100 | 0.62 | 10 | 105.1 | 110 | 0.0448 |
| C4 | CL-100 | 0.45 | 13 | 107.2 | 110 | 0.0255 |
| C5 | CL-100 | 0.45 | 13 | 107.2 | 110 | 0.0255 |
| C6 | CL-210 | 0.45 | 13 | 105.9 | 110 | 0.0372 |
| C7 | CL-100 | 0.45 | 13 | 107.2 | 110 | 0.0255 |
| C8 | CL-210 | 0.62 | 10 | 104.2 | 110 | 0.0531 |

Cascades (cl.3.6): the final clean rinse displacement of C8 (Vf 5,791 gal) is cascaded into C2 as its first displacement, and the final clean displacement of C6 (Vf 4,227 gal) into C7. Each donor's rinse is scheduled to complete before the receiver begins, so the donated volume is makeup-quality water; each counts as one full displacement for the receiver. The other six circuits rinse from the metered supply. These two cascades save 9,682 gal of makeup draw (the receiver displacement volumes) and reduce donor effluent by the same.

### 5. WATER, EFFLUENT AND DISCHARGE
Programme draw = 941516 gal (metered 850821, trucked 90695 at the reduced days and on the C1 draw days that exceed 62,000 gal). Programme-wide average water rate = $7.510/kgal (cl.3.10c). Total effluent = 857007 gal; the 540,000 gal sewer cap (RFI-031) is fully used and 317016 gal is hauled (the copper/zinc-bearing chem-clean streams of C4–C8 plus the over-cap excess). Peak day draw is 91184 gal against the 92,000 gal hard daily cap (62,000 metered + 30,000 trucked); the programme water margin on that cap is 0.008868. Day 6 metered allocation is zero (SI-04); no draw is scheduled that day.

### 6. DESIGN BASIS — GOVERNING CONSTRAINT PER CIRCUIT
For each circuit the governing constraint is the one of the five candidate families that this plan leaves the least room against; margin = (limit − achieved)/limit (upper limits) stated as a decimal. The five candidate margins per circuit are tabulated, and the binding one named on the required line.

| Circuit | Head | Rinse | Discharge | Daily water | Power | Governing |
|---|---|---|---|---|---|---|
| C1 | 0.262129 | 0.044786 | 0.000017 | 0.008868 | 0.500000 | AUTHORISED PROGRAMME DISCHARGE VOLUME |
| C2 | 0.633528 | 0.044786 | 0.000017 | 0.008868 | 0.600000 | AUTHORISED PROGRAMME DISCHARGE VOLUME |
| C3 | 0.543893 | 0.044786 | 0.000017 | 0.008868 | 0.368421 | AUTHORISED PROGRAMME DISCHARGE VOLUME |
| C4 | 0.358355 | 0.025457 | 0.000017 | 0.008868 | 0.666667 | AUTHORISED PROGRAMME DISCHARGE VOLUME |
| C5 | 0.037291 | 0.025457 | 0.000017 | 0.008868 | 0.666667 | AUTHORISED PROGRAMME DISCHARGE VOLUME |
| C6 | 0.338422 | 0.037238 | 0.000017 | 0.008868 | 0.666667 | AUTHORISED PROGRAMME DISCHARGE VOLUME |
| C7 | 0.344377 | 0.025457 | 0.000017 | 0.008868 | 0.333333 | AUTHORISED PROGRAMME DISCHARGE VOLUME |
| C8 | 0.620066 | 0.053088 | 0.000017 | 0.008868 | 0.750000 | AUTHORISED PROGRAMME DISCHARGE VOLUME |

GOVERNING CONSTRAINT C1: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)
GOVERNING CONSTRAINT C2: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)
GOVERNING CONSTRAINT C3: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)
GOVERNING CONSTRAINT C4: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)
GOVERNING CONSTRAINT C5: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)
GOVERNING CONSTRAINT C6: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)
GOVERNING CONSTRAINT C7: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)
GOVERNING CONSTRAINT C8: AUTHORISED PROGRAMME DISCHARGE VOLUME (margin 0.000017)

The programme is discharge-volume-bound: the 540,000 gal sewer authorisation is fully consumed by the lowest-cost plan (sewer is far cheaper than the $168/kgal tanker, so every sewerable gallon is sent to MH-14 up to the cap), leaving zero margin on that family for every circuit. The next-tightest programme constraint is the daily-water hard cap (margin 0.008868, peak day 91184/92,000). The tightest circuit-specific margins are C5 skid head (0.037291) and the C4/C5 rinse endpoints (0.025457); these are recorded in the table above and are the binding circuit-specific constraints should the discharge cap be read per-circuit. The rinse margin is given in the conductivity form (the tighter of the two permitted forms — displacements vs conductivity); in displacements it is larger (e.g. C1 (10−8.91)/10 = 0.109).

### 7. CONFLICTS, JUDGEMENT CALLS AND DEFECTS
- **Superseded/cancelled documents.** UFC 3-240-13FN (2005) is cancelled and is NOT used (23 25 16 cl.1.2); M-PID-103 Rev A is superseded by Rev C (M-601 Note 5). Neither is cited as authority in the constraint register; the current UFC 3-230-13 (2023) and Rev C drawings govern.
- **Missing hydrostatic evidence (defect).** CX-02 records all eight circuits PASS, but the pressure charts cited for C3, C5, C6 and C7 (TR-0414/0416/0417/0418) are not in the commissioning records. Per 01 91 13 cl.1.3 a result is accepted only with its cited evidence on file, so those four tests are NOT accepted and the circuits are re-tested before chemical cleaning. The four charts that ARE on file (TR-0412/0413/0415/0419 for C1/C2/C4/C8) stand.
- **Unreadable scanned documents (defect).** SW-02 (makeup water analysis) and SW-03 (sewer discharge authorisation, both the original and Rev B) are scanned images with no text layer and cannot be machine-read; no OCR is available in this workspace. Engineering assumptions made in their absence, to be confirmed against the originals before execution: C_mk = 100 µS/cm and makeup pH ≈ 7.6 (SW-02); sewer rate = $5.20/kgal and discharge pH/temperature band 6.0–104 °F (SW-03). The rinse n_r are chosen robust down to C_mk ≈ 75 µS/cm so a lower true makeup conductivity does not fail the rinse gate. The discharge pH lower limit (6.0) and temperature upper limit (104 °F) are typical POTW local limits; the actual SW-03 values must be substituted before any discharge.
- **Program selection by paragraph text, not selection table.** UFC Table 6-2 lists polysilicate-azole only for diesel-jacket systems, but the paragraph text of cl.6-2.2.5 states the programme is especially beneficial where aluminium is present; per 23 25 16 cl.3.5 the paragraph text governs, so C6 (aluminium cold plates, VD-04) and C8 (galvanized) use polysilicate-azole at pH 7.5–8.5.
- **Passivation vs maintenance table.** Nitrite is not tabulated in the passivation table (Table 5-11), so the passivation technology is molybdate or polysilicate (which ARE tabulated, with film-formation times); the closed-system maintenance residual is then met at turnover. Molybdate maintenance (125 ppm) ≥ passivation (50 ppm), so RETAIN_AND_TOP_UP is permitted and no molybdate is discharged.
- **Fine filtration (excluded scope).** The temporary strainer is 380 µm (40 mesh); the cold plates (50 µm, VD-04) and CDUs (300 µm, M-602) require finer filtration than the strainer provides when those components are in the flow path at turnover. That fine filtration is provided within the lump-sum mobilisation (cl.3.10f) and appears here, with no price line.
- **Film-formation hold attended/unattended.** UFC cl.5-7.3.2.4 says maintain and circulate for the time required; 23 25 16 cl.3.10b explicitly releases the skid and does not charge the unattended film-formation hold. The project Section is the more specific cost basis and governs; the hold is executed unattended (skid released).
- **Galvanized riser (RFI-022).** Confirmed galvanized; cleaned with the neutral CL-210 (not the alkaline CL-100) and passivated with polysilicate at pH ≤ 8.5 to avoid white rust (UFC cl.5-7.3.2).

### 8. SAFETY — HAZARD COMMUNICATION (29 CFR 1910.1200)
Every product brought on site (CL-100, CL-210, MO-500, PS-330, NB-700, TA-90, PD-45, SA-100) has a Safety Data Sheet in the VD-07 pack and on site before first use (CX-03 item 10). CL-100, CL-210 and SA-100 are Skin Corr. 1B / Eye Dam. 1 (DANGER); the azoles, molybdate, polysilicate, dispersant and nitrite-borax blend are Eye Irrit. 2A (WARNING). Obligations discharged: SDSs maintained at the handling point and accessible to every worker; containers labelled per the HCS; an emergency eyewash and a quick-drench shower within 10 seconds of the transfer point (VD-07 Section 4); chemical splash goggles, face shield and chemical-resistant gloves and apron worn when transferring (VD-07 Section 8); workers trained on the hazards and first aid (flush eyes 15 min with water) before handling. Spent cleaning solution is corrosive/alkaline and is drained to the route declared for it; the tanker stands only at the yard pad (C-101). No product is discharged to the storm system or to Tull Creek (RFI-031).

### 9. MILESTONES
Chemical cleaning complete by h288 (TM-2 day 22 = h528). Passivation charge dosed by h385; film-formation hold 10 days. Turnover (final fill) complete by h626 (TM-4 day 47 = h1128). All within the contractual milestones (CX-01).
