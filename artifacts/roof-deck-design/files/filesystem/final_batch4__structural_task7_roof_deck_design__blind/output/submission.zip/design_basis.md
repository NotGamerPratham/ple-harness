# DC-2 Helena Data Centre, Building A — Roof Deck Design Basis

## 1. Governing documents

The structural design criteria for the roof are **EOR-DC-RD-01, Revision 2** (31 July 2026, current for construction); Revision 1 is superseded and was not used. Where the adopted building code is modified for DoD work, **UFC 3-301-01 Structural Engineering (2023, Change 6)** governs and is cited in the criteria. The ground snow load is taken only from the site-specific **SNOW-2026-014 Rev 0** case study (pg = 63 psf on a Risk Category II basis); the snow importance factor Is = 1.10 is applied once, by the criteria, and is not built into pg. The lateral system, the roof-level forces and the chord/collector capacities and in-plane stiffnesses are taken from **LAT-2026-003 Rev 1**. The deck product is **NORDECK B-36 (2026 Edition)**; its load, deflection, diaphragm and fastener tables are reproduced from their stated basis. Unit rates and availability are from **Cost Plan CP-RD-2026** and **Deck Stock Availability 2026-07**.

The three-dimensional record of the roof is the **IFC roof structure model, Revision C**; the model transmittal note states that where the model and the 2-D drawings differ, the model governs. Plan positions and heights of the equipment enclosure, screen walls, rooftop units, parapets and framed openings were read from the model geometry and the mechanical equipment schedule. In particular the SCR-N and SCR-E screen-wall positions were taken from the model (they were relocated after A-201 Rev B). The framed openings (RO-1 96-108,48-60; RO-2 132-144,120-132; RO-3 180-210,60-80 ft) are confirmed on S-101 Rev 3.

## 2. Snow basis

pg = 63 psf (SNOW-2026-014, RC II). pf = 0.7 Ce Ct Is pg = 0.7 x 0.90 x 1.00 x 1.10 x 63 = 43.66 psf. gamma = 0.13 pg + 14 = 22.19 pcf. hb = pf/gamma = 1.97 ft. Drifts are computed by criteria clause 5.4 for each obstruction face and each of the four wind directions; the design surcharge at a point is the largest from the four directions (not superimposed). The four drifts reported are: MEP-PH-1 west face peak 104.3 psf over x = 41-60 ft; SCR-N south face peak 89.5 psf over y = 148-164 ft; the north parapet (inside face) peak 34.0 psf over y = 168-180 ft; RTU-1 east face peak 98.2 psf over x = 36-54 ft. The maximum gravity demand on the deck is dead + balanced snow + peak drift = about 171 psf at the worst drift face, which requires 18 gage (catalogue allowable 177 psf).

## 3. Seismic basis

SDS = 0.44, SD1 = 0.24, Site Class D, SDC D, Ie = 1.25, R = 3.25, Omega0 = 2.0, rho = 1.0 (criteria clause 7.1). The roof dead weight for the effective seismic weight is 18 psf (lateral report Table 5-2). Because the flat roof snow load pf = 43.66 psf exceeds 30 psf, clause 7.2 requires 20% of pf = 8.73 psf to be added to the effective seismic weight; the effective seismic weight is therefore 26.73 psf. The total seismic weight W = 26.73 x 240 x 180 / 1000 = 1154.8 kip. Cs = SDS Ie / R = 0.1692. Fpx = Cs W = 195.4 kip, which lies between the bounds 0.2 SDS Ie W (127 kip) and 0.4 SDS Ie W (254 kip), so Fpx = 195 kip governs. The seismic inertial force is spread uniformly over the plan (lateral report 5.3); accidental torsion is applied at 0.05 of the plan dimension perpendicular to the force, in the sense giving the greater effect (criteria 7.3).

## 4. Diaphragm analysis and classification

The roof was analysed as the in-plane assembly described in the lateral report: shear panels (one joist bay by one girder bay, discretised on the 6 ft x 6 ft checking grid with the catalogue G' of the selected deck) carrying pure shear, axial bars along every joist line (EA = 87,580 kip) and every girder line (EA = 221,850 kip), the perimeter edge member L5x3-1/2x5/16 (EA = 74,240 kip) on the boundary, and each braced frame as a spring of half its published stiffness at each of its two column lines. Framed openings are holes in the shear field with axial frame members around them. A small regularising spring on every free degree of freedom stabilises the solution; in every scenario less than 2% of the applied force is carried by those springs, so a complete load path exists.

The deck G' follows from the deck selected (catalogue clause 5.2). The distribution of the roof force between the eight braced frames is computed from the frame stiffnesses and positions, not assumed by tributary width; the frames are of unequal stiffness and asymmetrically placed (grid A frames k = 55 kip/in, grid G frames k = 18 kip/in), so inherent torsion is present in both directions.

The maximum in-plane deflection is reported relative to the supporting frame lines (excluding rigid-body translation of the supports). Under the wind cases the deflections are 1.05 in (along x) and 1.15 in (along y), within the 1.60 in limit of clause 9.2. Under the seismic cases the deflections are larger (about 1.54-1.79 in) because the seismic force (195 kip) exceeds the wind force and the grid G x-frames are soft (k = 18 kip/in); the allowable storey drift for RC III is 0.015 x 32 = 0.48 ft = 5.76 in, so twice the storey drift is 11.52 in. The seismic diaphragm deflection (1.79 in) is well below 11.52 in, so the diaphragm is classified **semi-rigid** and was analysed with its finite in-plane stiffness. The maximum chord force is 30 kip (capacity 38 kip, splice governs). The maximum collector (W12x26) force is 22 kip unamplified in the x direction and 40 kip in the y direction; amplified by Omega0 = 2.0 for the S10 collector case the x-direction collector force is 45 kip, below the 58 kip collector splice capacity the lateral report identifies.

## 5. Zoning decisions

Procurement (OBD section 5; Deck Stock 2026-07): the project release-to-site allowance is 9 weeks. 16 gage is a 14-week mill order and is therefore **not available**; 22, 20 and 18 gage are ex stock. The deck is therefore 18 gage throughout (one gage).

A single attachment pattern is used over the whole roof:
- **Z1 — 18 gage, 36/9 support pattern (9 HX-12 fasteners across the 36 in cover width at every support), 5 SCREW-10 sidelap connectors per span** (G' = 45.6 kip/in, nominal diaphragm shear Sn = 1751 plf, design shear phi_d Sn = 1226 plf).

This single pattern satisfies every demand on the roof and is the stiffest available 18 gage pattern, which keeps the in-plane diaphragm deflection as low as the available material allows:
- Gravity: the maximum total load (dead + balanced snow + peak drift) is about 171 psf, within the 18 gage 3-span allowable of 177 psf (catalogue Table 3-1).
- Uplift: the components-and-cladding Zone 3 corner uplift is 101.2 psf; the 36/9 attachment provides 126 psf of uplift resistance (0.9 dead + phi_t pull-over), so the corner zone is satisfied, and all lower-pressure zones are satisfied by the same pattern.
- Diaphragm shear: the maximum shear is about 1045 plf (concentrated at the opening corners and the stiff frame lines), within the 1226 plf design shear capacity.
- Boundary rule (clause 10.4): every deck zone touches the roof perimeter (and the 36/9, 5-sidelap pattern exceeds the 36/7, 3-sidelap boundary minimum), and the opening edges are framed out.

Sidelap connectors are spaced at not more than 36 in (5 per 6 ft span, well within the 36 in spacing of clause 10.3). The deck bears 1.5 in minimum on every support and is continuous over at least three spans.

The roof is divided into **9 rectangles** (the deck plan minus the three framed openings, split on the 6 ft module around each opening) — comfortably within the 14-rectangle buildability limit, and a single zone. The 16 gage that would further reduce the seismic deflection is excluded by the 9-week release-to-site allowance; the 18 gage 36/9-5 pattern is the stiffest available gage and pattern, and the lowest-cost single-pattern design that satisfies all gravity, uplift, diaphragm-shear, chord, collector and attachment requirements.
