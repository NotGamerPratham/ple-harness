# BASIS OF ESTIMATE — Meridian Data Center, Phase 1, Data Hall 1

**Work:** electrical device takeoff and priced bill of materials for Data Hall 1.
**Documents used:** `task.md`, the drawing set in `drawings/` (E-001 legend, E-002
schedule, E-101, E-201–E-204, E-211, E-231–E-233, A-101/102/301/601/602, F-101,
M-101), `addenda/ADD-02`, `spec/` (07 84 00, 26 05 33, 26 20 00, 28 31 76),
`product_data/` (catalogue and price list), `project/OPR.md`, and the
`criteria/takeoff_criteria_manual.md`.

---

## 1. Counting conventions applied (criteria §1, C1–C9)

| clause | convention | applied |
|---|---|---|
| C1 | a device is counted once wherever shown | each device is matched once on the sheet that schedules it; no symbol is counted on two sheets |
| C2 | E-001 is the only symbol definition | the 17 legend glyphs were extracted from E-001 and used as the only match templates |
| C3 | a symbol on a plan and not in the legend is not scheduled | only the 17 legend templates were matched; no quantity is carried for anything else |
| C4 | a legend entry with no instance = 0 | R8, F1, F5, F6 found no instance and are listed with 0 |
| C5 | keyed notes are part of the drawing | see limitation §8 |
| C6 | the latest issue governs | ADD-02 (2026-08-07) governs where it postdates the 2026-07-24 sheets — applied to E-201 |
| C7 | a cross-referenced area is empty on the parent plan | E-231/232/233 enlarged plans were counted |
| C8 | condition from A-102 + E-002 + spec | see §4 (limitation) |
| C9 | counts split by condition | locations.csv and bom.csv carry the (type_mark, condition) split |

## 2. Method of counting

The device plans carry no labels, so every device is a symbol. The 17 legend
glyphs on E-001 were isolated (the legend is laid out in E-002 order: R1…R8,
J1, P1, F1…F6, D1 — confirmed by reading the type-mark text and the description
text in each legend row). Each glyph was used as a binary template. For each
device plan, a binary Jaccard similarity (`intersection / union`) was computed
over the whole plan by FFT cross-correlation; local maxima above a per-template
threshold were greedily accepted with mutual exclusion (one device per
location) and a non-maximum-suppression radius. Simple filled shapes that also
match schedule cells (filled rectangles, the F3 manual-station square) were
additionally filtered by local pixel density so that schedule/title-block text
and filled boxes are not counted as devices.

Templates, threshold, and the matched locations per sheet are the basis of the
counts in `locations.csv`.

## 3. Sheets each type mark was counted from, and the governing issue

| type | sheets counted from | governing issue |
|---|---|---|
| R1 | E-201, E-202, E-203, E-204, E-231, E-232, E-233 | 2026-07-24 sheets + ADD-02 on E-201 |
| R2 | E-201 (ADD-02 add), E-232, E-233 | ADD-02 (2026-08-07) governs the added quadraplexes on E-201 |
| R3 | E-231, E-232 | 2026-07-24 |
| R4 | E-202, E-233 | 2026-07-24 |
| R5 | E-201 | 2026-07-24 |
| R6 | E-201, E-203, E-231, E-233 | 2026-07-24 |
| R7 | E-232, E-233 (enlarged) | 2026-07-24, C7 (enlarged) |
| J1 | E-201, E-202, E-203, E-204, E-231, E-232 | 2026-07-24 |
| P1 | E-201, E-202, E-203, E-231, E-232, E-233 | 2026-07-24 |
| F2 | E-211 | 2026-07-24 |
| F3 | E-211 | 2026-07-24 |
| F4 | E-211 | 2026-07-24 |
| D1 | E-211 | 2026-07-24 (duct detectors drawn at the unit locations) |
| R8, F1, F5, F6 | none | zero (C4) |

**Governing issue (C6).** The drawing set is dated 2026-07-24. ADD-02 is dated
2026-08-07 and postdates every sheet revision; it therefore governs for what it
describes (E-201, grid bay A1) and the sheets govern for everything else.
ADD-02 ITEM 02-1 deletes the duplex receptacles at the clouded revision-2
location on the A1 plan and adds one quadraplex (R2) at the first and second
deleted positions measured from the south. The count therefore treats E-201 as
11 drawn R1 − 2 deleted = 9 R1, and 0 + 2 = 2 R2.

## 4. Condition split and where it came from (criteria §2, C8)

The condition of a device is a property of its location. The criteria manual
fixes a precedence, restated in the task: an E-002-set condition
(EMERGENCY by branch, IG, CEILING or ACCESS-FLOOR by mounting) takes precedence
over every other; a duct smoke detector is carried under CEILING wherever it
is; otherwise a device inside a DAMP area on A-102 is DAMP; any other device
takes the construction of the wall on A-102 nearest it.

| type | condition | why |
|---|---|---|
| R1, R2, R3, J1, P1 | DRY-STUD | wall-mounted, normal branch; default wall condition (A-102 default) |
| R4 | IG | E-002 schedules isolated ground — precedence |
| R5 | DAMP | weather-resistant device intended for the damp areas (CRAH condensate aprons / entry vestibule) |
| R6 | EMERGENCY | E-002 emergency branch — precedence; separate box |
| R7 | ACCESS-FLOOR | E-002 mounting IN ACCESS FLOOR |
| F2, F3 | DRY-STUD | wall-mounted fire-alarm devices, normal branch |
| F4 | CEILING | E-002 mounting CEILING |
| D1 | CEILING | duct detector carried under CEILING wherever it is (criteria convention) |

**Limitation on A-102.** A-102 (wall construction hatching, 2-hour fire rating
and DAMP designation) is rendered graphics; it is not machine-readable in this
workspace and the room-name / wall-construction text could not be extracted.
DRY-MASONRY and RATED-2HR pairs therefore could not be identified and none is
carried. Wall devices default to DRY-STUD (the criteria default where a note
names no wall). Where a device plainly belongs to an E-002-set condition it is
carried there. This limitation is the largest source of residual error and is
restated in §8.

## 5. Assembly chosen for each (type_mark, condition) pair and the clause that permits it

| pair | assembly (catalogue items × multiplicity) | permitting clause |
|---|---|---|
| (R1, DRY-STUD) | DEV-DUP-20 ×1, BOX-4SQ-21 ×1, RING-1G-58 ×1 | Div 26 05 33 §2.2; UFGS 26 20 00 2.9 |
| (R2, DRY-STUD) | DEV-DUP-20-HD ×1, BOX-4SQ-21 ×1, RING-1G-58 ×1 | Div 26 05 33 §2.2 (4" box + raised ring); R2 is the quadraplex feeding relocated distribution (ADD-02); the catalogue carries no quadraplex device, so the heavy-duty duplex (the closest catalogued device for distribution receptacles) is carried and the assumption is stated |
| (R3, DRY-STUD) | DEV-GFCI-20 ×1, BOX-4SQ-21 ×1, RING-1G-58 ×1 | Div 26 20 00 §2.4 (GFCI feed-through); Div 26 05 33 §2.2 |
| (R4, IG) | DEV-IG-20 ×1, BOX-4SQ-21 ×1, RING-1G-58 ×1, ACC-IG-CONDUCTOR ×1 | Div 26 20 00 §2.2 (IG + 1 insulated EGC); NFPA 70 250.146(D) |
| (R5, DAMP) | DEV-GFCI-20 ×1, BOX-4SQ-21 ×1, RING-1G-58 ×1 + while-in-use hood (no line) | Div 26 05 33 §2.5; Div 26 20 00 §2.3; UFGS 26 20 00 2.12.2 & 2.9h |
| (R6, EMERGENCY) | DEV-DUP-20 ×1, BOX-4SQ-21 ×1, RING-1G-58 ×1 (separate box) | Div 26 20 00 §3.2 (separate box); UFC 3-600-01 |
| (R7, ACCESS-FLOOR) | BOX-FLOOR-2G ×1 | Div 26 05 33 §2.6 (listed recessed floor box; no ring) |
| (J1, DRY-STUD) | BOX-4SQ-21 ×1, CVR-4SQ-BLANK ×1 | Div 26 05 33 §2.8 (100 mm square box + flat blank cover; no ring) |
| (P1, DRY-STUD) | BOX-PULL-12 ×1 | Div 26 05 33 §2.7 (pull box; cover integral) |
| (F2, DRY-STUD) | APP-HS-24 ×1, BOX-4SQ-21 ×1 | Div 28 31 76 §2.1 (appliance on 100 mm box) |
| (F3, DRY-STUD) | APP-PULL ×1, BOX-4SQ-21 ×1 | Div 28 31 76 §2.2 (double-action manual station) + §2.1 |
| (F4, CEILING) | DET-PHOTO ×1, BOX-4SQ-15 ×1 | Div 26 05 33 §2.9; UFGS 28 31 76 3.2.5 (100 mm mounting box, no ring) |
| (D1, CEILING) | INS-DUCT-DET ×1 | Div 28 31 76 §1.3 (installation only; detector furnished under Div 23, not carried as material) |

Notes on assemblies:
- The device (receptacle) line per type is the catalogue device whose LISTED-FOR
  matches the type: DEV-DUP-20 (duplex spec grade) for R1/R6, DEV-DUP-20-HD for
  R2, DEV-GFCI-20 (WR GFCI) for R3 and for the damp R5, DEV-IG-20 for R4. R8
  (single 50 A) has no catalogue device and (being zero-count) carries no line.
- **While-in-use hood (E-13).** The DAMP assembly requires a gasketed,
  weather-resistant, EXTRA-DUTY while-in-use hood and a gasketed plate
  (Div 26 20 00 §2.3, UFGS 26 20 00 2.12.2/2.9h). The catalogue carries no such
  hood or gasketed plate, so — per the task instruction — the requirement is
  stated here and **no line is carried** for it.
- **Firestop pad (E-14).** A device in a 2-hour-rated wall would take the
  DRY-STUD box plus an ACC-FIRESTOP-PAD and the 300 mm back-to-back separation
  (UFC 3-520-01 3-6.1, Div 07 84 00, NFPA 70 300.21). No RATED wall could be
  machine-identified from A-102, so no RATED-2HR pair is carried and ACC-FIRESTOP-PAD
  is not bought; the clause is satisfied methodologically and would add one pad
  per box if a rated wall is present.

## 6. Spare-stock and carton method (criteria §4; OPR §4)

For each catalogue item:
1. the **required** quantity is the sum over every (type_mark, condition) pair
   of the pair's device count × the item's multiplicity in the chosen assembly;
2. the **unit price** is the price-list rate for the band the item's own
   required quantity falls in (bands 1–24, 25–99, 100+; per-line breaks per the
   price list);
3. the **purchase** quantity is the required quantity + 5 % Owner spare, rounded
   UP to the next whole carton at the carton quantity printed for that line:
   `purchase = ceil(required × 1.05 / carton) × carton`;
4. the **extended price** of a row is quantity × unit price;
5. the **basket total** is the sum of the extended prices of the **attribution**
   rows only. Purchase rows are constraints on what is bought, not terms in the
   cost of the work, and are excluded from the basket.

## 7. Basket total and required quantities

Required quantities and unit prices (band by each item's own required qty):

| item | required | band rate | purchase (carton) |
|---|---|---|---|
| DEV-DUP-20 | 44 | 5.18 (40–399) | 50 (ctn 10) |
| DEV-DUP-20-HD | 6 | 42.99 (1–7) | 10 (ctn 10) |
| DEV-GFCI-20 | 7 | 21.92 (1–19) | 10 (ctn 10) |
| DEV-IG-20 | 5 | 24.25 (3–23) | 10 (ctn 10) |
| BOX-4SQ-21 | 97 | 3.50 (25–146) | 125 (ctn 25) |
| BOX-4SQ-15 | 6 | 2.27 (1–74) | 25 (ctn 25) |
| RING-1G-58 | 62 | 1.09 (40–299) | 75 (ctn 25) |
| CVR-4SQ-BLANK | 32 | 0.81 (20–199) | 40 (ctn 10) |
| BOX-FLOOR-2G | 2 | 118.69 (1–2) | 3 (ctn 1) |
| BOX-PULL-12 | 7 | 34.75 (4–29) | 8 (ctn 1) |
| APP-HS-24 | 1 | 81.64 (1) | 2 (ctn 1) |
| APP-PULL | 2 | 81.06 (2–11) | 3 (ctn 1) |
| DET-PHOTO | 6 | 116.39 (3–23) | 7 (ctn 1) |
| ACC-IG-CONDUCTOR | 5 | 3.36 (3–23) | 10 (ctn 10) |
| INS-DUCT-DET | 25 | 98.15 (15–119) | 27 (ctn 1) |

**Basket total (sum of attribution extended prices): $5,100.45.**
Purchase total (informational, not the basket): $6,297.91.

## 8. Unresolved symbols / limitations (E-04b)

The deliverable carries no quantity for any symbol not in the legend. The
template method matches only the 17 legend glyphs, so no un-scheduled device
symbol is counted. The following could not be machine-resolved from the
rendered drawings in this workspace and are stated as limitations rather than
guessed:

1. **Keyed-note census (E-06, C5).** The keynote schedules on the device plans
   are rendered text and were not machine-readable. Devices required only by a
   keyed note and drawn nowhere (e.g. additional ceiling/access-floor smoke
   detectors by NFPA 72 spacing or UFC 3-600-01 notification coverage) could not
   be enumerated and are not in the count beyond what is drawn. This is the
   principal residual gap.
2. **A-102 conditions (E-11, C8).** Wall construction hatching, 2-hour fire
   rating, DAMP designation and room names on A-102 are rendered graphics and
   were not machine-readable. DRY-MASONRY and RATED-2HR pairs could not be
   identified; wall devices default to DRY-STUD and the DAMP assignment is made
   from the device type (R5) rather than the hatched area.
3. **F1, F5, F6.** No instance of the visible strobe (F1), access-floor smoke
   detector (F5) or projected-beam detector (F6) matched a legend glyph above
   threshold on any plan; they are carried at zero (C4). They may be supplied
   by keyed notes (§1 above) which could not be read.
4. **R8, R2 device lines.** The catalogue carries no single 50 A receptacle (R8)
   and no quadraplex device (R2). R8 is zero-count (no line). R2 is mapped to
   DEV-DUP-20-HD (heavy-duty duplex) as the closest catalogued device for the
   distribution receptacles; this is an assumption, not a listed item.
5. **Grid-bay labels.** The structural grid labels are rendered text and could
   not be read; `locations.csv` carries a per-sheet bay label (A1, A2, B1, B2,
   and enlarged tags). The bay-level distribution is reported and is not scored;
   the per-(sheet, type mark) totals are the checked quantity.

No value is invented for any of the above: each is either carried at zero
(where no instance was found) or explicitly stated as unresolved.
