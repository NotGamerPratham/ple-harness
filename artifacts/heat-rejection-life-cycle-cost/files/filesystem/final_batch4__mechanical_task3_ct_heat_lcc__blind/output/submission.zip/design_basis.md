# Condenser Water Heat Rejection Replacement — Design Basis
Papago Federal Center, Phoenix, Arizona
Engineer of Record: Sandoval Klee Mechanical Engineers, PC

## Governing Constraints

GOVERNING CONSTRAINT CUP: structural capacity (relative margin 0.0250)
GOVERNING CONSTRAINT ANNEX: electrical capacity (relative margin 0.0355)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0093)

## Documented Conflicts Resolution

CONFLICT 1: ADOPTED UFC 3-410-01 paragraph 2-4.2.4 | SET ASIDE GSA PBS-P100 paragraph 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 2026 edition | SET ASIDE UFC 3-230-13 2023 edition
CONFLICT 3: ADOPTED M-401 Revision C | SET ASIDE M-401 Revision B

## 1. Governing Documents and Authorities
This design basis establishes the engineering calculations, equipment selections, operating setpoints, and life-cycle cost analyses for the condenser water heat rejection plants serving the Courthouse Central Utility Plant (CUP), the Data Annex (ANNEX), and the Laboratory Wing (LAB). The governing documents and criteria are:
- **Design Criteria**: Mechanical Design Criteria Memorandum DC-02 Revision 3 (14 August 2026).
- **Life-Cycle Cost Criteria**: EC-01 Revision 0 (14 August 2026) under 10 CFR Part 436, Subpart A.
- **Economic Supplement**: Annual Supplement to NIST Handbook 135, 2025 edition (NIST data release doi:10.18434/mds2-3848). Real discount rate is 3.0% (DOE FEMP). Study period is 26 years (1-year construction period followed by a 25-year service period).
- **HVAC Criteria**: UFC 3-410-01, Heating, Ventilating and Air Conditioning Systems (28 July 2025, Change 1). Governs outdoor design conditions and mechanical code amendments.
- **Agency Facilities Standard**: GSA PBS-P100 Facilities Standards for the Public Buildings Service (2024). Governs plant configuration, cooling robustness redundancy (Tier 1), equipment clearances, and material restrictions.
- **Water Treatment Manual**: UFM 3-230-13, Industrial Water Treatment (5 February 2026). Governs circulating water chemistry, scaling indices (Puckorius Scaling Index), and cycles of concentration.
- **Reclaimed Water Allocation**: Municipal letters PW-LTR-014 (3 July 2026) and PW-LTR-019 (Amendment 1, 2 September 2026).
- **Electrical Distribution**: Panel schedules E-601 Revision C and RFI-034 Response 1 regarding retained loads on MCC-R3.
- **Equipment Submittals**: VD-01 (Cooling Tower CTX Series C), VD-02 (Fan and Motor Data), VD-03 (Chiller Condenser-Side Data), VD-04 (Drift Eliminator and Fill Options), and VD-05 (Budgetary Pricing and Service Life).

## 2. Resolution of Library Conflicts
1. **Conflict 1 (Outdoor Design Conditions for Tower Selection)**:
   - *Conflict*: PBS-P100 paragraph 5.3.1 prescribes sizing evaporative equipment at the 0.4% dewpoint with mean coincident dry bulb. In contrast, UFC 3-410-01 clause 2-4.2.4 and DC-02 paragraph 5.2 govern equipment sizing for open cooling towers and require adding 5.0 °F to the 1.0% annual wet-bulb temperature.
   - *Resolution*: ADOPTED UFC 3-410-01 paragraph 2-4.2.4 for sizing the cooling tower cells and design approach (giving an outdoor design wet bulb of 75.0 °F + 5.0 °F = 80.0 °F). SET ASIDE GSA PBS-P100 paragraph 5.3.1. PBS-P100 paragraph 5.1.3 governs the separate failure-case cooling robustness redundancy calculation, evaluated at the 0.4% evaporation wet bulb with the same 5.0 °F adder (76.0 °F + 5.0 °F = 81.0 °F), as confirmed by RFI-031 Response 1.
2. **Conflict 2 (Industrial Water Treatment Criteria Edition)**:
   - *Conflict*: The library contains both UFC 3-230-13 (2023) and UFM 3-230-13 (2026).
   - *Resolution*: ADOPTED UFM 3-230-13 2026 edition in accordance with DC-02 paragraph 2 and RFI-031 Response 3. SET ASIDE UFC 3-230-13 2023 edition as superseded. Circulating cycles of concentration are controlled to a Practical (Puckorius) Scaling Index of not less than 5.60 evaluated at the hottest waterside return temperature (CWR) and silica solubility limit of 150 ppm (Equation 5-8).
3. **Conflict 3 (Roof Mechanical Plan Revision)**:
   - *Conflict*: Drawings include superseded Revision B and current Revision C of M-401.
   - *Resolution*: ADOPTED M-401 Revision C, which fixes the current equipment zones, access aisles, and outdoor air intake coordinates. SET ASIDE M-401 Revision B as superseded.

## 3. Calculation Methodology
- **Climatic Basis**: Three complete calendar years (2022–2024) of NCEI Local Climatological Data for Phoenix Sky Harbor International Airport station (72278023183), filtering for FM-15 and FM-16 hourly observations (26,527 valid records).
  - Sizing Wet Bulb (1.0% annual + 5 °F): 75.0 °F + 5.0 °F = 80.0 °F.
  - Failure-Case Wet Bulb (0.4% annual + 5 °F): 76.0 °F + 5.0 °F = 81.0 °F.
  - 99.6% Annual Dry Bulb: 41.0 °F. Because 41.0 °F > 32.0 °F, basin heaters and heat-traced makeup are NOT required (`BASINHEATER = NO`).
  - Barometric Pressure: Mean station pressure over the period of record is 28.722 inHg (97,264 Pa).
- **Scenario Bins**: Observations grouped into 2 °F wet-bulb bins and 5 °F dry-bulb bins with bin mid-points, scaled to 8,760 hours/year (180 bins total).
- **Simulation Basis**: EnergyPlus variable-speed cooling tower model (YorkCalc correlation object) and Electric:EIR chiller model from `vendor_data/`.
  - Water flow rate ratio clamped to [0.75, 1.25].
  - Fan speed varies from free convection (AFR = 0.125), to minimum controllable speed (AFR = 0.300 with fan cycling), to modulating variable speed (0.300 to 1.000), drawing power proportional to AFR^3.
  - Condenser water pumps modeled per DC-02 paragraph 6.4 with dedicated constant-speed pumps per chiller.
- **Evaporation Formulation**: SATURATED-EXIT moist air method adopted consistently across water balance and life-cycle cost pricing.
- **Materials and Accessories**:
  - Casing & Basin: Type 304 Stainless Steel (SS-304), complying with GSA PBS-P100 paragraph 5.3.3.11 prohibition on galvanized steel in water contact surfaces. 25-year design service life eliminates mid-study replacements and salvage.
  - Drift Eliminator: Class DE-2 (certified drift rate 0.002% of design flow), complying with Project Specification Section 23 65 00 clause 2.3.
  - Fan Motors: Premium efficiency, continuous duty TEFC, NEMA Design B, complying with 10 CFR 431.25 Table 5.
  - Controls: Automatic conductivity controller with motorized blowdown valve, chemical feed, equalizing lines, and motorized isolation valves.

## 4. Plant Selection Summary and Performance
### CUP (Courthouse Central Utility Plant)
- **Equipment**: 4 cells of CTX-0600-S, total flow 1,800.0 gpm (450.0 gpm/cell, normal WFR = 0.750).
- **Setpoints**: CWSMIN = 75.0 °F, CWSOFFSET = 10.0 °F, Scheduled CWSDESIGN = 86.0 °F.
- **Water Chemistry**: Design CWR = 96.76 °F -> Max allowable COC = 4.14 (PSI = 5.60).
- **Performance**:
  - Achieved Design Point: CWS = 85.36 °F, Approach = 5.36 °F, Range = 11.40 °F, Heat Rejection = 10.26 MBTUH.
  - Redundancy (3 cells at 81.0 °F WB): CWS = 88.87 °F, Available Chiller Capacity = 905.2 tons (> 820.0 tons required), Redundant WFR = 1.000 (<= 1.25).
  - Peak Coincident Demand: 509.91 kW (<= 528.0 kW MCC-R1 limit).
  - Annual Water Makeup: 8,586.2 kgal (<= 10,300 kgal allocation).
  - Life-Cycle Cost: $5,611,202.31 vs Basic Design $5,776,778.67 -> **Net Savings: $165,576.36**.
- **Governing Constraint**: `structural capacity` (relative margin 0.0250), binding against allowable superimposed load of 120 psf in framing zone CUP-S2 (operating weight is 117.0 psf).

### ANNEX (Data Annex Condenser Water Plant)
- **Equipment**: 4 cells of CTX-0600-S, total flow 1,800.0 gpm (450.0 gpm/cell, normal WFR = 0.750).
- **Setpoints**: CWSMIN = 77.0 °F, CWSOFFSET = 11.0 °F, Scheduled CWSDESIGN = 86.5 °F.
- **Water Chemistry**: Design CWR = 97.98 °F -> Max allowable COC = 4.00 (PSI = 5.60).
- **Performance**:
  - Achieved Design Point: CWS = 85.69 °F, Approach = 5.69 °F, Range = 12.28 °F, Heat Rejection = 11.06 MBTUH.
  - Redundancy (3 cells at 81.0 °F WB): CWS = 89.35 °F, Available Chiller Capacity = 932.9 tons (> 880.0 tons required), Redundant WFR = 1.000 (<= 1.25).
  - Peak Coincident Demand: 569.06 kW (<= 590.0 kW MCC-R2 limit).
  - Annual Water Makeup: 11,690.5 kgal (<= 12,600 kgal amended allocation per PW-LTR-019).
  - Life-Cycle Cost: $7,521,498.97 vs Basic Design $7,748,722.15 -> **Net Savings: $227,223.17**.
- **Governing Constraint**: `electrical capacity` (relative margin 0.0355), with peak coincident demand of 569.06 kW against MCC-R2 spare capacity of 590.0 kW.

### LAB (Laboratory Wing Condenser Water Plant)
- **Equipment**: 3 cells of CTX-0900-H, total flow 2,025.0 gpm (675.0 gpm/cell, normal WFR = 0.750).
- **Setpoints**: CWSMIN = 61.0 °F, CWSOFFSET = 9.0 °F, Scheduled CWSDESIGN = 87.0 °F.
- **Water Chemistry**: Design CWR = 99.07 °F -> Max allowable COC = 3.87 (PSI = 5.60).
- **Performance**:
  - Achieved Design Point: CWS = 85.99 °F, Approach = 5.99 °F, Range = 13.08 °F, Heat Rejection = 13.24 MBTUH.
  - Redundancy (2 cells at 81.0 °F WB): CWS = 91.26 °F, Available Chiller Capacity = 1,205.7 tons (> 1,070.0 tons required), Redundant WFR = 1.125 (<= 1.25).
  - Peak Coincident Demand: 635.17 kW (<= 641.14 kW net MCC-R3 limit after RFI-034 deduction of 18.86 kW for continuous exhaust fans EF-L7/L8/L9).
  - Annual Water Makeup: 16,202.0 kgal (<= 17,400 kgal allocation).
  - Life-Cycle Cost: $7,742,277.58 vs Basic Design $7,935,639.70 -> **Net Savings: $193,362.13**.
- **Governing Constraint**: `electrical capacity` (relative margin 0.0093), with peak coincident demand of 635.17 kW against net MCC-R3 spare capacity of 641.14 kW.
