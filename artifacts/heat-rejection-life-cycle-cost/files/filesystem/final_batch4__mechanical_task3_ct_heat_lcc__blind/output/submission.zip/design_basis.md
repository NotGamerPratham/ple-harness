# Design Basis — Condenser Water Heat Rejection Replacement

Papago Federal Center, Phoenix, Arizona. Sandoval Klee Mechanical Engineers, PC. 95% construction documents.

## Governing documents
DC-02 Rev 3 (mechanical design criteria), EC-01 Rev 0 (life-cycle cost criteria), 10 CFR Part 436 Subpart A, the 2025 Annual Supplement to NIST Handbook 135 (NIST IR 85-3273-40), the EnergyPlus reference implementation and performance data sets, UFM 3-230-13 (2026 industrial water treatment), GSA PBS-P100 (2024), UFC 3-410-01 (2025 Change 1), 10 CFR Part 431 Subpart B, VD-01 through VD-05, M-601/M-603, E-601, M-401 Rev C, S-401 Rev C, E-501 Rev C, PW-LTR-014 and PW-LTR-019, UT-01, WT-01, and RFI-031/RFI-034. UFC 3-230-13 (2023), NIST IR 85-3273-39 (2024), and M-401 Rev B are superseded and are cited here only as set aside (see conflicts).

## Method
- Design outdoor wet bulb = 1.0% annual WB from the Phoenix Airport LCD POR (2022-2024, FM-15/FM-16 only) + 5 deg F (UFC 3-410-01 2-4.2.4). Computed 1.0% WB = 75.0 deg F, design WB = 80.0 deg F (lands on the YorkCalc inlet-WB maximum 26.6667 deg C). Redundancy WB = 0.4% evaporation WB (PBS-P100 5.1.3) + 5 deg F = 81.0 deg F. 99.6% DB = 41.0 deg F > 32 deg F, so no basin heater.
- Scenario bins: 2 deg F WB x 5 deg F DB from the POR, scaled to 8760 h/yr; block load from M-603 at the bin DB.
- Tower: EnergyPlus CoolingTower:VariableSpeed YorkCalc model (counterflow, CTX Series C). Approach from the YorkCalc correlation; inlet WB clamped to [-34.4, 26.6667] deg C; WFRR, range and approach limits enforced at every scenario. Fan power = (air flow ratio)^3 x design fan bhp / motor eff / VFD eff; free-convection and minimum-speed cycling per the reference routine.
- Chiller: EnergyPlus Chiller:Electric:EIR with the named performance data sets (CH-A York YT 1758kW/6.28COP/Vanes, CH-B Trane CVHE 1758kW/5.96COP/Vanes, CH-C York YT 1495kW/7.51COP/VSD). Capacity and power per CAPFT, EIRFT, EIRFPLR with curve input clamping; staging per DC-02 6.5; pump power per DC-02 6.4.
- Water balance declared in the LOSS-FACTOR formulation (water-treatment manual rule of thumb, evap = CWFlow x range / 1000). The life-cycle cost prices the SATURATED-EXIT formulation per EC-01 6, computed with the reference psychrometrics at the mean POR station pressure. Both are used consistently in their places.
- Cycles of concentration limited by the Practical (Puckorius) Scaling Index >= 5.60 (WT-01) at the design CWR, and by silica (150 ppm). Analysis of record WQP 2022-07-26 (Ca 109, alk 195, TDS 1720 ROE, SO4 205, SiO2 16 mg/L).
- Life-cycle cost: constant base-date dollars, real DOE discount rate 3.0%, study period 26 yr (1 construction + 25 service, SS-304 life), UPV* factors from the 2025 supplement (Mountain commercial electricity); water UPV* from the Authority 3.5%/yr forecast restated with 1.5% inflation; non-fuel OM UPV with no real escalation. Investment at base date; energy/water/OM accrue at beneficial occupancy (UPV*(26)-UPV*(1)). SS-304 25-yr life equals the service period, so no replacement or salvage.

## Selected designs
- CUP: CTX-0600-S, 4 cells, 1800 gpm, reset floor 75 deg F / offset 10 deg F, COC 3.94, DE-2 eliminator, SS-304, premium-efficiency fan motor. Net savings $209,932 against the basic design (LCC $5,669,121 vs basic $5,879,053).
- ANNEX: CTX-0600-S, 4 cells, 1800 gpm, reset floor 75 deg F / offset 11 deg F, COC 3.8, DE-2 eliminator, SS-304, premium-efficiency fan motor. Net savings $253,272 against the basic design (LCC $7,629,788 vs basic $7,883,060).
- LAB: CTX-0900-H, 3 cells, 2025 gpm, reset floor 60 deg F / offset 9 deg F, COC 3.71, DE-2 eliminator, SS-304, premium-efficiency fan motor. Net savings $258,861 against the basic design (LCC $7,785,369 vs basic $8,044,230).

## Governing constraint per plant
GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.0343)
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin -0.0703)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0094)

## Documented conflicts (DC-02 9.1)
CONFLICT 1: ADOPTED UFC 3-410-01 2-4.2.4 | SET ASIDE GSA PBS-P100 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 5-3.3 | SET ASIDE UFC 3-230-13 5-3.3
CONFLICT 3: ADOPTED M-401 Revision C | SET ASIDE M-401 Revision B

## Judgement calls
- Evaporation formulation: LOSS-FACTOR declared for the water balance and the PW-LTR-014 allocation/discharge checks; SATURATED-EXIT used for the LCC water pricing per EC-01 6. This is consistent: the workbook water balance reports loss-factor throughout, and the LCC prices the adopted simulation basis.
- Material SS-304 selected for every plant (25-yr service life = study service period, lowest routine maintenance, no replacement or salvage); G-235 and FRP-PV were rejected by the life-cycle cost.
- Drift eliminator DE-2 (0.002%) selected: the lowest-cost eliminator that meets the 23 65 00 2.3 limit of 0.002%.
- Premium-efficiency fan motors selected throughout: the economy offerings fall below the 10 CFR 431 Subpart B minimum full-load efficiency for these nameplate horsepowers and pole counts.
- Basin clearance scheduled at 4 ft (PBS-P100 5.3.2.3 minimum).
- ANNEX note: the amended annual allocation (PW-LTR-019, 12,600 kgal/yr) is very tight relative to the 880-ton load; the selected ANNEX design operates at the maximum COC the PSI allows and minimises condenser-water flow, and is reported in the loss-factor formulation. The peak-day and blowdown limits are met with margin.