# Pacific Crest Space Force Annex — 13.8 kV Site Distribution Conveyance Study

**Solicitation FA4610-26-R-0031 — Project PCSFA 24-0117 — Study date 2026-09-15**

Prepared by the design-build contractor (electrical engineer and cost estimator). Bottom-up estimate per RFP Section 01 11 00 (Amd 0002) Part 3 estimating basis; PCSFA-IEDS Rev 3 governs design; UFC/UFGS, 29 CFR 1926 Subpart P and EP 1110-1-8 applied.

## 1. Basis of estimate

- **Wage determination:** CA20260022 Mod 2 (Attachment J-3), per RFP 2.1. Line-construction, laborer, operator and inside-electrician classifications per the labor classification plan; loaded rate = base ×(1+burden)+fringe, burden = FICA 7.65%+FUTA 0.6%+CA SUI 3.4%+workers' comp class code.

- **Equipment:** EP 1110-1-8 Vol 7 (Region VII) total hourly rates adjusted for fuel and FOG per paras 3.9/3.10 using jobsite fuel prices (gasoline $5.12/gal, off-road diesel $4.38/gal, invoice FSI-0826-2207); rental equipment at RQ-26-0419.

- **Materials:** Supplier quote Q-2608-114 unit prices ×(1+waste)×PPI adjustment (WPU102603 Aug 2026=494.096 / base Jul 2026=482.612) for indexed (I) items ×(1+9.5% sales tax).

- **Markups:** JOOH 9.5% of direct; HOOH 4.5% of (direct+JOOH); profit 7.949% (weighted guidelines, UFC 3-740-05 11-2.2: risk×0.08, difficulty×0.09, size×0.0614 ($4.2M), period×0.0848 (15 mo), investment×0.06, assistance×0.07, subcontracting×0.0862 (30%)); bond Class B graduated +3% (15-mo period) → effective 1.225% applied to all alternatives; escalation factor 1.01939 (UFS Table 4-2 midpoint/study, daily interpolation); design contingency 5.0%; SIOH 5.7% of (contract+contingency).

- **Area cost factor:** 1.0 (PCSFA is not a site in UFS 3-701-01 Table 4-1; RFP 3.1 limits location factors to UFS-permitted values — see Finding F01).

- **Cable:** TD-15AL-133 (15 kV 133% XLPE Al, copper tape shield, PVC jacket); ampacity tables with selection rules (next higher rho/depth/circuits/ambient, no interpolation); earth ambient 25 °C; ACSR/building at 40 °C; design current = protective-device phase pickup (PDS Rev D); short-circuit each set ≥ source-bus fault for 0.5 s backup clearing; load factor F1/F2 = 100%, others 75%.


## 2. Recommendations

| Item | Circuit | Recommended | Cable (sets) | OH cond. | Design I (A) | Amp/set (A) | Route (ft) | Total cost ($) | $/lf |
|---|---|---|---|---|---|---|---|---|---|
| C01 | SS-1 F1→MB-1 MSG-A | **CEDB** | 250 (3) | — | 640 | 233 | 950 | 437,477 | 460.5 |
| C02 | SS-1 F2→MB-1 MSG-B | **CEDB** | 350 (2) | — | 560 | 285 | 1205 | 422,333 | 350.5 |
| C03 | SS-1 F3→CUP-1 SWG-C1 | **CEDB** | 350 (1) | — | 400 | 410 | 520 | 138,574 | 266.5 |
| C04 | CUP-1 CF-2→LS-2 TX-LS2 | **CEDB** | 250 (1) | — | 60 | 330 | 1332 | 337,548 | 253.4 |
| C05 | MB-1 MSG-A→USS-A1 | **RMC** | 250 (2) | — | 200 | 160 | 324 | 175,162 | 540.6 |
| C06 | SS-1 F4→GH-1 TX-GH1 | **OH** | 250 (1) | 1/0 | 40 | 196 | 1898 | 124,334 | 65.5 |
| C07 | CUP-1 CF-1→W-3 TX-W3 | **CEDB** | 250 (1) | — | 120 | 345 | 672 | 177,417 | 264.0 |

- **C01–C04, C07:** the installation standard (IEDS 4.2) requires concrete-encased ductbanks for primary distribution and prohibits direct-buried cable and unencased conduit; directional bores are only for crossings (IEDS 4.3) and overhead is not permitted inside the congested industrial area / W-3 crane area (IEDS 4.1) on these routes — so **CEDB** is the only permitted type and is recommended.
- **C05 (inside MB-1):** MV cable inside buildings must be in raceway or fully-enclosed tray (UFC 3-520-01 Table 3-1); the corridor route is blocked for tray by the 14-in/16-in ceiling spaces at the supply-air main (COR-1D) and the SCIF keep-out, so **RMC** (rigid metal conduit) is recommended over EMT and the inadmissible tray types.
- **C06 (SS-1 to gate house):** both terminals border the non-congested south strip; an overhead pole line along y≈290 (outside the congested area, 50-ft poles across Mission Drive, span over channel DC-1, underground risers at both ends) is permitted and is far cheaper than a ~2,000-ft concrete ductbank for this small (40 A, 150 kVA) load — **OH** is recommended.


## C01 — SS-1 F1→MB-1 MSG-A  (recommended: CEDB)

Route 950 ft; cable 250 kcmil, 3 set(s); ampacity 233 A/set at the governing condition ≥ design current 640 A; short-circuit 16.6 kA @0.5 s ≥ 16.5 kA source-bus fault.

| Type | Adm. | Governing clause | Length (ft) | Labor mh | Labor $ | Equip $ | Material $ | Sub $ | Direct $ | Total $ | $/lf |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB **(rec)** | Y | IEDS 4.2; UFC 3-550-01 3-11.2.1 | 950 | 1051 | 90,040 | 18,286 | 178,885 | 22,040 | 309,252 | 437,477 | 460.5 |
| UEDB | N | IEDS 4.2 (conduit without encasement not permitted for primary distribution) | 950 | 972 | 83,562 | 18,697 | 186,191 | 22,040 | 310,491 | 439,230 | 462.3 |
| DBC | N | IEDS 4.2 (direct-buried cable not permitted for primary distribution) | 950 | 577 | 49,856 | 11,311 | 137,146 | 0 | 198,312 | 280,539 | 295.3 |
| HDD | N | IEDS 4.3 (directional bores only for crossings, not entire run) | 950 | 691 | 59,757 | 16,300 | 68,753 | 161,440 | 306,250 | 433,231 | 456.0 |
| OH | N | IEDS 4.1 (overhead not permitted inside the congested industrial area / W-3 crane area) | 950 | 1051 | 90,040 | 18,286 | 178,885 | 22,040 | 309,252 | 437,477 | 460.5 |

**Labor rates used** (loaded $/hr, crew-average): CR-EX 83.8, CR-TM 82.6, CR-BF 83.9, CR-DU 83.6, CR-CO 81.3, CR-CP 86.2, CR-SP 90.0, CR-MH 84.9, CR-DW 108.6, CR-OH/2 90.0, CR-OH3 96.4, CR-STR 86.2, CR-IN 112.8, CR-IS 114.8. See LaborRates sheet for the per-class base/fringe/burden/loaded-rate formula.


## C02 — SS-1 F2→MB-1 MSG-B  (recommended: CEDB)

Route 1205 ft; cable 350 kcmil, 2 set(s); ampacity 285 A/set at the governing condition ≥ design current 560 A; short-circuit 23.3 kA @0.5 s ≥ 16.5 kA source-bus fault.

| Type | Adm. | Governing clause | Length (ft) | Labor mh | Labor $ | Equip $ | Material $ | Sub $ | Direct $ | Total $ | $/lf |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB **(rec)** | Y | IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1205 | 914 | 78,242 | 16,052 | 190,252 | 14,000 | 298,547 | 422,333 | 350.5 |
| UEDB | N | IEDS 4.2 (conduit without encasement not permitted for primary distribution) | 1205 | 853 | 73,253 | 16,414 | 195,982 | 14,000 | 299,649 | 423,892 | 351.8 |
| DBC | N | IEDS 4.2 (direct-buried cable not permitted for primary distribution) | 1205 | 528 | 45,510 | 10,194 | 157,244 | 0 | 212,948 | 301,243 | 250.0 |
| HDD | N | IEDS 4.3 (directional bores only for crossings, not entire run) | 1205 | 570 | 49,248 | 13,677 | 67,537 | 198,996 | 329,459 | 466,062 | 386.8 |
| OH | N | IEDS 4.1 (overhead not permitted inside the congested industrial area / W-3 crane area) | 1205 | 914 | 78,242 | 16,052 | 190,252 | 14,000 | 298,547 | 422,333 | 350.5 |

**Labor rates used** (loaded $/hr, crew-average): CR-EX 83.8, CR-TM 82.6, CR-BF 83.9, CR-DU 83.6, CR-CO 81.3, CR-CP 86.2, CR-SP 90.0, CR-MH 84.9, CR-DW 108.6, CR-OH/2 90.0, CR-OH3 96.4, CR-STR 86.2, CR-IN 112.8, CR-IS 114.8. See LaborRates sheet for the per-class base/fringe/burden/loaded-rate formula.


## C03 — SS-1 F3→CUP-1 SWG-C1  (recommended: CEDB)

Route 520 ft; cable 350 kcmil, 1 set(s); ampacity 410 A/set at the governing condition ≥ design current 400 A; short-circuit 23.3 kA @0.5 s ≥ 16.5 kA source-bus fault.

| Type | Adm. | Governing clause | Length (ft) | Labor mh | Labor $ | Equip $ | Material $ | Sub $ | Direct $ | Total $ | $/lf |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB **(rec)** | Y | IEDS 4.2; UFC 3-550-01 3-11.2.1 | 520 | 270 | 23,080 | 4,118 | 70,760 | 0 | 97,958 | 138,574 | 266.5 |
| UEDB | N | IEDS 4.2 (conduit without encasement not permitted for primary distribution) | 520 | 251 | 21,520 | 4,252 | 72,600 | 0 | 98,372 | 139,160 | 267.6 |
| DBC | N | IEDS 4.2 (direct-buried cable not permitted for primary distribution) | 520 | 167 | 14,352 | 2,792 | 59,482 | 0 | 76,626 | 108,397 | 208.5 |
| HDD | N | IEDS 4.3 (directional bores only for crossings, not entire run) | 520 | 138 | 11,986 | 3,064 | 16,090 | 43,672 | 74,812 | 105,831 | 203.5 |
| OH | N | IEDS 4.1 (overhead not permitted inside the congested industrial area / W-3 crane area) | 520 | 270 | 23,080 | 4,118 | 70,760 | 0 | 97,958 | 138,574 | 266.5 |

**Labor rates used** (loaded $/hr, crew-average): CR-EX 83.8, CR-TM 82.6, CR-BF 83.9, CR-DU 83.6, CR-CO 81.3, CR-CP 86.2, CR-SP 90.0, CR-MH 84.9, CR-DW 108.6, CR-OH/2 90.0, CR-OH3 96.4, CR-STR 86.2, CR-IN 112.8, CR-IS 114.8. See LaborRates sheet for the per-class base/fringe/burden/loaded-rate formula.


## C04 — CUP-1 CF-2→LS-2 TX-LS2  (recommended: CEDB)

Route 1332 ft; cable 250 kcmil, 1 set(s); ampacity 330 A/set at the governing condition ≥ design current 60 A; short-circuit 16.6 kA @0.5 s ≥ 14.2 kA source-bus fault.

| Type | Adm. | Governing clause | Length (ft) | Labor mh | Labor $ | Equip $ | Material $ | Sub $ | Direct $ | Total $ | $/lf |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB **(rec)** | Y | IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1332 | 636 | 54,140 | 10,087 | 148,378 | 26,008 | 238,612 | 337,548 | 253.4 |
| UEDB | N | IEDS 4.2 (conduit without encasement not permitted for primary distribution) | 1332 | 553 | 47,311 | 10,005 | 149,478 | 26,008 | 232,802 | 329,329 | 247.2 |
| DBC | N | IEDS 4.2 (direct-buried cable not permitted for primary distribution) | 1332 | 356 | 30,569 | 6,485 | 120,843 | 0 | 157,898 | 223,367 | 167.7 |
| HDD | N | IEDS 4.3 (directional bores only for crossings, not entire run) | 1332 | 312 | 26,967 | 7,538 | 31,122 | 129,939 | 195,566 | 276,654 | 207.7 |
| OH | N | IEDS 4.1 (overhead not permitted inside the congested industrial area / W-3 crane area) | 1332 | 636 | 54,140 | 10,087 | 148,378 | 26,008 | 238,612 | 337,548 | 253.4 |

**Labor rates used** (loaded $/hr, crew-average): CR-EX 83.8, CR-TM 82.6, CR-BF 83.9, CR-DU 83.6, CR-CO 81.3, CR-CP 86.2, CR-SP 90.0, CR-MH 84.9, CR-DW 108.6, CR-OH/2 90.0, CR-OH3 96.4, CR-STR 86.2, CR-IN 112.8, CR-IS 114.8. See LaborRates sheet for the per-class base/fringe/burden/loaded-rate formula.


## C05 — MB-1 MSG-A→USS-A1  (recommended: RMC)

Route 324 ft; cable 250 kcmil, 2 set(s); ampacity 160 A/set at the governing condition ≥ design current 200 A; short-circuit 16.6 kA @0.5 s ≥ 15.8 kA source-bus fault.

| Type | Adm. | Governing clause | Length (ft) | Labor mh | Labor $ | Equip $ | Material $ | Sub $ | Direct $ | Total $ | $/lf |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RMC **(rec)** | Y | IEDS 5.1; UFC 3-520-01 Table 3-1; UFGS 26 20 00 3.1.6 | 324 | 431 | 48,752 | 2,319 | 72,750 | 0 | 123,821 | 175,162 | 540.6 |
| EMT | N | UFC 3-520-01 Table 3-1 / TD-15AL-133 4.5: EMT-4 (4.334 in ID) gives jam ratio D/d 2.8-3.2 for 250/350 kcmil and >40% fill for 500 kcmil - no viable cable size, not permitted | 324 | 345 | 38,955 | 1,807 | 38,330 | 0 | 79,092 | 111,886 | 345.3 |
| TRAY-EN | N | IEDS 5.1 (no viable route: 14/16-in spaces block; SCIF keepout blocks detour) | 324 | 249 | 28,100 | 1,354 | 36,319 | 0 | 65,774 | 93,046 | 287.2 |
| TRAY-LD | N | IEDS 5.1 (no viable route: 14/16-in spaces block; SCIF keepout blocks detour) | 324 | 230 | 26,002 | 1,245 | 28,656 | 0 | 55,903 | 79,082 | 244.1 |

**Labor rates used** (loaded $/hr, crew-average): CR-EX 83.8, CR-TM 82.6, CR-BF 83.9, CR-DU 83.6, CR-CO 81.3, CR-CP 86.2, CR-SP 90.0, CR-MH 84.9, CR-DW 108.6, CR-OH/2 90.0, CR-OH3 96.4, CR-STR 86.2, CR-IN 112.8, CR-IS 114.8. See LaborRates sheet for the per-class base/fringe/burden/loaded-rate formula.


## C06 — SS-1 F4→GH-1 TX-GH1  (recommended: OH)

Route 1898 ft; cable 250 kcmil, 1 set(s); ampacity 196 A/set at the governing condition ≥ design current 40 A; short-circuit 16.6 kA @0.5 s ≥ 16.5 kA source-bus fault.

| Type | Adm. | Governing clause | Length (ft) | Labor mh | Labor $ | Equip $ | Material $ | Sub $ | Direct $ | Total $ | $/lf |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | IEDS 4.2; UFC 3-550-01 3-11.2.1 | 2002 | 894 | 76,165 | 14,500 | 219,407 | 22,040 | 332,112 | 469,816 | 234.7 |
| UEDB | N | IEDS 4.2 (conduit without encasement not permitted for primary distribution) | 2002 | 825 | 70,549 | 14,981 | 226,034 | 22,040 | 333,603 | 471,925 | 235.7 |
| DBC | N | IEDS 4.2 (direct-buried cable not permitted for primary distribution) | 2002 | 523 | 44,847 | 9,683 | 180,136 | 0 | 234,666 | 331,966 | 165.8 |
| HDD | N | IEDS 4.3 (directional bores only for crossings, not entire run) | 2002 | 455 | 39,328 | 11,230 | 45,512 | 173,115 | 269,185 | 380,797 | 190.2 |
| OH **(rec)** | Y | IEDS 4.1 (overhead permitted outside the congested industrial area and W-3 crane area, with underground risers) | 1898 | 349 | 30,477 | 7,617 | 49,798 | 0 | 87,892 | 124,334 | 65.5 |

**Labor rates used** (loaded $/hr, crew-average): CR-EX 83.8, CR-TM 82.6, CR-BF 83.9, CR-DU 83.6, CR-CO 81.3, CR-CP 86.2, CR-SP 90.0, CR-MH 84.9, CR-DW 108.6, CR-OH/2 90.0, CR-OH3 96.4, CR-STR 86.2, CR-IN 112.8, CR-IS 114.8. See LaborRates sheet for the per-class base/fringe/burden/loaded-rate formula.


## C07 — CUP-1 CF-1→W-3 TX-W3  (recommended: CEDB)

Route 672 ft; cable 250 kcmil, 1 set(s); ampacity 345 A/set at the governing condition ≥ design current 120 A; short-circuit 16.6 kA @0.5 s ≥ 14.2 kA source-bus fault.

| Type | Adm. | Governing clause | Length (ft) | Labor mh | Labor $ | Equip $ | Material $ | Sub $ | Direct $ | Total $ | $/lf |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB **(rec)** | Y | IEDS 4.2; UFC 3-550-01 3-11.2.1 | 672 | 306 | 26,135 | 4,963 | 72,277 | 22,040 | 125,416 | 177,417 | 264.0 |
| UEDB | N | IEDS 4.2 (conduit without encasement not permitted for primary distribution) | 672 | 286 | 24,509 | 5,103 | 74,196 | 22,040 | 125,848 | 178,028 | 264.9 |
| DBC | N | IEDS 4.2 (direct-buried cable not permitted for primary distribution) | 672 | 191 | 16,429 | 3,323 | 61,871 | 0 | 81,622 | 115,465 | 171.8 |
| HDD | N | IEDS 4.3 (directional bores only for crossings, not entire run) | 672 | 171 | 14,790 | 3,901 | 16,947 | 75,227 | 110,866 | 156,834 | 233.4 |
| OH | N | IEDS 4.1 (overhead not permitted inside the congested industrial area / W-3 crane area) | 672 | 306 | 26,135 | 4,963 | 72,277 | 22,040 | 125,416 | 177,417 | 264.0 |

**Labor rates used** (loaded $/hr, crew-average): CR-EX 83.8, CR-TM 82.6, CR-BF 83.9, CR-DU 83.6, CR-CO 81.3, CR-CP 86.2, CR-SP 90.0, CR-MH 84.9, CR-DW 108.6, CR-OH/2 90.0, CR-OH3 96.4, CR-STR 86.2, CR-IN 112.8, CR-IS 114.8. See LaborRates sheet for the per-class base/fringe/burden/loaded-rate formula.


## 3. Key findings in Government-furnished documents

- **F01** (Government Estimate Template PCSFA FY26, Summary line 2): Area Cost Factor 1.16 (Los Angeles AFB Site #1) applied, but PCSFA is not a site in UFS 3-701-01 Table 4-1; RFP 3.1 limits ACF to UFS-permitted factors. Correction used: Applied ACF=1.0 (no factor); per RFP 3.1

- **F02** (C-101 Site Utility Plan Rev 4, General Note 2 / UTIL-WATER): Record drawing shows EX 12in water W-12 top of pipe approx 72in; SUE-24-0117 QLB test holes measure 56in. Correction used: Used SUE depth 56in (SUE governs per IEDS 1.3(5))

- **F03** (Attachment J-3 Wage Determination CA20260022 Mod 2 vs cost folder Mod 5, ELEC0011-004): Mod 2 lists electrician inside $65.00 (CBA 01/27/2026); later Mod 5 (2026-08-06) lists $60.80 (CBA 06/30/2023) - regressive/older CBA date. Correction used: Used Attachment J-3 (Mod 2) per RFP 2.1; noted Mod 5 discrepancy

- **F04** (E-001 One-Line Diagram vs Protective Device Settings Rev D, Feeder F1 pickup): One-line may show older F1 rating; PDS Rev D increased F1 phase pickup to 640A for MB-1 Phase 2 load. Correction used: Used PDS Rev D 640A (PDS governs per IEDS 1.3(4))

- **F05** (TD-15AL-133 Cable Data Sheet / IEDS 2.1, Construction): IEDS 2.1 specifies Type MV-105 (105C); ampacity tables/submittal use 90C operating for ampacity. Correction used: Used 90C ampacity (submittal/manufacturer tables govern per IEDS 1.3(3)); 105C is max emergency


## 4. Pulling plan (recommended designs)

All pulls are within the approved submittal limits (max tension 0.006×2×cmil ≤ 10,000 lb; sidewall ≤ 600 lb/ft; conduit fill ≤ 40%; jam ratio avoided in 2.8–3.2). See Pulls sheet for each pull's length, tension, sidewall, jam ratio and fill.
