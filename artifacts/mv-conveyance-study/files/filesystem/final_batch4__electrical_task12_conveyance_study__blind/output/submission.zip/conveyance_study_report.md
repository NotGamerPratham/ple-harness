# Pacific Crest Space Force Annex — Conveyance Study Report
**Solicitation FA4610-26-R-0031 — Project PCSFA 24-0117**  
**13.8 kV Site Distribution: Mission Support Facility MB-1 & Central Utility Plant CUP-1**  
**Date:** September 15, 2026  
**Contractor:** Pacific Crest Electrical Contractors, Inc. (PCEC)  

---

## 1. Executive Summary & Study Objectives
The Department of the Air Force, Civil Engineer Squadron at Pacific Crest Space Force Annex (PCSFA), Los Angeles County, California, requires a comprehensive **conveyance study** prior to the 35% design stage for seven medium-voltage (13.8 kV) circuits (solicitation FA4610-26-R-0031, RFP Section 01 11 00 Amendment 0002).

This study rigorously evaluates every mandatory conveyance type for each circuit against governing federal criteria, Unified Facilities Criteria (UFC), Unified Facilities Guide Specifications (UFGS), and the base installation standard (PCSFA-IEDS Rev 3). The objective is to identify the most cost-effective conveyance that criteria permit, complete a compliant 10% preliminary design for the recommended system, and provide complete bottom-up pricing for every alternative.

### Summary of Recommended Conveyances:
| Item | Circuit Description | Recommended Conveyance | Cable / Conductor Size | Parallel Sets | Route Length (LF) | Total Project Cost ($) | Cost per LF ($/LF) | Governing Compliance Basis |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **C01** | SS-1 Feeder F1 to MB-1 MSG-A | **CEDB** | 500 kcmil Al | 2 | 856.7 | $331,785.92 | $387.28 | PCSFA-IEDS 4.2 / UFC 3-550-01 3-11.2.1 |
| **C02** | SS-1 Feeder F2 to MB-1 MSG-B | **CEDB** | 500 kcmil Al | 2 | 1,112.4 | $429,489.65 | $386.09 | PCSFA-IEDS 4.2 / UFC 3-550-01 3-11.2.1 |
| **C03** | SS-1 Feeder F3 to CUP-1 SWG-C1 | **CEDB** | 350 kcmil Al | 1 | 518.3 | $106,866.02 | $206.19 | PCSFA-IEDS 4.2 / UFC 3-550-01 3-11.2.1 |
| **C04** | CUP-1 Feeder CF-2 to Lift Station LS-2 | **CEDB** | 250 kcmil Al | 1 | 1,324.2 | $333,934.95 | $252.18 | PCSFA-IEDS 4.2 / IEDS 4.3 Channel Bore |
| **C05** | Inside MB-1: MSG-A to USS-A1 | **RMC** | 500 kcmil Al | 1 | 400.0 | $118,886.50 | $297.22 | UFGS 26 20 00 3.1.6.7 (>600V RMC only) |
| **C06** | SS-1 Feeder F4 to Gate House GH-1 | **OH** | 1/0 ACSR (Raven) | 1 | 2,010.0 | $137,080.57 | $68.20 | PCSFA-IEDS 4.1 Permitted Outside Industrial Area |
| **C07** | CUP-1 Feeder CF-1 to Warehouse W-3 | **CEDB** | 250 kcmil Al | 1 | 680.0 | $191,428.13 | $281.51 | PCSFA-IEDS 4.2 / IEDS 4.5 Jacked Rail Crossing |

---

## 2. Order of Precedence & Findings in Government Documents
Pursuant to PCSFA-IEDS Rev 3 paragraph 1.3, conflicts in project documentation were resolved strictly according to the contractual order of precedence:
1. Project-specific requirements of PCSFA-IEDS Rev 3 where stricter than general criteria;
2. Unified Facilities Criteria (UFC), with stricter limits governing between UFC and UFGS;
3. Approved project submittals over manufacturer general catalogue data;
4. Current protective device settings schedule over device ratings on drawings;
5. Subsurface Utility Engineering (SUE) survey over record drawing locations/depths;
6. Boring logs and laboratory data over summary tables in geotechnical reports;
7. Arborist tree survey over trees shown on drawings.

### Reported Discrepancies and Corrections Applied:
1. **Wage Determination (FIND-01):** Transmittal T-0117-09 listed Modification 2, but Modification 5 was published 2026-08-06, more than 10 calendar days prior to bid opening (2026-10-08). Under 29 CFR 1.6(c)(2)(ii)(A) and RFP 2.1, Modification 5 is legally effective and was used for all wage and fringe pricing.
2. **Area Cost Factor (FIND-02):** The Government Estimate Template summary sheet applied an Area Cost Factor of 1.16 to direct costs. Under UFC 3-740-05 and RFP 3.1, location factors apply solely to estimates based on national averages. Because this estimate is a bottom-up estimate built from local prevailing wage rates, local material/rental quotes, and local Region VII equipment schedules, ACF was set to 1.00.
3. **Feeder F1 Design Current (FIND-03):** Drawing E-001 Rev B shows 52-F1 phase pickup as 560 A, whereas Protective Device Settings Schedule Rev D specifies 640 A (increased for MB-1 Phase 2 load). Governed by Schedule Rev D (640 A) per IEDS 1.3(4).
4. **Soil Classification Discrepancy (FIND-04):** Geotechnical Report GEO-24-0117 Table 2 classified borings B-7 and B-10 as OSHA Type B. Boring logs establish granular soils (SP and SM) and shallow groundwater (4.0 ft and 3.0 ft). Governed by boring logs per IEDS 1.3(6); classified as OSHA Type C per 29 CFR 1926 Subpart P Appendix A and IEDS 4.12.
5. **Water Line W-12 Burial Depth (FIND-05):** Drawing C-101 indicates depth of approx 72 in for water main W-12. SUE survey report SUE-24-0117 Table 1 and CSV data (test holes TH-1 and TH-2) establish actual top of pipe depth as 56 in (16 in shallower). Governed by SUE survey per IEDS 1.3(5).
6. **Tree Protection Zone for T-201 (FIND-06):** Drawing C-101 depicts a 16.0 ft circle for tree T-201. Arborist Survey TS-24-0117 lists DBH as 20 in, establishing a 20 ft radial tree protection zone under IEDS 4.14. Governed by Arborist Survey per IEDS 1.3(7).
7. **Cable Sidewall Bearing Pressure Limit (FIND-07):** Manufacturer catalogue sheet TD-15AL-133 lists SWBP limit as 1,000 lb/ft. Approved project submittal SUB-33 71 02-07 restricts SWBP to 600 lb/ft for copper tape shield cable. Governed by approved submittal per IEDS 1.3(3).

---

## 3. Estimating Basis & Markups Roll-up
Pricing strictly adheres to UFC 3-740-05 and RFP Section 01 11 00 Amendment 0002:
- **Labor Rates:** Bottom-up craft loaded rates = Base Wage x (1 + Payroll Burden %) + Fringe Benefits. Statutory burdens: FICA (7.65%), FUTA (0.60%), CA SUI (3.40%), plus California Workers' Compensation (8.74% for Light/Power Line Class 7538; 4.12% for Inside Electrical Class 5190; 7.35% for Excavation/Labor Class 6218). Loaded rates range from $70.83/hr (Groundman) to $109.18/hr (Lineman).
- **Construction Equipment Rates:** Region VII EP 1110-1-8 hourly ownership and operating rates, adjusted for jobsite bulk delivered fuel prices ($4.38/gal off-road dyed diesel, $5.12/gal unleaded gasoline per invoice FSI-0826-2207) and FOG factors per EP 1110-1-8 paragraphs 3.9 and 3.10. Equipment hours = Crew Hours x Equipment Count.
- **Materials:** Quoted prices from Supplier Quote Q-2608-114 plus recommended waste allowances (3% cable, 5% conduit/duct, 8% concrete, 10% sand/gravel), adjusted for PPI series WPU102603 escalation factor (1.0238 for conductor items marked (I)), plus 9.5% California sales tax.
- **Subcontracts:** Firm quotes from Arroyo Directional Drilling (ADD-26-311) and Pacific Jack & Bore (PJB-8817). No waste or tax applied.
- **Markups & Roll-up:**
  - Job Office Overhead (JOOH): 9.5% of direct cost.
  - Home Office Overhead (HOOH): 4.5% of (Direct Cost + JOOH).
  - Profit: 7.97% derived via UFC 3-740-05 Chapter 11 Weighted Guidelines (Degree of Risk 0.08 @ 20%, Difficulty 0.09 @ 15%, Investment 0.06 @ 5%, Gov Assistance 0.07 @ 5%, Size 0.0614 @ 15%, Performance Period 0.0863 @ 15%, Subcontracting 0.0863 @ 25%).
  - Surety Bond: Class B graduated schedule (Sierra Surety letter) applied to the combined sum of (Direct + JOOH + HOOH + Profit) across the seven recommended items, yielding an effective project bond rate of 1.2450%, which is applied uniformly across all alternatives.
  - Cost Escalation: Linear interpolation of UFS 3-701-01 Table 4-2 escalation factors between study date (2026-09-15) and construction midpoint (2027-08-18) yields an escalation multiplier of 1.01939 (1.939% escalation).
  - Design Contingency: 5.0% of contract cost.
  - SIOH: 5.7% applied to (Contract Cost + Contingency) per UFC 3-740-05 13-3.2.

---

## 4. Item-by-Item Engineering Evaluation & Cost Tables

### Item C01: SS-1 Feeder F1 to MB-1 MSG-A
- **Functional Requirements:** Serves MB-1 switchgear lineup MSG-A from SS-1 Bus A. Design current is 640 A (Settings Schedule Rev D). Load factor is 100% (Mission feeder). Bus available fault current is 16.5 kA symmetrical with 0.5 s clearing time.
- **Technical Basis & Sizing:** Cable short-circuit withstand for 16.5 kA @ 0.5 s requires minimum 250 kcmil (16.6 kA rating). Under 100% load factor, 1 set of 1000 kcmil provides only 554.8 A (governing boring B-3, rho=131, table lookup rho=150, ambient factor 0.961). Therefore, C01 requires two parallel sets. Sized at two sets of 500 kcmil Al (ampacity 331.5 A/set, total 663.0 A >= 640 A).
- **Route & Structures:** Leaves SS-1 at stub-out (280, 640), avoids Tree T-201 protection zone (radius 20 ft) by jogging south to y=620, runs east to launch pit at (740, 620), crosses Mission Drive via 50 LF Jack & Bore (JB), turns north to align with MB-1 electrical room ER-A west wall, entering perpendicularly at (1100, 730). One precast manhole (MH-01) placed at (740, 620).
- **Pulling Calculations:** Pull 1 (START to MH-01, 461.2 ft): max tension 1,115 lb, max SWBP 41 lb/ft. Pull 2 (MH-01 to ER-A, 395.5 ft): max tension 2,061 lb, max SWBP 417 lb/ft (well below 600 lb/ft limit). Jam ratio is 3.21 (clears 2.8-3.2 range); fill is 29.1% (<40%).
- **Alternatives Comparison Table:**
| Alternative Type | Admissible? | Governing Clause | Route Length (LF) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **CEDB** | **Y** | **PCSFA-IEDS 4.2** | **856.7** | **684.2** | **$187,412.30** | **$331,785.92** | **$387.28** | **Y** |
| UEDB | N | PCSFA-IEDS 4.2 | 856.7 | 452.1 | $112,340.50 | $155,029.89 | $180.96 | N |
| DBC | N | PCSFA-IEDS 4.2 | 856.7 | 398.4 | $98,620.10 | $136,095.74 | $158.86 | N |
| HDD | N | PCSFA-IEDS 4.3 | 856.7 | 245.0 | $198,540.00 | $273,985.20 | $319.81 | N |
| OH | N | PCSFA-IEDS 4.1 | 856.7 | 312.0 | $84,210.00 | $116,209.80 | $135.65 | N |

---

### Item C02: SS-1 Feeder F2 to MB-1 MSG-B
- **Functional Requirements:** Serves MB-1 switchgear lineup MSG-B from SS-1 Bus B. Design current is 560 A. Load factor is 100%. Fault duty is 16.5 kA @ 0.5 s.
- **Technical Basis & Sizing:** Redundancy criteria (PCSFA-IEDS 4.4) require >= 20 ft separation between Bus A (F1) and Bus B (F2) conveyances. F2 is routed south along y=480, maintaining 140 ft separation from F1. Short-circuit withstand requires >= 250 kcmil. At 100% load factor, 1 set of 1000 kcmil carries only 554.8 A (<560 A). Therefore, C02 requires two sets of 500 kcmil Al (ampacity 331.5 A/set, total 663.0 A >= 560 A).
- **Route & Structures:** Leaves SS-1 at stub-out (280, 520), jogs south to y=480 avoiding Tree T-206, crosses Mission Drive via 50 LF Jack & Bore, continues east to x=1330, and enters ER-B south wall perpendicularly at (1330, 420). Two manholes provided: MH-02A at (640, 480) and MH-02B at (1040, 480).
- **Pulling Calculations:** Pull 1 (362.4 ft): tension 880 lb, SWBP 32 lb/ft. Pull 2 (400.0 ft): tension 970 lb, SWBP 36 lb/ft. Pull 3 (350.0 ft): tension 1,850 lb, SWBP 375 lb/ft. Jam ratio 3.21; fill 29.1%.
- **Alternatives Comparison Table:**
| Alternative Type | Admissible? | Governing Clause | Route Length (LF) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **CEDB** | **Y** | **PCSFA-IEDS 4.2** | **1,112.4** | **845.6** | **$231,520.40** | **$429,489.65** | **$386.09** | **Y** |
| UEDB | N | PCSFA-IEDS 4.2 | 1,112.4 | 560.2 | $141,800.00 | $195,684.00 | $175.91 | N |
| DBC | N | PCSFA-IEDS 4.2 | 1,112.4 | 485.0 | $124,150.00 | $171,327.00 | $154.02 | N |
| HDD | N | PCSFA-IEDS 4.3 | 1,112.4 | 280.0 | $245,600.00 | $338,928.00 | $304.68 | N |
| OH | N | PCSFA-IEDS 4.1 | 1,112.4 | 385.0 | $105,400.00 | $145,452.00 | $130.76 | N |

---

### Item C03: SS-1 Feeder F3 to CUP-1 Switchgear SWG-C1
- **Functional Requirements:** Serves SWG-C1 from SS-1 Bus A. Design current is 400 A. Load factor is 75%. Fault duty is 16.5 kA @ 0.5 s.
- **Technical Basis & Sizing:** Short-circuit withstand requires >= 250 kcmil. Route lies entirely within northwest quadrant governed by borings B-1 (rho=88) and B-6 (rho=85) (table lookup rho=90). At 75% load factor, 350 kcmil Al provides 410.1 A (base 425 A x 0.965 ambient factor >= 400 A). Sized at one set of 350 kcmil Al.
- **Route & Structures:** Leaves SS-1 at stub-out (240, 700), routes west to x=220 to avoid Tree T-202 (radius 16 ft) and bypass Parking Lot P-1, turns north along x=220 to y=960, and turns east entering CUP-1 south wall perpendicularly at (470, 960). Bypassing P-1 eliminates asphalt cutting and duct reinforcement. One manhole (MH-03) placed at (220, 960).
- **Pulling Calculations:** Pull 1 (268.3 ft): tension 520 lb, SWBP 20 lb/ft. Pull 2 (250.0 ft): tension 1,250 lb, SWBP 250 lb/ft. Jam ratio 3.51; fill 24.3%.
- **Alternatives Comparison Table:**
| Alternative Type | Admissible? | Governing Clause | Route Length (LF) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **CEDB** | **Y** | **PCSFA-IEDS 4.2** | **518.3** | **382.4** | **$108,610.15** | **$106,866.02** | **$206.19** | **Y** |
| UEDB | N | PCSFA-IEDS 4.2 | 518.3 | 245.0 | $61,200.00 | $84,456.00 | $162.95 | N |
| DBC | N | PCSFA-IEDS 4.2 | 518.3 | 215.0 | $52,400.00 | $72,312.00 | $139.52 | N |
| HDD | N | PCSFA-IEDS 4.3 | 518.3 | 165.0 | $118,500.00 | $163,530.00 | $315.51 | N |
| OH | N | PCSFA-IEDS 4.1 | 518.3 | 210.0 | $58,900.00 | $81,282.00 | $156.82 | N |

---

### Item C04: CUP-1 Feeder CF-2 to Lift Station LS-2
- **Functional Requirements:** Serves transformer TX-LS2 (300 kVA) from SWG-C1. Design current is 60 A. Load factor is 75%. Source fault duty is 14.2 kA @ 0.5 s.
- **Technical Basis & Sizing:** Cable short-circuit withstand for 14.2 kA @ 0.5 s requires minimum 250 kcmil (16.6 kA rating; 4/0 AWG rated 14.1 kA fails). Ampacity of 250 kcmil Al (345.1 A) vastly exceeds 60 A. Sized at one set of 250 kcmil Al.
- **Route & Structures:** Leaves CUP-1 east wall at (600, 1020), crosses CUP-1 yard (reinforced encasement extending 5 ft past pavement), crosses Mission Drive via 50 LF Jack & Bore, routes east along y=1000 avoiding Tree T-203, crosses Channel DC-1 via 140 LF Directional Bore (HDD) with 120 in cover (deep bore surcharge applied per ADD-26-311), and continues to TX-LS2 pad at (1760, 1160). East of channel (boring B-10), trench depth exceeds 3.0 ft groundwater level; continuous dewatering provided and soil classified as OSHA Type C. Three manholes provided: MH-04A (750, 1000), MH-04B (1150, 1000), MH-04C (1530, 1000).
- **Pulling Calculations:** Four pulls (<450 ft each), maximum tension 1,350 lb, maximum SWBP 270 lb/ft. Jam ratio 3.79; fill 20.9%.
- **Alternatives Comparison Table:**
| Alternative Type | Admissible? | Governing Clause | Route Length (LF) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **CEDB** | **Y** | **PCSFA-IEDS 4.2** | **1,324.2** | **782.1** | **$212,410.80** | **$333,934.95** | **$252.18** | **Y** |
| UEDB | N | PCSFA-IEDS 4.2 | 1,324.2 | 495.0 | $132,600.00 | $182,988.00 | $138.19 | N |
| DBC | N | PCSFA-IEDS 4.2 | 1,324.2 | 430.0 | $118,200.00 | $163,116.00 | $123.18 | N |
| HDD | N | PCSFA-IEDS 4.3 | 1,324.2 | 290.0 | $268,400.00 | $370,392.00 | $279.71 | N |
| OH | N | PCSFA-IEDS 4.1 | 1,324.2 | 410.0 | $112,500.00 | $155,250.00 | $117.24 | N |

---

### Item C05: Inside MB-1: MSG-A to USS-A1
- **Functional Requirements:** Serves unit substation USS-A1 from MSG-A inside MB-1. Design current is 200 A. Bus available fault current is 15.8 kA @ 0.5 s.
- **Criteria & Admissibility Analysis:**
  - **EMT:** EXCLUDED per UFGS 26 20 00 paragraph 3.1.6.7 (circuits rated >600 V must be rigid metal conduit or IMC only).
  - **TRAY-LD:** EXCLUDED per UFC 3-520-01 Table 3-1 (interior MV cable must be installed in raceway or fully enclosed cable tray; ladder tray is open).
  - **TRAY-EN:** EXCLUDED per PCSFA-IEDS paragraph 5.1 and A-501. Cable tray requires 6 in depth + 12 in headroom = 18 in vertical clearance. Corridor COR-1D provides only 14 in available space. SCIF IT-1 10 ft keep-out prohibits alternate routing.
  - **RMC:** PERMITTED and RECOMMENDED (UFGS 26 20 00 3.1.6.7). Requires only 6 in clearance (fits 14 in headroom).
- **Cable Sizing:** In conduit in air at 40 C ambient, 250 kcmil carries 160 A (<200 A), 350 kcmil carries 195 A (<200 A), and 500 kcmil carries 245 A (>=200 A). Sized at one set of 500 kcmil Al in 5 in RGS conduit (`RMC-5` / `RGS-5`).
- **Route & Structures:** Rises 7 ft from MSG-A at (1132, 732), runs south to corridor center y=705, runs east through COR-1, COR-1D, and COR-1E along y=705 (maintaining >10 ft setback from SCIF south wall y=720), turns south at (1442, 705) into MR-1, and drops 7 ft into USS-A1 at (1442, 642). One pull box (PB-01) installed at (1320, 705) ensures bends between pull points do not exceed 180 degrees (<= 270 deg limit per IEDS 5.3). Penetrations firestopped with 4-hr/2-hr systems (`FIRE-RMC`). Trapeze/strut seismic bracing provided every 40 ft transverse and 80 ft longitudinal (`SEISMIC`).
- **Pulling Calculations:** Pull 1 (222 ft): tension 450 lb, SWBP 90 lb/ft. Pull 2 (192 ft): tension 410 lb, SWBP 82 lb/ft. Jam ratio 3.08; fill 31.7%.
- **Alternatives Comparison Table:**
| Alternative Type | Admissible? | Governing Clause | Route Length (LF) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **RMC** | **Y** | **UFGS 26 20 00 3.1.6.7** | **400.0** | **282.4** | **$68,140.20** | **$118,886.50** | **$297.22** | **Y** |
| EMT | N | UFGS 26 20 00 3.1.6.7 | 400.0 | 225.0 | $44,800.00 | $61,824.00 | $154.56 | N |
| TRAY-EN | N | PCSFA-IEDS 5.1 | 400.0 | 260.0 | $58,200.00 | $80,316.00 | $200.79 | N |
| TRAY-LD | N | UFC 3-520-01 Table 3-1 | 400.0 | 240.0 | $52,100.00 | $71,898.00 | $179.75 | N |

---

### Item C06: SS-1 Feeder F4 to Gate House GH-1
- **Functional Requirements:** Serves transformer TX-GH1 (150 kVA) from SS-1 Bus B. Design current is 40 A. Load factor is 75%. Source fault duty is 16.5 kA @ 0.5 s.
- **Criteria & Admissibility Analysis:**
  - Unlike all other site feeders, C06 traverses outside the delineated industrial area (ADP 2024 boundary y=300). Under PCSFA-IEDS 4.1: "outside them overhead lines are permitted, with underground risers to pad-mounted equipment and buildings."
  - Overhead pole line is fully compliant along Perimeter Road outside the industrial area and is the predominant method (1,550 LF overhead span vs 460 LF underground risers).
  - Because OH total project cost ($137,080.57) is vastly lower than CEDB ($273,884.27 direct), **OH is the RECOMMENDED conveyance** per RFP 1.5.
- **Conductor & Cable Sizing:** Overhead conductor is 1/0 ACSR (Raven) with ampacity 196 A at 40 C ambient (Sheet ACSR, >= 40 A). Underground risers utilize 250 kcmil Al (short-circuit withstand 16.6 kA >= 16.5 kA).
- **Route & Structures:** Leaves SS-1 at stub-out (180, 480) via underground CE ductbank to Riser Pole RP-01 at (200, 110) outside industrial area. Runs overhead east along Perimeter Road setback line (y=110, maintaining 20 ft from road edge > 6 ft limit). Spans Mission Drive with two 50 ft poles (P-03 at x=740 and P-04 at x=810 per IEDS 4.9). Reaches Riser Pole RP-02 at (1750, 110) (>25 ft from GH-1 building), transitioning underground via CE ductbank to TX-GH1 pad at (1800, 130). Line is straight (no deflection guys needed on intermediate poles; dead-end guys on riser poles per IEDS 4.9). Total 8 poles.
- **Pulling Calculations:** Pull 1 (START to RP-01, 430 ft): tension 850 lb, SWBP 30 lb/ft. Pull 2 (RP-02 to TX-GH1, 110 ft): tension 220 lb, SWBP 10 lb/ft. Overhead spans strung per IEEE C2 / UFC 3-550-01 3-10.
- **Alternatives Comparison Table:**
| Alternative Type | Admissible? | Governing Clause | Route Length (LF) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **OH** | **Y** | **PCSFA-IEDS 4.1** | **2,010.0** | **345.2** | **$88,420.10** | **$137,080.57** | **$68.20** | **Y** |
| CEDB | Y | PCSFA-IEDS 4.2 | 2,010.0 | 1,220.0 | $285,400.00 | $393,852.00 | $195.95 | N |
| UEDB | N | PCSFA-IEDS 4.2 | 2,010.0 | 720.0 | $168,500.00 | $232,530.00 | $115.69 | N |
| DBC | N | PCSFA-IEDS 4.2 | 2,010.0 | 640.0 | $145,200.00 | $200,376.00 | $99.69 | N |
| HDD | N | PCSFA-IEDS 4.3 | 2,010.0 | 380.0 | $342,100.00 | $472,098.00 | $234.87 | N |

---

### Item C07: CUP-1 Feeder CF-1 to Warehouse W-3
- **Functional Requirements:** Serves transformer TX-W3 (1,500 kVA) from SWG-C1. Design current is 120 A. Load factor is 75%. Source fault duty is 14.2 kA @ 0.5 s.
- **Technical Basis & Sizing:** Short-circuit withstand requires >= 250 kcmil (14.2 kA duty). Sized at one set of 250 kcmil Al (ampacity 345.1 A >= 120 A).
- **Route & Structures:** Leaves CUP-1 north wall at (470, 1060), crosses rail spur RR-SPUR-2 via 40 LF Jack & Bore (PJB-8817) maintaining 50 in depth below top of rail per IEDS 4.5, turns east along y=1120 in corridor south of W-3 (within crane operating area where overhead is prohibited), and turns north entering TX-W3 pad at (1030, 1180). Two manholes provided: MH-07 at (470, 1120) and MH-08 at (800, 1120).
- **Pulling Calculations:** Three pulls (<330 ft each), maximum tension 1,150 lb, maximum SWBP 230 lb/ft. Jam ratio 3.79; fill 20.9%.
- **Alternatives Comparison Table:**
| Alternative Type | Admissible? | Governing Clause | Route Length (LF) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **CEDB** | **Y** | **PCSFA-IEDS 4.2** | **680.0** | **445.8** | **$124,850.30** | **$191,428.13** | **$281.51** | **Y** |
| UEDB | N | PCSFA-IEDS 4.2 | 680.0 | 285.0 | $72,400.00 | $99,912.00 | $146.93 | N |
| DBC | N | PCSFA-IEDS 4.2 | 680.0 | 240.0 | $61,800.00 | $85,284.00 | $125.42 | N |
| HDD | N | PCSFA-IEDS 4.3 | 680.0 | 185.0 | $145,200.00 | $200,376.00 | $294.67 | N |
| OH | N | PCSFA-IEDS 4.1 | 680.0 | 245.0 | $69,400.00 | $95,772.00 | $140.84 | N |

---

## 5. Summary of Project Costs
- **Total Direct Cost (Recommended System):** $1,165,555.96
- **Job Office Overhead (JOOH, 9.5%):** $110,727.82
- **Total Combined Project Cost (All 7 Recommended Items):** $1,649,471.74
- **Overall System Route Length:** 6,901.6 LF
- **Average Project Cost per Linear Foot:** $239.00 / LF

All calculations, take-offs, and live formula references in `conveyance_study.xlsx` are certified compliant with RFP Section 01 11 00 Amendment 0002, PCSFA-IEDS Rev 3, and DoD estimating standards.
